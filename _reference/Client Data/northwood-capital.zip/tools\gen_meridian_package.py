"""
gen_meridian_package.py
Generates Q4 2025 Management Package Excel file for Meridian Business Solutions
Portfolio company of Northwood Capital Fund I
"""

import os
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.utils import get_column_letter

# ─── PATHS ────────────────────────────────────────────────────────────────────
BASE = "/Users/diego/Desktop/Claude-Projects/kith-os/environments/clients/northwood-capital"
OUT_PATH = os.path.join(
    BASE,
    "portfolio/meridian-business-solutions/reporting/meridian-management-package-q4-2025-v1.xlsx"
)
os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)

# ─── CONSTANTS ────────────────────────────────────────────────────────────────
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

SEASONALITY = {
    "Jan": 0.065, "Feb": 0.075, "Mar": 0.085,
    "Apr": 0.080, "May": 0.080, "Jun": 0.085,
    "Jul": 0.075, "Aug": 0.080, "Sep": 0.085,
    "Oct": 0.090, "Nov": 0.095, "Dec": 0.105
}

REV_2025 = 222.0
REV_2024 = 209.0
REV_BUDGET = 220.0

DIRECT_LABOR_PCT = 0.65
SM_PCT = 0.08
GA_PCT = 0.10
DA_PCT = 0.025
INTEREST_MONTHLY = 0.298  # $42M × 8.5% / 12
TAX_RATE = 0.25
CAPEX_PCT = 0.015
DEBT_REPAY_MONTHLY = 0.035  # $42M × 1% / 12

# ─── COLORS ───────────────────────────────────────────────────────────────────
NAVY = "1F3864"
LIGHT_BLUE = "D9E1F2"
ALT_GRAY = "F9F9F9"
GREEN_POS = "00B050"
RED_NEG = "FF0000"
GREEN_FILL = "C6EFCE"
YELLOW_FILL = "FFEB9C"
BLUE_FILL = "BDD7EE"
GRAY_FILL = "EDEDED"

# ─── STYLE HELPERS ────────────────────────────────────────────────────────────
def navy_fill():
    return PatternFill("solid", fgColor=NAVY)

def light_blue_fill():
    return PatternFill("solid", fgColor=LIGHT_BLUE)

def alt_gray_fill():
    return PatternFill("solid", fgColor=ALT_GRAY)

def white_fill():
    return PatternFill("solid", fgColor="FFFFFF")

def header_font():
    return Font(name="Calibri", bold=True, color="FFFFFF", size=11)

def bold_font(size=10):
    return Font(name="Calibri", bold=True, size=size)

def italic_font(size=10):
    return Font(name="Calibri", italic=True, size=size)

def normal_font(size=10):
    return Font(name="Calibri", size=size)

def green_font():
    return Font(name="Calibri", color=GREEN_POS, size=10)

def red_font():
    return Font(name="Calibri", color=RED_NEG, size=10)

def center_align():
    return Alignment(horizontal="center", vertical="center", wrap_text=False)

def left_align():
    return Alignment(horizontal="left", vertical="center")

def right_align():
    return Alignment(horizontal="right", vertical="center")

def set_col_widths(ws, col_a=32, data_width=13):
    ws.column_dimensions["A"].width = col_a
    for col in range(2, ws.max_column + 5):
        letter = get_column_letter(col)
        ws.column_dimensions[letter].width = data_width

def style_header_row(ws, row, last_col, height=18):
    ws.row_dimensions[row].height = height
    for col in range(1, last_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = navy_fill()
        cell.font = header_font()
        cell.alignment = center_align()

def style_subtotal_row(ws, row, last_col, bold=True):
    for col in range(1, last_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = light_blue_fill()
        cell.font = bold_font()

def apply_alt_fill(ws, row, last_col, even=True):
    if even:
        for col in range(1, last_col + 1):
            ws.cell(row=row, column=col).fill = alt_gray_fill()

def set_tab_color(ws):
    ws.sheet_properties.tabColor = NAVY

# ─── COMPUTED MONTHLY P&L ─────────────────────────────────────────────────────
def compute_monthly_pl(annual_rev):
    data = {}
    for m in MONTHS:
        rev = round(annual_rev * SEASONALITY[m], 4)
        cogs = round(rev * DIRECT_LABOR_PCT, 4)
        gp = round(rev - cogs, 4)
        sm = round(rev * SM_PCT, 4)
        ga = round(rev * GA_PCT, 4)
        sga = round(sm + ga, 4)
        ebitda = round(gp - sga, 4)
        da = round(rev * DA_PCT, 4)
        ebit = round(ebitda - da, 4)
        interest = INTEREST_MONTHLY
        ebt = round(ebit - interest, 4)
        tax = round(max(ebt * TAX_RATE, 0), 4)
        ni = round(ebt - tax, 4)
        data[m] = {
            "rev": rev, "cogs": cogs, "gp": gp,
            "sm": sm, "ga": ga, "sga": sga,
            "ebitda": ebitda, "da": da, "ebit": ebit,
            "interest": interest, "ebt": ebt, "tax": tax, "ni": ni
        }
    return data

monthly_2025 = compute_monthly_pl(REV_2025)

def fy_sum(monthly, key):
    return round(sum(monthly[m][key] for m in MONTHS), 4)

def fy_from_rev(annual_rev, key):
    tmp = compute_monthly_pl(annual_rev)
    return fy_sum(tmp, key)

# Annual summaries
fy25_rev = REV_2025
fy25_cogs = round(fy25_rev * DIRECT_LABOR_PCT, 1)
fy25_gp = round(fy25_rev - fy25_cogs, 1)
fy25_sm = round(fy25_rev * SM_PCT, 1)
fy25_ga = round(fy25_rev * GA_PCT, 1)
fy25_sga = round(fy25_sm + fy25_ga, 1)
fy25_ebitda = round(fy25_rev * 0.17, 1)  # = 37.7
fy25_da = round(fy25_rev * DA_PCT, 1)
fy25_ebit = round(fy25_ebitda - fy25_da, 1)
fy25_interest = round(INTEREST_MONTHLY * 12, 3)
fy25_ebt = round(fy25_ebit - fy25_interest, 1)
fy25_tax = round(fy25_ebt * TAX_RATE, 1)
fy25_ni = round(fy25_ebt - fy25_tax, 1)

bud_rev = REV_BUDGET
bud_cogs = round(bud_rev * DIRECT_LABOR_PCT, 1)
bud_gp = round(bud_rev - bud_cogs, 1)
bud_sm = round(bud_rev * SM_PCT, 1)
bud_ga = round(bud_rev * GA_PCT, 1)
bud_sga = round(bud_sm + bud_ga, 1)
bud_ebitda = round(bud_rev * 0.17, 1)
bud_da = round(bud_rev * DA_PCT, 1)
bud_ebit = round(bud_ebitda - bud_da, 1)
bud_interest = round(INTEREST_MONTHLY * 12, 3)
bud_ebt = round(bud_ebit - bud_interest, 1)
bud_tax = round(bud_ebt * TAX_RATE, 1)
bud_ni = round(bud_ebt - bud_tax, 1)

fy24_rev = REV_2024
fy24_cogs = round(fy24_rev * DIRECT_LABOR_PCT, 1)
fy24_gp = round(fy24_rev - fy24_cogs, 1)
fy24_sm = round(fy24_rev * SM_PCT, 1)
fy24_ga = round(fy24_rev * GA_PCT, 1)
fy24_sga = round(fy24_sm + fy24_ga, 1)
fy24_ebitda = round(fy24_rev * 0.17, 1)
fy24_da = round(fy24_rev * DA_PCT, 1)
fy24_ebit = round(fy24_ebitda - fy24_da, 1)
fy24_interest = round(INTEREST_MONTHLY * 12, 3)
fy24_ebt = round(fy24_ebit - fy24_interest, 1)
fy24_tax = round(fy24_ebt * TAX_RATE, 1)
fy24_ni = round(fy24_ebt - fy24_tax, 1)

# ─── WORKBOOK ─────────────────────────────────────────────────────────────────
wb = Workbook()

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1: SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
ws1 = wb.active
ws1.title = "Summary"
set_tab_color(ws1)
ws1.column_dimensions["A"].width = 36
ws1.column_dimensions["B"].width = 18
ws1.column_dimensions["C"].width = 18
ws1.column_dimensions["D"].width = 16
ws1.column_dimensions["E"].width = 14
ws1.column_dimensions["F"].width = 18
ws1.column_dimensions["G"].width = 14
ws1.column_dimensions["H"].width = 14

# Header block
ws1.row_dimensions[1].height = 22
c = ws1.cell(row=1, column=1,
             value="Meridian Business Solutions — Management Package")
c.font = Font(name="Calibri", bold=True, size=16, color=NAVY)
c.alignment = left_align()
ws1.merge_cells("A1:H1")

c = ws1.cell(row=2, column=1,
             value="December 2025 / Full Year 2025 | Northwood Capital Fund I")
c.font = Font(name="Calibri", size=11, color="444444")
c.alignment = left_align()
ws1.merge_cells("A2:H2")

c = ws1.cell(row=3, column=1,
             value="Deal Lead: Mark Sullivan | RAG Status: \u25cf GREEN | Prepared: February 2026")
c.font = Font(name="Calibri", size=11, color="444444")
c.alignment = left_align()
ws1.merge_cells("A3:H3")

# Key Metrics table — header row 5
metrics_header = ["Metric", "FY 2025 Actual", "FY 2025 Budget",
                  "Variance ($)", "Variance (%)", "FY 2024 Actual", "YoY ($)", "YoY (%)"]
for col, h in enumerate(metrics_header, 1):
    cell = ws1.cell(row=5, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()
ws1.row_dimensions[5].height = 16

# Metric rows
metric_data = [
    ("Revenue",         222.0,  220.0,  "+$2.0M",  "+0.9%", 209.0, "+$13.0M", "+6.2%", "dollar"),
    ("Gross Profit",    77.7,   77.0,   "+$0.7M",  "+0.9%", 73.2,  "+$4.5M",  "+6.2%", "dollar"),
    ("Gross Margin %",  "35.0%","35.0%","—",       "—",     "35.0%","—",       "—",     "pct"),
    ("EBITDA",          37.7,   37.4,   "+$0.3M",  "+0.8%", 35.5,  "+$2.2M",  "+6.2%", "dollar"),
    ("EBITDA Margin %", "17.0%","17.0%","—",       "—",     "17.0%","—",       "—",     "pct"),
    ("Net Debt",        29.7,   "—",    "—",       "—",     31.9,  "—",       "—",     "dollar"),
    ("Net Leverage (x)","0.8x", "—",    "—",       "—",     "0.9x","—",       "—",     "mult"),
]

fmt_dollar = '#,##0.0'
fmt_pct = '0.0%'

for i, (label, a, b, vd, vp, c24, yoy_d, yoy_p, typ) in enumerate(metric_data):
    row = 6 + i
    ws1.row_dimensions[row].height = 15
    fill = alt_gray_fill() if i % 2 == 1 else white_fill()

    def mc(col, val, fmt=None, fnt=None, aln=None):
        cell = ws1.cell(row=row, column=col, value=val)
        cell.fill = fill
        cell.font = fnt or normal_font()
        cell.alignment = aln or (left_align() if col == 1 else center_align())
        if fmt:
            cell.number_format = fmt
        return cell

    mc(1, label)
    if typ == "dollar" and isinstance(a, float):
        mc(2, a, fmt_dollar)
        mc(3, b, fmt_dollar) if isinstance(b, float) else mc(3, b)
    else:
        mc(2, a)
        mc(3, b)

    # Variance columns — green text for positive
    for col_i, val in [(4, vd), (5, vp), (6, c24), (7, yoy_d), (8, yoy_p)]:
        cell = ws1.cell(row=row, column=col_i, value=val)
        cell.fill = fill
        cell.alignment = center_align()
        if isinstance(val, str) and val.startswith("+"):
            cell.font = Font(name="Calibri", color=GREEN_POS, size=10)
        elif isinstance(val, str) and val.startswith("-"):
            cell.font = Font(name="Calibri", color=RED_NEG, size=10)
        else:
            cell.font = normal_font()
        if isinstance(val, float) and typ == "dollar":
            cell.number_format = fmt_dollar

    if isinstance(c24, float) and typ == "dollar":
        ws1.cell(row=row, column=6).number_format = fmt_dollar

# Section 3 — Commentary
ws1.row_dimensions[13].height = 6
c = ws1.cell(row=14, column=1, value="Management Commentary — Full Year 2025")
c.font = Font(name="Calibri", bold=True, size=11, color=NAVY)
c.alignment = left_align()
ws1.merge_cells("A14:H14")

bullets = [
    "\u2022  Full year 2025 revenue of $222.0M, +0.9% vs. budget and +6.2% vs. prior year. "
    "EBITDA of $37.7M at 17.0% margin, on plan. Fourth consecutive year of double-digit "
    "EBITDA growth since entry.",
    "\u2022  Exit process preparation advancing. Data room 90% complete (financial section) and "
    "75% complete (legal/contracts). QoE engagement initiated with EY. Sell-side advisor "
    "selection is the primary agenda item for the March 12, 2026 board meeting.",
    "\u2022  Operational KPIs strong. Headcount 580, up from 548 at year-end 2024. Utilization "
    "77.8% vs. 77.0% target. Customer churn 3.4% vs. 5.0% budget. DSO 41 days within "
    "45-day target. Contract renewal rate 91.2%.",
]
for i, bullet in enumerate(bullets):
    row = 15 + i
    ws1.row_dimensions[row].height = 30
    cell = ws1.cell(row=row, column=1, value=bullet)
    cell.font = normal_font()
    cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
    ws1.merge_cells(f"A{row}:H{row}")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2: P&L
# ══════════════════════════════════════════════════════════════════════════════
ws2 = wb.create_sheet("P&L")
set_tab_color(ws2)

ws2.column_dimensions["A"].width = 34
for col in range(2, 22):
    ws2.column_dimensions[get_column_letter(col)].width = 13

# Title
ws2.merge_cells("A1:T1")
c = ws2.cell(row=1, column=1,
             value="Income Statement — Full Year 2025 | Actuals vs. Budget vs. Prior Year ($M)")
c.font = Font(name="Calibri", bold=True, size=13, color=NAVY)
c.alignment = left_align()
ws2.row_dimensions[1].height = 20

# Column headers row 2
headers_pl = (
    ["Line Item"] +
    [f"{m} 2025" for m in MONTHS] +
    ["FY 2025 Actual", "FY 2025 Budget", "Variance $", "Variance %",
     "FY 2024 Actual", "YoY $", "YoY %"]
)
for col, h in enumerate(headers_pl, 1):
    cell = ws2.cell(row=2, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()
ws2.row_dimensions[2].height = 16

ws2.freeze_panes = "B3"

# P&L row definitions
# (label, key_or_formula, row_type)
# row_type: normal | subtotal | pct | blank | interest
pl_rows = [
    ("Revenue",               "rev",      "subtotal"),
    ("Direct Labor / COGS",   "cogs",     "normal"),
    ("Gross Profit",          "gp",       "subtotal"),
    ("Gross Margin %",        "gp_pct",   "pct"),
    (None,                    None,       "blank"),
    ("Sales & Marketing",     "sm",       "normal"),
    ("General & Administrative","ga",     "normal"),
    ("Total SG&A",            "sga",      "subtotal"),
    (None,                    None,       "blank"),
    ("EBITDA",                "ebitda",   "subtotal"),
    ("EBITDA Margin %",       "ebd_pct",  "pct"),
    (None,                    None,       "blank"),
    ("Depreciation & Amortization","da",  "normal"),
    ("EBIT",                  "ebit",     "subtotal"),
    ("Interest Expense",      "interest", "normal"),
    ("Earnings Before Tax",   "ebt",      "normal"),
    ("Income Tax Provision",  "tax",      "normal"),
    ("Net Income",            "ni",       "subtotal"),
]

# Annual summary maps
fy25_map = {
    "rev": fy25_rev, "cogs": fy25_cogs, "gp": fy25_gp,
    "sm": fy25_sm, "ga": fy25_ga, "sga": fy25_sga,
    "ebitda": fy25_ebitda, "da": fy25_da, "ebit": fy25_ebit,
    "interest": fy25_interest, "ebt": fy25_ebt, "tax": fy25_tax, "ni": fy25_ni,
    "gp_pct": 0.350, "ebd_pct": 0.170,
}
bud_map = {
    "rev": bud_rev, "cogs": bud_cogs, "gp": bud_gp,
    "sm": bud_sm, "ga": bud_ga, "sga": bud_sga,
    "ebitda": bud_ebitda, "da": bud_da, "ebit": bud_ebit,
    "interest": bud_interest, "ebt": bud_ebt, "tax": bud_tax, "ni": bud_ni,
    "gp_pct": 0.350, "ebd_pct": 0.170,
}
fy24_map = {
    "rev": fy24_rev, "cogs": fy24_cogs, "gp": fy24_gp,
    "sm": fy24_sm, "ga": fy24_ga, "sga": fy24_sga,
    "ebitda": fy24_ebitda, "da": fy24_da, "ebit": fy24_ebit,
    "interest": fy24_interest, "ebt": fy24_ebt, "tax": fy24_tax, "ni": fy24_ni,
    "gp_pct": 0.350, "ebd_pct": 0.170,
}

def get_monthly_val(key, m):
    d = monthly_2025[m]
    if key == "gp_pct":
        return d["gp"] / d["rev"]
    elif key == "ebd_pct":
        return d["ebitda"] / d["rev"]
    return d.get(key, 0)

num_fmt_dollar = "#,##0.0"
num_fmt_pct = "0.0%"

for idx, (label, key, rtype) in enumerate(pl_rows):
    row = 3 + idx
    ws2.row_dimensions[row].height = 14

    if rtype == "blank":
        continue

    even = idx % 2 == 0
    base_fill = white_fill() if even else alt_gray_fill()

    if rtype == "subtotal":
        row_fill = light_blue_fill()
        row_font = bold_font()
    elif rtype == "pct":
        row_fill = base_fill
        row_font = italic_font()
    else:
        row_fill = base_fill
        row_font = normal_font()

    # Label
    cell = ws2.cell(row=row, column=1, value=label)
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = left_align()

    # Monthly values (cols 2-13)
    for mi, m in enumerate(MONTHS):
        col = 2 + mi
        val = get_monthly_val(key, m)
        cell = ws2.cell(row=row, column=col, value=round(val, 4))
        cell.fill = row_fill
        cell.font = row_font
        cell.alignment = right_align()
        cell.number_format = num_fmt_pct if rtype == "pct" else num_fmt_dollar

    # FY 2025 Actual (col 14)
    act_val = fy25_map.get(key, 0)
    cell = ws2.cell(row=row, column=14, value=act_val)
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = right_align()
    cell.number_format = num_fmt_pct if rtype == "pct" else num_fmt_dollar

    # FY 2025 Budget (col 15)
    bud_val = bud_map.get(key, 0)
    cell = ws2.cell(row=row, column=15, value=bud_val)
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = right_align()
    cell.number_format = num_fmt_pct if rtype == "pct" else num_fmt_dollar

    # Variance $ (col 16)
    if rtype == "pct":
        var_d = None
        var_p = None
    else:
        var_d = round(act_val - bud_val, 4)
        var_p = var_d / bud_val if bud_val else 0

    cell16 = ws2.cell(row=row, column=16, value=var_d)
    cell16.fill = row_fill
    cell16.alignment = right_align()
    cell16.number_format = num_fmt_dollar if rtype != "pct" else "General"
    if var_d is not None:
        # For cost lines, negative variance is favorable (costs below budget)
        cost_lines = {"cogs", "sm", "ga", "sga", "da", "interest", "tax"}
        fav = (var_d >= 0) if key not in cost_lines else (var_d <= 0)
        cell16.font = Font(name="Calibri", color=GREEN_POS if fav else RED_NEG, size=10, bold=(rtype == "subtotal"))
    else:
        cell16.font = row_font

    # Variance % (col 17)
    cell17 = ws2.cell(row=row, column=17, value=var_p)
    cell17.fill = row_fill
    cell17.alignment = right_align()
    cell17.number_format = num_fmt_pct
    if var_p is not None:
        cost_lines = {"cogs", "sm", "ga", "sga", "da", "interest", "tax"}
        fav = (var_p >= 0) if key not in cost_lines else (var_p <= 0)
        cell17.font = Font(name="Calibri", color=GREEN_POS if fav else RED_NEG, size=10, bold=(rtype == "subtotal"))
    else:
        cell17.font = row_font

    # FY 2024 Actual (col 18)
    fy24_val = fy24_map.get(key, 0)
    cell = ws2.cell(row=row, column=18, value=fy24_val)
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = right_align()
    cell.number_format = num_fmt_pct if rtype == "pct" else num_fmt_dollar

    # YoY $ (col 19)
    if rtype == "pct":
        yoy_d2 = None
        yoy_p2 = None
    else:
        yoy_d2 = round(act_val - fy24_val, 4)
        yoy_p2 = yoy_d2 / fy24_val if fy24_val else 0

    cell19 = ws2.cell(row=row, column=19, value=yoy_d2)
    cell19.fill = row_fill
    cell19.alignment = right_align()
    cell19.number_format = num_fmt_dollar if rtype != "pct" else "General"
    if yoy_d2 is not None:
        cost_lines2 = {"cogs", "sm", "ga", "sga", "da", "interest", "tax"}
        fav2 = (yoy_d2 >= 0) if key not in cost_lines2 else (yoy_d2 <= 0)
        cell19.font = Font(name="Calibri", color=GREEN_POS if fav2 else RED_NEG, size=10, bold=(rtype == "subtotal"))
    else:
        cell19.font = row_font

    # YoY % (col 20)
    cell20 = ws2.cell(row=row, column=20, value=yoy_p2)
    cell20.fill = row_fill
    cell20.alignment = right_align()
    cell20.number_format = num_fmt_pct
    if yoy_p2 is not None:
        cost_lines2 = {"cogs", "sm", "ga", "sga", "da", "interest", "tax"}
        fav2 = (yoy_p2 >= 0) if key not in cost_lines2 else (yoy_p2 <= 0)
        cell20.font = Font(name="Calibri", color=GREEN_POS if fav2 else RED_NEG, size=10, bold=(rtype == "subtotal"))
    else:
        cell20.font = row_font

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3: BALANCE SHEET
# ══════════════════════════════════════════════════════════════════════════════
ws3 = wb.create_sheet("Balance Sheet")
set_tab_color(ws3)
ws3.column_dimensions["A"].width = 36
ws3.column_dimensions["B"].width = 16
ws3.column_dimensions["C"].width = 16
ws3.column_dimensions["D"].width = 16

# Title
ws3.merge_cells("A1:D1")
c = ws3.cell(row=1, column=1,
             value="Balance Sheet | Northwood Capital Portco Reporting ($M)")
c.font = Font(name="Calibri", bold=True, size=13, color=NAVY)
c.alignment = left_align()
ws3.row_dimensions[1].height = 20

# Column headers
bs_headers = ["", "Dec 2025", "Nov 2025", "Dec 2024"]
for col, h in enumerate(bs_headers, 1):
    cell = ws3.cell(row=2, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()
ws3.row_dimensions[2].height = 16

# Balance sheet data
# (label, dec25, nov25, dec24, row_type)
# row_type: normal | subtotal | section | blank
bs_data = [
    ("ASSETS", None, None, None, "section"),
    ("Cash & Cash Equivalents",      12.3, 11.8, 10.1, "normal"),
    ("Accounts Receivable",          25.3, 25.8, 24.0, "normal"),
    ("Prepaid & Other Current",       2.8,  2.7,  2.5, "normal"),
    ("Total Current Assets",         40.4, 40.3, 36.6, "subtotal"),
    ("PP&E, net",                     8.2,  8.4,  9.0, "normal"),
    ("Goodwill",                    115.0,115.0,115.0, "normal"),
    ("Other Intangibles, net",       27.5, 28.0, 30.0, "normal"),
    ("Other Long-Term Assets",        2.1,  2.1,  2.0, "normal"),
    ("Total Assets",               193.2,193.8,192.6, "subtotal"),
    (None, None, None, None, "blank"),
    ("LIABILITIES & EQUITY",       None, None, None, "section"),
    ("Accounts Payable",              8.1,  8.3,  7.8, "normal"),
    ("Accrued Compensation",          7.2,  7.0,  6.8, "normal"),
    ("Accrued Expenses & Other",      5.2,  5.0,  4.7, "normal"),
    ("Current Portion of LTD",        0.4,  0.4,  0.4, "normal"),
    ("Total Current Liabilities",    20.9, 20.7, 19.7, "subtotal"),
    ("Long-Term Debt",               41.6, 41.8, 42.0, "normal"),
    ("Deferred Tax Liability",        2.1,  2.1,  2.0, "normal"),
    ("Other Long-Term Liabilities",   1.1,  1.1,  1.0, "normal"),
    ("Total Liabilities",            65.7, 65.7, 64.7, "subtotal"),
    ("Total Equity",               127.5,128.1,127.9, "subtotal"),
    ("Total Liabilities & Equity", 193.2,193.8,192.6, "subtotal"),
]

# Verify totals
assert round(12.3+25.3+2.8, 1) == 40.4
assert round(40.4+8.2+115.0+27.5+2.1, 1) == 193.2
assert round(8.1+7.2+5.2+0.4, 1) == 20.9
assert round(20.9+41.6+2.1+1.1, 1) == 65.7
assert round(193.2 - 65.7, 1) == 127.5
assert round(65.7 + 127.5, 1) == 193.2

for idx, row_def in enumerate(bs_data):
    label, d25, d24m, d24y, rtype = row_def
    row = 3 + idx
    ws3.row_dimensions[row].height = 14

    if rtype == "blank":
        continue

    even = idx % 2 == 0
    if rtype == "section":
        cell = ws3.cell(row=row, column=1, value=label)
        cell.font = Font(name="Calibri", bold=True, size=10, color=NAVY)
        cell.fill = PatternFill("solid", fgColor="E8EEF7")
        cell.alignment = left_align()
        ws3.merge_cells(f"A{row}:D{row}")
    elif rtype == "subtotal":
        for col, val in [(1, label), (2, d25), (3, d24m), (4, d24y)]:
            cell = ws3.cell(row=row, column=col, value=val)
            cell.fill = light_blue_fill()
            cell.font = bold_font()
            cell.alignment = right_align() if col > 1 else left_align()
            if col > 1 and val is not None:
                cell.number_format = num_fmt_dollar
    else:
        base_fill = white_fill() if even else alt_gray_fill()
        for col, val in [(1, label), (2, d25), (3, d24m), (4, d24y)]:
            cell = ws3.cell(row=row, column=col, value=val)
            cell.fill = base_fill
            cell.font = normal_font()
            cell.alignment = right_align() if col > 1 else left_align()
            if col > 1 and val is not None:
                cell.number_format = num_fmt_dollar

# Key Ratios section
# Dec25: LTD=41.6, CPLTD=0.4, Cash=12.3 → Net Debt = 42.0 - 12.3 = 29.7
# Nov25: 41.8+0.4-11.8 = 30.4
# Dec24: 42.0+0.4-10.1 = 32.3
start_ratio = 3 + len(bs_data) + 1
ws3.row_dimensions[start_ratio - 1].height = 8

cell = ws3.cell(row=start_ratio, column=1, value="Key Credit Metrics")
cell.font = Font(name="Calibri", bold=True, size=10, color=NAVY)
cell.fill = PatternFill("solid", fgColor="E8EEF7")
cell.alignment = left_align()
ws3.merge_cells(f"A{start_ratio}:D{start_ratio}")

ratios = [
    ("Net Debt ($M)",       29.7, 30.4, 32.3, "dollar"),
    ("LTM EBITDA ($M)",     37.7, None, 35.5, "dollar"),
    ("Net Leverage (x)",    0.79, None, 0.91, "mult"),
]
for ri, (label, d25, d24m, d24y, typ) in enumerate(ratios):
    row = start_ratio + 1 + ri
    ws3.row_dimensions[row].height = 14
    fill = white_fill() if ri % 2 == 0 else alt_gray_fill()
    for col, val in [(1, label), (2, d25), (3, d24m), (4, d24y)]:
        cell = ws3.cell(row=row, column=col, value=val)
        cell.fill = fill
        cell.font = bold_font() if label.startswith("Net Leverage") else normal_font()
        cell.alignment = right_align() if col > 1 else left_align()
        if col > 1 and val is not None:
            if typ == "dollar":
                cell.number_format = num_fmt_dollar
            elif typ == "mult":
                cell.number_format = "0.00"
        elif col > 1 and val is None:
            cell.value = "—"
            cell.alignment = center_align()

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4: CASH FLOW
# ══════════════════════════════════════════════════════════════════════════════
ws4 = wb.create_sheet("Cash Flow")
set_tab_color(ws4)
ws4.column_dimensions["A"].width = 36
for col in range(2, 18):
    ws4.column_dimensions[get_column_letter(col)].width = 13

# Title
ws4.merge_cells("A1:P1")
c = ws4.cell(row=1, column=1,
             value="Statement of Cash Flows — Monthly 2025 ($M)")
c.font = Font(name="Calibri", bold=True, size=13, color=NAVY)
c.alignment = left_align()
ws4.row_dimensions[1].height = 20

# Headers
cf_headers = ["Line Item"] + [f"{m} 2025" for m in MONTHS] + ["FY 2025 Total", "FY 2024 Total"]
for col, h in enumerate(cf_headers, 1):
    cell = ws4.cell(row=2, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()
ws4.row_dimensions[2].height = 16

ws4.freeze_panes = "B3"

# Compute monthly cash flows
# Monthly revenue for prior month (Dec 2024 as base for Jan AR change)
rev_dec24 = REV_2024 * SEASONALITY["Dec"]  # approximate prior month

cf_monthly = {}
prior_rev = rev_dec24
begin_cash = 10.1  # Dec 2024 ending cash

for m in MONTHS:
    rev = monthly_2025[m]["rev"]
    ni = monthly_2025[m]["ni"]
    da = monthly_2025[m]["da"]
    delta_rev = rev - prior_rev
    ar_change = round(-delta_rev * 0.114, 4)
    other_wc = round(rev * 0.015, 4)
    cfo_items = round(ni + da + ar_change + other_wc, 4)
    capex = round(-rev * CAPEX_PCT, 4)
    debt_rep = -DEBT_REPAY_MONTHLY
    net_change = round(cfo_items + capex + debt_rep, 4)
    cf_monthly[m] = {
        "ni": ni, "da": da, "ar_change": ar_change,
        "other_wc": other_wc, "cfo": cfo_items,
        "capex": capex, "investing": capex,
        "debt_rep": debt_rep, "financing": debt_rep,
        "net_change": net_change,
        "begin": begin_cash,
        "ending": round(begin_cash + net_change, 4),
    }
    prior_rev = rev
    begin_cash = cf_monthly[m]["ending"]

def cf_fy_sum(key):
    return round(sum(cf_monthly[m][key] for m in MONTHS), 4)

fy25_cfo = cf_fy_sum("cfo")
fy25_investing = cf_fy_sum("investing")
fy25_financing = cf_fy_sum("financing")
fy25_net_change = cf_fy_sum("net_change")

# FY 2024 reference totals (approximate)
fy24_cf = {
    "ni": None, "da": None, "ar_change": None, "other_wc": None,
    "cfo": 32.1, "capex": -3.1, "investing": -3.1,
    "debt_rep": -0.4, "financing": -0.4,
    "net_change": 28.6,
    "begin": None, "ending": None,
}

cf_rows = [
    ("OPERATING ACTIVITIES", None, "section"),
    ("Net Income",               "ni",         "normal"),
    ("Add: Depreciation & Amortization", "da",  "normal"),
    ("Change in Accounts Receivable",  "ar_change", "normal"),
    ("Change in Other Working Capital","other_wc", "normal"),
    ("Cash from Operations",           "cfo",    "subtotal"),
    (None, None, "blank"),
    ("INVESTING ACTIVITIES", None, "section"),
    ("Capital Expenditures",           "capex",  "normal"),
    ("Total Investing",                "investing","subtotal"),
    (None, None, "blank"),
    ("FINANCING ACTIVITIES", None, "section"),
    ("Mandatory Debt Repayment",       "debt_rep","normal"),
    ("Total Financing",                "financing","subtotal"),
    (None, None, "blank"),
    ("NET CHANGE IN CASH",             "net_change","subtotal"),
    ("BEGINNING CASH",                 "begin",   "normal"),
    ("ENDING CASH",                    "ending",  "subtotal"),
]

for idx, row_def in enumerate(cf_rows):
    label, key, rtype = row_def
    row = 3 + idx
    ws4.row_dimensions[row].height = 14

    if rtype == "blank":
        continue

    even = idx % 2 == 0
    base_fill = white_fill() if even else alt_gray_fill()

    if rtype == "section":
        cell = ws4.cell(row=row, column=1, value=label)
        cell.font = Font(name="Calibri", bold=True, size=10, color=NAVY)
        cell.fill = PatternFill("solid", fgColor="E8EEF7")
        cell.alignment = left_align()
        ws4.merge_cells(f"A{row}:P{row}")
        continue

    if rtype == "subtotal":
        row_fill = light_blue_fill()
        row_font = bold_font()
    else:
        row_fill = base_fill
        row_font = normal_font()

    cell = ws4.cell(row=row, column=1, value=label)
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = left_align()

    # Monthly (cols 2-13)
    monthly_vals = []
    for mi, m in enumerate(MONTHS):
        col = 2 + mi
        if key in ("begin", "ending"):
            val = cf_monthly[m].get(key, 0)
        elif key:
            val = cf_monthly[m].get(key, 0)
        else:
            val = 0
        monthly_vals.append(val)
        cell = ws4.cell(row=row, column=col, value=round(val, 4))
        cell.fill = row_fill
        cell.font = row_font
        cell.alignment = right_align()
        cell.number_format = num_fmt_dollar

    # FY 2025 Total (col 14)
    if key in ("begin",):
        fy25_total = cf_monthly["Jan"]["begin"]
    elif key in ("ending",):
        fy25_total = cf_monthly["Dec"]["ending"]
    elif key:
        fy25_total = cf_fy_sum(key)
    else:
        fy25_total = 0

    cell = ws4.cell(row=row, column=14, value=round(fy25_total, 4))
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = right_align()
    cell.number_format = num_fmt_dollar

    # FY 2024 Total (col 15)
    fy24_val = fy24_cf.get(key)
    if fy24_val is not None:
        cell = ws4.cell(row=row, column=15, value=fy24_val)
    else:
        cell = ws4.cell(row=row, column=15, value="—")
    cell.fill = row_fill
    cell.font = row_font
    cell.alignment = right_align() if fy24_val is not None else center_align()
    if fy24_val is not None:
        cell.number_format = num_fmt_dollar

# ══════════════════════════════════════════════════════════════════════════════
# TAB 5: KPI DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
ws5 = wb.create_sheet("KPI Dashboard")
set_tab_color(ws5)
ws5.column_dimensions["A"].width = 34
for col in range(2, 10):
    ws5.column_dimensions[get_column_letter(col)].width = 16

# Title
ws5.merge_cells("A1:H1")
c = ws5.cell(row=1, column=1,
             value="KPI Dashboard — Q4 2025 / Full Year 2025 | Meridian Business Solutions")
c.font = Font(name="Calibri", bold=True, size=13, color=NAVY)
c.alignment = left_align()
ws5.row_dimensions[1].height = 20

# KPI Table header
kpi_headers = ["KPI", "Q4 2025 Actual", "Q4 2025 Budget", "Q4 2024 Actual",
               "FY 2025 Actual", "FY 2025 Budget", "FY 2024 Actual", "Status"]
for col, h in enumerate(kpi_headers, 1):
    cell = ws5.cell(row=2, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()
ws5.row_dimensions[2].height = 16

# KPI data
# (label, q4a, q4b, q4_24, fya, fyb, fy24, status, fmt)
kpi_rows = [
    ("Revenue ($M)",            58.7,   58.3,   54.9,  222.0,  220.0, 209.0,  "\u2713", "dollar"),
    ("Revenue Growth YoY",      0.069,  0.062,  0.072,  0.062,  0.053, 0.072,  "\u2713", "pct"),
    ("Gross Margin %",          0.350,  0.350,  0.350,  0.350,  0.350, 0.350,  "\u2713", "pct"),
    ("EBITDA ($M)",              9.9,    9.9,    9.3,   37.7,   37.4,  35.5,   "\u2713", "dollar"),
    ("EBITDA Margin %",         0.170,  0.170,  0.170,  0.170,  0.170, 0.170,  "\u2713", "pct"),
    ("Billable Headcount",        455,    450,    430,    455,    450,   430,   "\u2713", "int"),
    ("Total Headcount",           580,    575,    548,    580,    575,   548,   "\u2713", "int"),
    ("Utilization Rate %",      0.782,  0.770,  0.765,  0.778,  0.770, 0.765,  "\u2713", "pct"),
    ("DSO (days)",                 41,     42,     43,     41,     42,    43,   "\u2713", "int"),
    ("Active Customer Count",     145,    143,    138,    145,    143,   138,   "\u2713", "int"),
    ("Customer Churn %",        0.034,  0.050,  0.041,  0.034,  0.050, 0.041,  "\u2713", "pct"),
    ("Contract Renewal Rate %", 0.912,  0.870,  0.885,  0.912,  0.870, 0.885,  "\u2713", "pct"),
    ("Top 10 Customer Conc. %", 0.382,  0.400,  0.395,  0.382,  0.400, 0.395,  "\u2713", "pct"),
    ("NRR %",                   1.080,  1.050,  1.065,  1.080,  1.050, 1.065,  "\u2713", "pct"),
]

for idx, (label, q4a, q4b, q4_24, fya, fyb, fy24, status, fmt) in enumerate(kpi_rows):
    row = 3 + idx
    ws5.row_dimensions[row].height = 14
    fill = white_fill() if idx % 2 == 0 else alt_gray_fill()

    cell = ws5.cell(row=row, column=1, value=label)
    cell.fill = fill
    cell.font = normal_font()
    cell.alignment = left_align()

    num_f = num_fmt_dollar if fmt == "dollar" else (num_fmt_pct if fmt == "pct" else "0")
    for col, val in [(2, q4a), (3, q4b), (4, q4_24), (5, fya), (6, fyb), (7, fy24)]:
        cell = ws5.cell(row=row, column=col, value=val)
        cell.fill = fill
        cell.font = normal_font()
        cell.alignment = right_align()
        if fmt != "int":
            cell.number_format = num_f

    cell = ws5.cell(row=row, column=8, value=status)
    cell.fill = PatternFill("solid", fgColor=GREEN_FILL)
    cell.font = Font(name="Calibri", color="375623", bold=True, size=10)
    cell.alignment = center_align()

# EBITDA Bridge
bridge_start = 3 + len(kpi_rows) + 2
ws5.row_dimensions[bridge_start - 1].height = 8

ws5.merge_cells(f"A{bridge_start}:H{bridge_start}")
c = ws5.cell(row=bridge_start, column=1,
             value="EBITDA Bridge — FY 2025 Actual vs. Budget ($M)")
c.font = Font(name="Calibri", bold=True, size=11, color=NAVY)
c.alignment = left_align()

bridge_hdrs = ["Item", "Amount ($M)", "Note"]
for col, h in enumerate(bridge_hdrs, 1):
    cell = ws5.cell(row=bridge_start + 1, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()
ws5.column_dimensions["C"].width = 55

bridge_rows = [
    ("FY 2025 Budget EBITDA",                             37.4, "—"),
    ("Volume (revenue +$2.0M \u00d7 17% flow-through)",   0.3, "Revenue beat, in-line margin flow-through"),
    ("Mix / Rate",                                         0.0, "Margin structure consistent with budget"),
    ("Cost Savings vs. Budget",                            0.0, "SG&A in-line with budget"),
    ("FY 2025 Actual EBITDA",                             37.7, "+$0.3M / +0.8% favorable to budget"),
]
for bi, (label, amt, note) in enumerate(bridge_rows):
    row = bridge_start + 2 + bi
    ws5.row_dimensions[row].height = 14
    fill = white_fill() if bi % 2 == 0 else alt_gray_fill()
    is_total = label.startswith("FY 2025 Actual")
    row_fill = light_blue_fill() if is_total else fill
    row_fnt = bold_font() if is_total else normal_font()

    cell = ws5.cell(row=row, column=1, value=label)
    cell.fill = row_fill; cell.font = row_fnt; cell.alignment = left_align()

    cell = ws5.cell(row=row, column=2, value=amt)
    cell.fill = row_fill; cell.font = row_fnt; cell.alignment = right_align()
    cell.number_format = num_fmt_dollar
    if not is_total:
        if amt > 0:
            cell.font = Font(name="Calibri", color=GREEN_POS, size=10, bold=is_total)
        elif amt < 0:
            cell.font = Font(name="Calibri", color=RED_NEG, size=10, bold=is_total)

    cell = ws5.cell(row=row, column=3, value=note)
    cell.fill = row_fill; cell.font = row_fnt; cell.alignment = left_align()

note_row = bridge_start + 2 + len(bridge_rows)
ws5.merge_cells(f"A{note_row}:H{note_row}")
cell = ws5.cell(row=note_row, column=1,
                value="Note: Exit process costs (QoE engagement, data room preparation) "
                      "classified as one-time — not in SG&A run-rate above.")
cell.font = Font(name="Calibri", italic=True, size=9, color="666666")
cell.alignment = Alignment(horizontal="left", wrap_text=True)
ws5.row_dimensions[note_row].height = 14

# Exit Process Readiness Checklist
exit_start = note_row + 2
ws5.row_dimensions[exit_start - 1].height = 8

ws5.merge_cells(f"A{exit_start}:H{exit_start}")
c = ws5.cell(row=exit_start, column=1,
             value="Exit Process Readiness Checklist — March 12, 2026 Board Meeting")
c.font = Font(name="Calibri", bold=True, size=11, color=NAVY)
c.alignment = left_align()

exit_hdrs = ["Workstream", "Status", "Owner", "Target Date", "Notes"]
exit_col_widths = {"A": 36, "B": 20, "C": 30, "D": 18, "E": 55}
for col, (k, w) in enumerate(exit_col_widths.items(), 0):
    ws5.column_dimensions[get_column_letter(exit_start + col)] if False else None

for col, h in enumerate(exit_hdrs, 1):
    cell = ws5.cell(row=exit_start + 1, column=col, value=h)
    cell.fill = navy_fill()
    cell.font = header_font()
    cell.alignment = center_align()

# Adjust columns for exit checklist section
ws5.column_dimensions["B"].width = 20
ws5.column_dimensions["C"].width = 30
ws5.column_dimensions["D"].width = 18
ws5.column_dimensions["E"].width = 50

# status → fill color
STATUS_FILLS = {
    "90% Complete":     GREEN_FILL,
    "75% Complete":     YELLOW_FILL,
    "In Progress":      YELLOW_FILL,
    "Board Agenda Item":BLUE_FILL,
    "Not Started":      GRAY_FILL,
    "Draft in Progress":YELLOW_FILL,
}
STATUS_FONTS = {
    "90% Complete":     "375623",
    "75% Complete":     "9C5700",
    "In Progress":      "9C5700",
    "Board Agenda Item":"1F3864",
    "Not Started":      "595959",
    "Draft in Progress":"9C5700",
}

exit_rows = [
    ("Financial Data Room (3-yr + LTM financials, projections)",
     "90% Complete", "Patricia Wells, CFO", "Feb 28, 2026",
     "EY QoE review initiated"),
    ("Legal / Contracts Data Room",
     "75% Complete", "Outside Counsel (Kirkland)", "Mar 5, 2026",
     "Material contracts under review"),
    ("Quality of Earnings Engagement",
     "In Progress", "EY (engaged Jan 2026)", "Mar 20, 2026",
     "Preliminary findings expected Mar 10"),
    ("Management Presentation",
     "Draft in Progress", "Mark Sullivan / Mgmt", "Mar 10, 2026",
     "Full-day session with advisors planned"),
    ("CIM First Draft",
     "Not Started", "Sell-side advisor TBD", "Post-selection",
     "Awaiting advisor selection"),
    ("Sell-side Advisor Selection",
     "Board Agenda Item", "Mark Sullivan", "Mar 12, 2026 Board",
     "Short list: 3 advisors"),
    ("Lender Consent / Process Letter",
     "Not Started", "Brian Taylor / Kirkland", "Post-advisor selection",
     "$42M TL, consent required"),
]

for ei, (ws_name, status, owner, target, notes) in enumerate(exit_rows):
    row = exit_start + 2 + ei
    ws5.row_dimensions[row].height = 16
    base_fill = white_fill() if ei % 2 == 0 else alt_gray_fill()

    for col, val in [(1, ws_name), (2, status), (3, owner), (4, target), (5, notes)]:
        cell = ws5.cell(row=row, column=col, value=val)
        if col == 2:
            sfill = STATUS_FILLS.get(status, GRAY_FILL)
            sfont_color = STATUS_FONTS.get(status, "000000")
            cell.fill = PatternFill("solid", fgColor=sfill)
            cell.font = Font(name="Calibri", bold=True, size=9, color=sfont_color)
            cell.alignment = center_align()
        else:
            cell.fill = base_fill
            cell.font = normal_font()
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=(col == 5))

# ─── SAVE ─────────────────────────────────────────────────────────────────────
wb.save(OUT_PATH)
print(f"Saved: {OUT_PATH}")
print(f"Tabs: {[ws.title for ws in wb.worksheets]}")
