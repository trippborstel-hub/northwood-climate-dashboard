#!/usr/bin/env python3
"""
Northwood Capital — Customer Cube Analysis

Multidimensional customer revenue analysis for DD and portfolio monitoring.
Generates interactive HTML dashboards with concentration, cohort retention,
growth decomposition, tenure, segment, and geography analysis.

Usage:
    # DD mode (pre-close): ingest CSV from target company
    python tools/customer_cube.py --dd everest --data _data/customer-data-everest.csv

    # Portfolio mode (post-close): analyze active portfolio company
    python tools/customer_cube.py --portco meridian-business-solutions [--period 2026-01]

    # JSON output (either mode)
    python tools/customer_cube.py --dd falcon --data file.csv --json
"""

import csv
import json
import sys
import re
import argparse
from pathlib import Path
from datetime import datetime
from collections import defaultdict

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rc_utils


# ============================================================
# COLUMN MAPPING — flexible ingestion from varied ERP exports
# ============================================================

COLUMN_ALIASES = {
    "customer_name": [
        "customer_name", "customer", "name", "client", "account",
        "customer name", "client name", "account name",
    ],
    "period": [
        "period", "date", "month", "year", "reporting_period",
        "reporting period", "fiscal_period", "fiscal period",
    ],
    "revenue": [
        "revenue", "sales", "amount", "total_revenue", "net_revenue",
        "total revenue", "net revenue", "total sales", "gross revenue",
    ],
    "segment": [
        "segment", "product", "service", "line", "category",
        "product_line", "service_line", "product line", "service line",
        "business_line", "business line", "vertical",
    ],
    "geography": [
        "geography", "geo", "region", "state", "location", "market",
        "territory", "area", "country",
    ],
    "first_period": [
        "first_period", "first_date", "acquired", "start_date",
        "cohort", "vintage", "acquisition_date", "first period",
        "customer_since", "customer since",
    ],
}

SECTOR_CUSTOMER_CONFIG = {
    "Business Services": {
        "entity_label": "customers",
        "analysis_type": "standard",
    },
    "Healthcare Services": {
        "entity_label": "payors/clinics",
        "analysis_type": "payor_mix",
    },
    "Industrial Technology": {
        "entity_label": "customers",
        "analysis_type": "contract_backlog",
    },
    "Environmental Services": {
        "entity_label": "customers",
        "analysis_type": "standard",
    },
    "Technology Services": {
        "entity_label": "customers",
        "analysis_type": "standard",
    },
}

# Screening criteria thresholds (from screening-criteria.md)
CONCENTRATION_FLAG_THRESHOLD = 25.0   # >25% single customer = FLAG
CONCENTRATION_PASS_THRESHOLD = 40.0   # >40% single customer = discretionary PASS


# ============================================================
# CSV PARSER — DD MODE
# ============================================================

def _clean_revenue(val):
    """Clean a revenue value string to float."""
    if not val or not isinstance(val, str):
        return None
    val = val.strip()
    if val in ("", "N/A", "N/M", "—", "--", "-"):
        return None
    negative = False
    if val.startswith("(") and val.endswith(")"):
        negative = True
        val = val[1:-1]
    elif val.startswith("-"):
        negative = True
        val = val[1:]
    val = val.replace("$", "").replace(",", "").strip()
    try:
        result = float(val)
        return -result if negative else result
    except (ValueError, TypeError):
        return None


def _match_column(header, target):
    """Check if a CSV header matches a target column alias."""
    cleaned = header.strip().lower().replace("-", "_")
    aliases = COLUMN_ALIASES.get(target, [])
    return cleaned in [a.lower().replace("-", "_") for a in aliases]


def _map_columns(headers):
    """Map CSV headers to canonical column names."""
    mapping = {}
    for header in headers:
        for target, aliases in COLUMN_ALIASES.items():
            if _match_column(header, target):
                mapping[target] = header
                break
    return mapping


def ingest_dd_csv(csv_path):
    """Parse customer revenue CSV for DD analysis.

    Returns dict with customers list, periods, columns detected, and warnings.
    """
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    warnings = []
    rows = []

    with open(path, newline="", encoding="utf-8-sig") as f:
        # Skip comment lines
        lines = []
        for line in f:
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                lines.append(line)

        reader = csv.DictReader(lines)
        col_map = _map_columns(reader.fieldnames or [])

        # Validate required columns
        for required in ["customer_name", "period", "revenue"]:
            if required not in col_map:
                raise ValueError(
                    f"Required column '{required}' not found in CSV. "
                    f"Headers found: {reader.fieldnames}. "
                    f"Accepted aliases: {COLUMN_ALIASES[required]}"
                )

        for i, raw_row in enumerate(reader, start=2):
            name = raw_row.get(col_map["customer_name"], "").strip()
            period = raw_row.get(col_map["period"], "").strip()
            rev_raw = raw_row.get(col_map["revenue"], "")
            revenue = _clean_revenue(rev_raw)

            if not name:
                warnings.append(f"Row {i}: blank customer name — skipped")
                continue
            if not period:
                warnings.append(f"Row {i}: blank period for '{name}' — skipped")
                continue
            if revenue is None:
                warnings.append(f"Row {i}: unparseable revenue '{rev_raw}' for '{name}' — skipped")
                continue

            row = {
                "customer_name": name,
                "period": period,
                "revenue": revenue,
            }

            if "segment" in col_map:
                row["segment"] = raw_row.get(col_map["segment"], "").strip() or None
            if "geography" in col_map:
                row["geography"] = raw_row.get(col_map["geography"], "").strip() or None
            if "first_period" in col_map:
                row["first_period"] = raw_row.get(col_map["first_period"], "").strip() or None

            rows.append(row)

    if not rows:
        raise ValueError("CSV contains no valid data rows after parsing.")

    # Detect period format
    periods = sorted(set(r["period"] for r in rows))
    period_format = "monthly" if any(re.match(r"\d{4}-\d{2}", p) for p in periods) else "annual"

    # Check for duplicates
    seen = set()
    for r in rows:
        key = (r["customer_name"], r["period"])
        if key in seen:
            warnings.append(f"Duplicate row: '{r['customer_name']}' in period '{r['period']}'")
        seen.add(key)

    columns_detected = list(col_map.keys())

    return {
        "customers": rows,
        "periods": periods,
        "columns_detected": columns_detected,
        "period_format": period_format,
        "total_rows": len(rows),
        "warnings": warnings,
    }


# ============================================================
# PORTFOLIO MODE — data assembly
# ============================================================

def assemble_portco_data(portco_slug, period=None):
    """Assemble customer analysis data for an active portfolio company."""
    portco = rc_utils.load_portco(portco_slug)
    kpi_data = rc_utils.load_portco_kpi_dashboard(portco_slug)
    status_data = rc_utils.load_portco_status(portco_slug)
    closing_data = rc_utils.load_portco_closing_summary(portco_slug)

    sector = portco.get("sector", "Business Services")
    config = SECTOR_CUSTOMER_CONFIG.get(sector, SECTOR_CUSTOMER_CONFIG["Business Services"])

    # Extract customer metrics from spine
    customer_count = portco.get("customer_count", 0)
    top_concentration = portco.get("top_customer_concentration", 0)

    # Build synthetic customer data from available metrics
    # Portfolio mode provides aggregate view when transaction-level CSV not available
    customer_metrics = {
        "customer_count": customer_count,
        "top_customer_concentration_pct": top_concentration * 100 if top_concentration < 1 else top_concentration,
        "entry_customer_count": portco.get("customer_count_at_entry"),
        "current_revenue": portco.get("current_revenue", 0),
        "entry_revenue": portco.get("entry_revenue", 0),
        "sector": sector,
        "sector_config": config,
        "revenue_per_customer": (
            round(portco.get("current_revenue", 0) / customer_count, 2)
            if customer_count else None
        ),
    }

    # Parse KPI dashboard for additional metrics if markdown
    kpi_metrics = {}
    if isinstance(kpi_data, str):
        # Try to extract customer-related rows from KPI table
        kpi_table = rc_utils.parse_markdown_table(kpi_data, section_header="Customer KPIs")
        if not kpi_table:
            kpi_table = rc_utils.parse_markdown_table(kpi_data, section_header="Operating KPIs")
        for row in kpi_table:
            kpi_name = row.get("KPI", row.get("Metric", "")).lower()
            current_val = row.get("Current", row.get("Actual", ""))
            if "churn" in kpi_name:
                kpi_metrics["churn_rate"] = rc_utils.parse_number(current_val)
            elif "retention" in kpi_name and "revenue" not in kpi_name:
                kpi_metrics["retention_rate"] = rc_utils.parse_number(current_val)
            elif "nrr" in kpi_name or "net revenue retention" in kpi_name:
                kpi_metrics["nrr"] = rc_utils.parse_number(current_val)
            elif "renewal" in kpi_name:
                kpi_metrics["renewal_rate"] = rc_utils.parse_number(current_val)

    customer_metrics.update(kpi_metrics)

    return {
        "portco": portco,
        "portco_slug": portco_slug,
        "period": period or datetime.now().strftime("%Y-%m"),
        "kpi_data": kpi_data,
        "status_data": status_data,
        "closing_data": closing_data,
        "customer_metrics": customer_metrics,
        "sector": sector,
    }


# ============================================================
# ANALYTICS ENGINE
# ============================================================

def concentration_analysis(customers, periods):
    """Compute revenue concentration metrics for the latest period."""
    latest = periods[-1]
    latest_rows = [c for c in customers if c["period"] == latest]

    if not latest_rows:
        return None

    # Aggregate by customer (in case of duplicates within period)
    cust_rev = defaultdict(float)
    for r in latest_rows:
        cust_rev[r["customer_name"]] += r["revenue"]

    total_revenue = sum(cust_rev.values())
    if total_revenue <= 0:
        return None

    # Rank by revenue descending
    ranked = sorted(cust_rev.items(), key=lambda x: x[1], reverse=True)
    customer_count = len(ranked)

    # Build concentration table
    cumulative = 0
    table = []
    for i, (name, rev) in enumerate(ranked):
        pct = (rev / total_revenue) * 100
        cumulative += pct
        table.append({
            "rank": i + 1,
            "customer_name": name,
            "revenue": rev,
            "pct_of_total": round(pct, 1),
            "cumulative_pct": round(cumulative, 1),
        })

    # Top-N percentages
    def top_n_pct(n):
        return round(sum(t["pct_of_total"] for t in table[:n]), 1)

    # HHI
    shares = [(rev / total_revenue) * 100 for _, rev in ranked]
    hhi = round(sum(s ** 2 for s in shares), 0)
    if hhi < 1500:
        hhi_interp = "Low"
    elif hhi < 2500:
        hhi_interp = "Moderate"
    else:
        hhi_interp = "High"

    # Risk flags
    risk_flags = []
    top_1_pct = table[0]["pct_of_total"] if table else 0
    if top_1_pct > CONCENTRATION_PASS_THRESHOLD:
        risk_flags.append({
            "severity": "HIGH",
            "flag": f"Top customer ({table[0]['customer_name']}) represents {top_1_pct:.1f}% of revenue — exceeds {CONCENTRATION_PASS_THRESHOLD}% discretionary pass threshold",
            "reference": "screening-criteria.md",
        })
    elif top_1_pct > CONCENTRATION_FLAG_THRESHOLD:
        risk_flags.append({
            "severity": "MEDIUM",
            "flag": f"Top customer ({table[0]['customer_name']}) represents {top_1_pct:.1f}% of revenue — exceeds {CONCENTRATION_FLAG_THRESHOLD}% flag-for-review threshold",
            "reference": "screening-criteria.md",
        })

    if hhi >= 2500:
        risk_flags.append({
            "severity": "MEDIUM",
            "flag": f"HHI of {hhi:.0f} indicates high revenue concentration across customer base",
            "reference": "screening-criteria.md",
        })

    return {
        "latest_period": latest,
        "total_revenue": round(total_revenue, 2),
        "customer_count": customer_count,
        "top_1_pct": top_1_pct,
        "top_1_name": table[0]["customer_name"] if table else "N/A",
        "top_5_pct": top_n_pct(5),
        "top_10_pct": top_n_pct(10),
        "top_20_pct": top_n_pct(min(20, customer_count)),
        "hhi": hhi,
        "hhi_interpretation": hhi_interp,
        "concentration_table": table[:50],  # Limit to top 50 for display
        "risk_flags": risk_flags,
        "revenue_per_customer": round(total_revenue / customer_count, 2) if customer_count else 0,
    }


def cohort_retention_analysis(customers, periods):
    """Revenue by customer acquisition vintage (cohort analysis)."""
    if len(periods) < 2:
        return None

    # Determine each customer's first period
    customer_first = {}
    for c in customers:
        fp = c.get("first_period") or c["period"]
        name = c["customer_name"]
        if name not in customer_first or fp < customer_first[name]:
            customer_first[name] = fp

    # Group customers by cohort year
    cohorts = defaultdict(set)
    for name, fp in customer_first.items():
        cohort_year = fp[:4]
        cohorts[cohort_year].add(name)

    # Build revenue by customer-period
    rev_map = defaultdict(lambda: defaultdict(float))
    for c in customers:
        rev_map[c["customer_name"]][c["period"]] += c["revenue"]

    # Build cohort matrix
    cohort_years = sorted(cohorts.keys())
    cohort_data = []
    for cy in cohort_years:
        members = cohorts[cy]
        row = {"cohort": cy, "customer_count": len(members), "periods": {}}
        for p in periods:
            active = [n for n in members if rev_map[n].get(p, 0) > 0]
            rev = sum(rev_map[n].get(p, 0) for n in members)
            row["periods"][p] = {
                "revenue": round(rev, 2),
                "active_customers": len(active),
                "survival_rate": round(len(active) / len(members) * 100, 1) if members else 0,
            }
        # Compute retention vs. first observed period for this cohort
        first_cohort_period = None
        for p in periods:
            if row["periods"][p]["revenue"] > 0:
                first_cohort_period = p
                break
        if first_cohort_period and row["periods"].get(periods[-1]):
            base_rev = row["periods"][first_cohort_period]["revenue"]
            latest_rev = row["periods"][periods[-1]]["revenue"]
            row["retention_rate"] = round(latest_rev / base_rev * 100, 1) if base_rev > 0 else 0
        else:
            row["retention_rate"] = None

        cohort_data.append(row)

    # Overall NRR: for existing customers, revenue in latest vs. prior period
    if len(periods) >= 2:
        prior, latest = periods[-2], periods[-1]
        prior_customers = {c["customer_name"] for c in customers if c["period"] == prior and c["revenue"] > 0}
        existing_rev_latest = sum(
            rev_map[n].get(latest, 0) for n in prior_customers
        )
        existing_rev_prior = sum(
            rev_map[n].get(prior, 0) for n in prior_customers
        )
        nrr = round(existing_rev_latest / existing_rev_prior * 100, 1) if existing_rev_prior > 0 else None

        # Logo retention
        still_active = sum(1 for n in prior_customers if rev_map[n].get(latest, 0) > 0)
        logo_retention = round(still_active / len(prior_customers) * 100, 1) if prior_customers else None
    else:
        nrr = None
        logo_retention = None

    return {
        "cohorts": cohort_data,
        "periods": periods,
        "nrr": nrr,
        "logo_retention": logo_retention,
    }


def growth_decomposition(customers, periods):
    """Decompose revenue growth into new, expansion, contraction, churned."""
    if len(periods) < 2:
        return None

    rev_map = defaultdict(lambda: defaultdict(float))
    for c in customers:
        rev_map[c["customer_name"]][c["period"]] += c["revenue"]

    decomp = []
    for i in range(1, len(periods)):
        prev_p, curr_p = periods[i - 1], periods[i]
        prev_custs = {n: rev_map[n][prev_p] for n in rev_map if rev_map[n].get(prev_p, 0) > 0}
        curr_custs = {n: rev_map[n][curr_p] for n in rev_map if rev_map[n].get(curr_p, 0) > 0}

        new_rev = sum(v for n, v in curr_custs.items() if n not in prev_custs)
        churned_rev = sum(v for n, v in prev_custs.items() if n not in curr_custs)

        existing = set(prev_custs) & set(curr_custs)
        expansion = sum(
            curr_custs[n] - prev_custs[n] for n in existing
            if curr_custs[n] > prev_custs[n]
        )
        contraction = sum(
            prev_custs[n] - curr_custs[n] for n in existing
            if curr_custs[n] < prev_custs[n]
        )

        prev_total = sum(prev_custs.values())
        curr_total = sum(curr_custs.values())

        decomp.append({
            "from_period": prev_p,
            "to_period": curr_p,
            "starting_revenue": round(prev_total, 2),
            "new": round(new_rev, 2),
            "expansion": round(expansion, 2),
            "contraction": round(-contraction, 2),
            "churned": round(-churned_rev, 2),
            "ending_revenue": round(curr_total, 2),
            "net_change": round(curr_total - prev_total, 2),
            "new_customers": len(set(curr_custs) - set(prev_custs)),
            "lost_customers": len(set(prev_custs) - set(curr_custs)),
        })

    # Summary across all periods
    total_new = sum(d["new"] for d in decomp)
    total_expansion = sum(d["expansion"] for d in decomp)
    total_contraction = sum(d["contraction"] for d in decomp)
    total_churned = sum(d["churned"] for d in decomp)

    first_rev = decomp[0]["starting_revenue"] if decomp else 0
    grr = round((first_rev + total_contraction + total_churned) / first_rev * 100, 1) if first_rev > 0 else None
    nrr = round(
        (first_rev + total_expansion + total_contraction + total_churned) / first_rev * 100, 1
    ) if first_rev > 0 else None

    return {
        "periods": decomp,
        "summary": {
            "total_new": round(total_new, 2),
            "total_expansion": round(total_expansion, 2),
            "total_contraction": round(total_contraction, 2),
            "total_churned": round(total_churned, 2),
        },
        "grr": grr,
        "nrr": nrr,
    }


def tenure_distribution(customers, periods):
    """Analyze customer tenure distribution."""
    if not periods:
        return None

    latest = periods[-1]
    latest_customers = {c["customer_name"] for c in customers if c["period"] == latest and c["revenue"] > 0}

    if not latest_customers:
        return None

    # Find first period for each customer
    customer_first = {}
    for c in customers:
        fp = c.get("first_period") or c["period"]
        name = c["customer_name"]
        if name in latest_customers:
            if name not in customer_first or fp < customer_first[name]:
                customer_first[name] = fp

    # Revenue in latest period per customer
    latest_rev = defaultdict(float)
    for c in customers:
        if c["period"] == latest:
            latest_rev[c["customer_name"]] += c["revenue"]

    # Compute tenure in years
    def period_to_year(p):
        return int(p[:4]) + (int(p[5:7]) / 12 if len(p) > 4 else 0)

    latest_year = period_to_year(latest)
    tenures = {}
    for name, fp in customer_first.items():
        tenures[name] = max(0, latest_year - period_to_year(fp))

    # Bucket
    buckets_def = [
        ("<1 yr", 0, 1),
        ("1-2 yr", 1, 2),
        ("2-5 yr", 2, 5),
        ("5-10 yr", 5, 10),
        ("10+ yr", 10, 999),
    ]
    buckets = []
    total_rev = sum(latest_rev.get(n, 0) for n in latest_customers)

    for label, low, high in buckets_def:
        members = [n for n, t in tenures.items() if low <= t < high]
        bucket_rev = sum(latest_rev.get(n, 0) for n in members)
        buckets.append({
            "label": label,
            "count": len(members),
            "revenue": round(bucket_rev, 2),
            "pct_revenue": round(bucket_rev / total_rev * 100, 1) if total_rev > 0 else 0,
        })

    tenure_values = list(tenures.values())
    median_tenure = round(sorted(tenure_values)[len(tenure_values) // 2], 1) if tenure_values else 0
    avg_tenure = round(sum(tenure_values) / len(tenure_values), 1) if tenure_values else 0

    # Revenue-weighted tenure
    if total_rev > 0:
        rw_tenure = round(
            sum(tenures.get(n, 0) * latest_rev.get(n, 0) for n in latest_customers) / total_rev, 1
        )
    else:
        rw_tenure = 0

    # Risk flag
    short_tenure_rev = sum(b["pct_revenue"] for b in buckets if b["label"] in ("<1 yr", "1-2 yr"))
    risk_flag = None
    if short_tenure_rev > 50:
        risk_flag = f"{short_tenure_rev:.1f}% of revenue from customers with <2 year tenure"

    return {
        "buckets": buckets,
        "median_tenure_years": median_tenure,
        "avg_tenure_years": avg_tenure,
        "revenue_weighted_tenure": rw_tenure,
        "risk_flag": risk_flag,
    }


def segment_analysis(customers, periods):
    """Revenue breakdown by segment (if available)."""
    latest = periods[-1]
    latest_rows = [c for c in customers if c["period"] == latest and c.get("segment")]

    if not latest_rows:
        return None

    seg_data = defaultdict(lambda: {"revenue": 0, "customers": set()})
    for r in latest_rows:
        seg = r["segment"]
        seg_data[seg]["revenue"] += r["revenue"]
        seg_data[seg]["customers"].add(r["customer_name"])

    total = sum(s["revenue"] for s in seg_data.values())
    segments = []
    for name, data in sorted(seg_data.items(), key=lambda x: x[1]["revenue"], reverse=True):
        segments.append({
            "name": name,
            "revenue": round(data["revenue"], 2),
            "pct": round(data["revenue"] / total * 100, 1) if total > 0 else 0,
            "customer_count": len(data["customers"]),
        })

    return {"segments": segments, "period": latest}


def geography_analysis(customers, periods):
    """Revenue breakdown by geography (if available)."""
    latest = periods[-1]
    latest_rows = [c for c in customers if c["period"] == latest and c.get("geography")]

    if not latest_rows:
        return None

    geo_data = defaultdict(lambda: {"revenue": 0, "customers": set()})
    for r in latest_rows:
        geo = r["geography"]
        geo_data[geo]["revenue"] += r["revenue"]
        geo_data[geo]["customers"].add(r["customer_name"])

    total = sum(g["revenue"] for g in geo_data.values())
    regions = []
    for name, data in sorted(geo_data.items(), key=lambda x: x[1]["revenue"], reverse=True):
        regions.append({
            "name": name,
            "revenue": round(data["revenue"], 2),
            "pct": round(data["revenue"] / total * 100, 1) if total > 0 else 0,
            "customer_count": len(data["customers"]),
        })

    return {"regions": regions, "period": latest}


# ============================================================
# RISK FLAGGING
# ============================================================

def check_related_entities(concentration_table):
    """Heuristic check for related entities in top-20 customers.

    Flags customer groups that share name stems (potential subsidiaries of
    same parent). Per QA adversarial review: CIMs routinely present
    subsidiary relationships as independent customers.
    """
    top_20 = concentration_table[:20]
    if len(top_20) < 2:
        return None

    # Extract meaningful words (3+ chars) from each name
    name_words = {}
    for entry in top_20:
        name = entry["customer_name"]
        words = set(
            w.lower() for w in re.split(r"[\s,.\-&/]+", name)
            if len(w) >= 3 and w.lower() not in (
                "the", "inc", "llc", "ltd", "corp", "company", "group",
                "services", "solutions", "industries", "partners",
                "international", "national", "management", "holdings",
            )
        )
        name_words[name] = words

    # Find overlapping word pairs
    warnings = []
    names = list(name_words.keys())
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            shared = name_words[names[i]] & name_words[names[j]]
            if len(shared) >= 2:
                entry_i = next(e for e in top_20 if e["customer_name"] == names[i])
                entry_j = next(e for e in top_20 if e["customer_name"] == names[j])
                combined_pct = entry_i["pct_of_total"] + entry_j["pct_of_total"]
                if combined_pct > 10:
                    warnings.append({
                        "severity": "HIGH",
                        "flag": (
                            f"Potential related entities: '{names[i]}' and '{names[j]}' "
                            f"share name elements ({', '.join(shared)}). "
                            f"Combined revenue: {combined_pct:.1f}% of total. "
                            f"Verify corporate family tree before IC presentation."
                        ),
                        "reference": "qa-protocol.md — adversarial review",
                    })

    return warnings if warnings else None


# ============================================================
# QA PROTOCOL
# ============================================================

def run_qa_checks(analytics, mode, input_sources, data_warnings=None):
    """Run 4-check QA protocol per qa-protocol.md."""
    warnings = list(data_warnings or [])
    blocking_issues = []

    # Check 1: Source Verification
    source_check = {
        "passed": True,
        "score": 1.0,
        "notes": f"All data sourced from {', '.join(input_sources)}",
    }

    # Check 2: Structural Consistency
    concentration = analytics.get("concentration")
    structural_ok = True
    if concentration:
        # Verify percentages reconcile
        table = concentration.get("concentration_table", [])
        if table:
            total_pct = sum(t["pct_of_total"] for t in table)
            if abs(total_pct - 100.0) > 0.5:
                structural_ok = False
                warnings.append(f"Revenue percentages sum to {total_pct:.1f}%, expected 100%")

    structural_check = {
        "passed": structural_ok,
        "score": 1.0 if structural_ok else 0.7,
        "notes": "Revenue totals reconcile across all analyses" if structural_ok else "Reconciliation gap detected",
    }

    # Check 3: Adversarial Review
    adversarial_issues = []
    if concentration:
        # Related-entity check
        related = check_related_entities(concentration.get("concentration_table", []))
        if related:
            adversarial_issues.extend(related)
            for r in related:
                warnings.append(r["flag"])

        # Stress test: what if top customer leaves?
        if concentration.get("top_1_pct", 0) > 15:
            warnings.append(
                f"Stress test: loss of top customer ({concentration['top_1_name']}) "
                f"would reduce revenue by {concentration['top_1_pct']:.1f}%"
            )

    adversarial_check = {
        "passed": len(adversarial_issues) == 0,
        "score": 0.6 if adversarial_issues else 1.0,
        "notes": (
            f"{len(adversarial_issues)} potential related-entity issue(s) flagged"
            if adversarial_issues
            else "No related-entity concentration detected"
        ),
    }

    # Check 4: Assumption Flagging
    assumptions = []
    if mode == "dd":
        assumptions.append("[RC Assumption] Customer tenure based on first observed period in dataset — may not reflect true acquisition date")
        assumptions.append("[CSV Data] Revenue figures as provided by target management — not independently verified")
    else:
        assumptions.append("[Spine] Customer count and concentration from data-spine.json")
        assumptions.append("[Portco Mgmt] KPI metrics from portco-reported dashboard")

    assumption_check = {
        "passed": True,
        "score": 0.9,
        "notes": "; ".join(assumptions),
    }

    return {
        "source_verification": source_check,
        "structural_consistency": structural_check,
        "adversarial_review": adversarial_check,
        "assumption_flagging": assumption_check,
        "warnings": warnings,
        "blocking_issues": blocking_issues,
        "assumptions": assumptions,
    }


# ============================================================
# HTML GENERATION — Interactive Dashboard
# ============================================================

def _build_css():
    """Shared CSS for the interactive dashboard."""
    return """
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      background: #f0f2f5; color: #333; line-height: 1.6;
    }

    .dashboard { max-width: 1400px; margin: 0 auto; padding: 24px; }

    .header {
      background: linear-gradient(135deg, #1B365D 0%, #2a4a7f 100%);
      color: white; padding: 32px 40px; border-radius: 12px; margin-bottom: 24px;
    }
    .header h1 { font-size: 28px; font-weight: 600; margin-bottom: 4px; }
    .header .subtitle { font-size: 16px; opacity: 0.85; }
    .header .meta { font-size: 13px; opacity: 0.7; margin-top: 8px; }

    .metric-grid {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;
    }
    .metric-card {
      background: white; border-radius: 8px; padding: 20px;
      border-left: 4px solid #1B365D; box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    .metric-card.flag { border-left-color: #ffc107; }
    .metric-card.danger { border-left-color: #dc3545; }
    .metric-card .label { font-size: 12px; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; }
    .metric-card .value { font-size: 26px; font-weight: 700; color: #1B365D; margin: 4px 0; }
    .metric-card .detail { font-size: 12px; color: #495057; }

    .tabs {
      display: flex; gap: 4px; margin-bottom: 0; background: white;
      border-radius: 8px 8px 0 0; padding: 8px 8px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.08);
      flex-wrap: wrap;
    }
    .tab {
      padding: 10px 20px; cursor: pointer; border-radius: 6px 6px 0 0;
      font-size: 14px; font-weight: 500; color: #6c757d;
      border: 1px solid transparent; border-bottom: none;
      transition: all 0.15s ease;
    }
    .tab:hover { color: #1B365D; background: #f8f9fa; }
    .tab.active { color: #1B365D; background: #f8f9fa; border-color: #dee2e6; font-weight: 600; }

    .tab-content {
      background: white; padding: 24px; border-radius: 0 0 8px 8px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 24px;
      display: none;
    }
    .tab-content.active { display: block; }

    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th {
      background: #1B365D; color: white; padding: 10px 12px;
      text-align: left; font-weight: 600; font-size: 13px;
      cursor: pointer; user-select: none; position: relative;
    }
    th:hover { background: #244675; }
    th.right, td.right { text-align: right; }
    th .sort-icon { margin-left: 4px; opacity: 0.5; font-size: 11px; }
    th.sorted .sort-icon { opacity: 1; }
    td { padding: 8px 12px; border-bottom: 1px solid #eee; }
    tr:nth-child(even) td { background: #fafbfc; }
    tr:hover td { background: #f0f4f8; }

    .bar-cell { position: relative; }
    .bar-bg {
      position: absolute; top: 4px; bottom: 4px; left: 0;
      background: rgba(27, 54, 93, 0.08); border-radius: 3px;
    }
    .bar-cell span { position: relative; z-index: 1; }

    .search-box {
      margin-bottom: 16px; display: flex; align-items: center; gap: 8px;
    }
    .search-box input {
      padding: 8px 12px; border: 1px solid #dee2e6; border-radius: 6px;
      font-size: 14px; width: 300px; outline: none;
    }
    .search-box input:focus { border-color: #1B365D; box-shadow: 0 0 0 2px rgba(27,54,93,0.15); }

    .rag { display: inline-block; padding: 3px 10px; border-radius: 4px; font-weight: 600; font-size: 12px; }
    .rag-green { background: #d4edda; color: #155724; }
    .rag-amber { background: #fff3cd; color: #856404; }
    .rag-red { background: #f8d7da; color: #721c24; }

    .badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; }
    .badge-high { background: #f8d7da; color: #721c24; }
    .badge-medium { background: #fff3cd; color: #856404; }
    .badge-low { background: #d4edda; color: #155724; }

    h2 { color: #1B365D; font-size: 18px; margin: 20px 0 12px; }
    h3 { color: #1B365D; font-size: 15px; margin: 16px 0 8px; }

    .waterfall { display: flex; align-items: flex-end; gap: 8px; height: 200px; margin: 16px 0; }
    .waterfall-bar {
      flex: 1; display: flex; flex-direction: column; align-items: center;
      justify-content: flex-end; min-width: 60px;
    }
    .waterfall-bar .bar {
      width: 100%; border-radius: 4px 4px 0 0; min-height: 4px;
      transition: height 0.3s ease;
    }
    .waterfall-bar .bar-label {
      font-size: 11px; font-weight: 600; margin-bottom: 4px; text-align: center;
    }
    .waterfall-bar .bar-name {
      font-size: 11px; color: #6c757d; margin-top: 6px; text-align: center;
    }
    .bar-positive { background: #28a745; }
    .bar-negative { background: #dc3545; }
    .bar-neutral { background: #1B365D; }

    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }

    .highlight {
      background: #f8f9fa; border-left: 4px solid #1B365D;
      padding: 12px 16px; margin: 12px 0; border-radius: 0 4px 4px 0;
    }
    .highlight.warn { border-left-color: #ffc107; background: #fffcf0; }
    .highlight.danger { border-left-color: #dc3545; background: #fff5f5; }

    .qa-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
    .qa-card {
      border: 1px solid #dee2e6; border-radius: 6px; padding: 12px;
    }
    .qa-card.pass { border-color: #28a745; }
    .qa-card.warn { border-color: #ffc107; }
    .qa-card.fail { border-color: #dc3545; }
    .qa-card .qa-title { font-weight: 600; font-size: 13px; margin-bottom: 4px; }
    .qa-card .qa-detail { font-size: 12px; color: #495057; }

    .cohort-cell {
      text-align: center; font-size: 13px; font-weight: 500; padding: 6px 8px;
    }
    .cohort-green { background: #d4edda; color: #155724; }
    .cohort-amber { background: #fff3cd; color: #856404; }
    .cohort-red { background: #f8d7da; color: #721c24; }
    .cohort-gray { background: #f8f9fa; color: #999; }

    .footer-bar {
      text-align: center; padding: 16px; font-size: 12px; color: #6c757d;
    }

    @media print {
      body { background: white; }
      .dashboard { max-width: 100%; padding: 0; }
      .tabs { display: none; }
      .tab-content { display: block !important; page-break-inside: avoid; box-shadow: none; }
      .search-box { display: none; }
      .header { border-radius: 0; }
    }
"""


def _build_js():
    """Interactive JavaScript for tabs, sorting, and filtering."""
    return """
    // Tab navigation
    function showTab(tabId) {
      document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
      document.getElementById(tabId).classList.add('active');
      document.querySelector('[data-tab="' + tabId + '"]').classList.add('active');
    }

    // Table sorting
    function sortTable(tableId, colIdx, numeric) {
      var table = document.getElementById(tableId);
      if (!table) return;
      var tbody = table.querySelector('tbody') || table;
      var rows = Array.from(tbody.querySelectorAll('tr'));
      var header = table.querySelectorAll('th')[colIdx];
      var asc = header.getAttribute('data-sort') !== 'asc';
      // Reset other headers
      table.querySelectorAll('th').forEach(function(th) {
        th.removeAttribute('data-sort');
        th.classList.remove('sorted');
      });
      header.setAttribute('data-sort', asc ? 'asc' : 'desc');
      header.classList.add('sorted');

      rows.sort(function(a, b) {
        var aVal = a.cells[colIdx].getAttribute('data-val') || a.cells[colIdx].textContent.trim();
        var bVal = b.cells[colIdx].getAttribute('data-val') || b.cells[colIdx].textContent.trim();
        if (numeric) {
          aVal = parseFloat(aVal.replace(/[^0-9.\\-]/g, '')) || 0;
          bVal = parseFloat(bVal.replace(/[^0-9.\\-]/g, '')) || 0;
        }
        if (aVal < bVal) return asc ? -1 : 1;
        if (aVal > bVal) return asc ? 1 : -1;
        return 0;
      });
      rows.forEach(function(row) { tbody.appendChild(row); });
    }

    // Customer search/filter
    function filterTable(tableId, inputId) {
      var filter = document.getElementById(inputId).value.toLowerCase();
      var table = document.getElementById(tableId);
      if (!table) return;
      var rows = table.querySelectorAll('tbody tr, tr:not(:first-child)');
      rows.forEach(function(row) {
        var text = row.textContent.toLowerCase();
        row.style.display = text.indexOf(filter) > -1 ? '' : 'none';
      });
    }
"""


def generate_html_dd(entity_name, deal_data, analytics, qa_results):
    """Generate interactive HTML dashboard for DD mode."""
    conc = analytics.get("concentration")
    cohort = analytics.get("cohort")
    growth = analytics.get("growth")
    tenure = analytics.get("tenure")
    seg = analytics.get("segment")
    geo = analytics.get("geography")
    fc = rc_utils.fc
    fp = rc_utils.fp
    fi = rc_utils.fi

    total_rev = conc["total_revenue"] if conc else 0
    cust_count = conc["customer_count"] if conc else 0
    top_1_pct = conc["top_1_pct"] if conc else 0
    hhi = conc["hhi"] if conc else 0
    hhi_interp = conc["hhi_interpretation"] if conc else "N/A"

    # Determine card severity classes
    top1_class = "danger" if top_1_pct > 40 else ("flag" if top_1_pct > 25 else "")
    hhi_class = "danger" if hhi > 2500 else ("flag" if hhi > 1500 else "")

    # Build tabs list
    tabs = [
        ("tab-concentration", "Concentration"),
        ("tab-cohort", "Cohort Retention"),
        ("tab-growth", "Growth Decomposition"),
        ("tab-tenure", "Tenure"),
    ]
    if seg:
        tabs.append(("tab-segment", "Segments"))
    if geo:
        tabs.append(("tab-geography", "Geography"))
    tabs.append(("tab-qa", "Risk & QA"))

    tabs_html = "".join(
        f'<div class="tab{"" if i > 0 else " active"}" data-tab="{tid}" onclick="showTab(\'{tid}\')">{label}</div>'
        for i, (tid, label) in enumerate(tabs)
    )

    # --- Concentration Tab ---
    conc_rows = ""
    if conc:
        for entry in conc["concentration_table"][:30]:
            bar_width = min(entry["pct_of_total"], 100)
            conc_rows += f"""<tr>
              <td class="right">{entry['rank']}</td>
              <td>{entry['customer_name']}</td>
              <td class="right" data-val="{entry['revenue']}">${entry['revenue']:,.0f}</td>
              <td class="bar-cell right" data-val="{entry['pct_of_total']}">
                <div class="bar-bg" style="width:{bar_width}%"></div>
                <span>{entry['pct_of_total']:.1f}%</span>
              </td>
              <td class="right" data-val="{entry['cumulative_pct']}">{entry['cumulative_pct']:.1f}%</td>
            </tr>"""

    # --- Cohort Tab ---
    cohort_html = ""
    if cohort and cohort["cohorts"]:
        periods = cohort["periods"]
        # Show up to last 6 periods
        display_periods = periods[-6:] if len(periods) > 6 else periods
        period_headers = "".join(f"<th class='right'>{p}</th>" for p in display_periods)
        cohort_html += f"""
        <h2>Cohort Retention Matrix</h2>
        <p style="font-size:13px;color:#6c757d;margin-bottom:12px;">
          Revenue retention by customer acquisition vintage. Colors:
          <span class="cohort-cell cohort-green" style="display:inline;padding:2px 6px;">&gt;90%</span>
          <span class="cohort-cell cohort-amber" style="display:inline;padding:2px 6px;">70-90%</span>
          <span class="cohort-cell cohort-red" style="display:inline;padding:2px 6px;">&lt;70%</span>
        </p>
        <table><tr><th>Cohort</th><th class="right">Customers</th>{period_headers}<th class="right">Retention</th></tr>
        """
        for c in cohort["cohorts"]:
            row = f"<tr><td><strong>{c['cohort']}</strong></td><td class='right'>{c['customer_count']}</td>"
            for p in display_periods:
                pd = c["periods"].get(p, {})
                rev = pd.get("revenue", 0)
                surv = pd.get("survival_rate", 0)
                css = "cohort-green" if surv > 90 else ("cohort-amber" if surv > 70 else ("cohort-red" if surv > 0 else "cohort-gray"))
                row += f'<td class="cohort-cell {css} right">${rev:,.0f}</td>'
            ret = c.get("retention_rate")
            ret_str = f"{ret:.0f}%" if ret is not None else "—"
            row += f"<td class='right'><strong>{ret_str}</strong></td></tr>"
            cohort_html += row
        cohort_html += "</table>"

        # Summary metrics
        nrr_str = f"{cohort['nrr']:.1f}%" if cohort["nrr"] is not None else "N/A"
        logo_str = f"{cohort['logo_retention']:.1f}%" if cohort["logo_retention"] is not None else "N/A"
        cohort_html += f"""
        <div class="metric-grid" style="grid-template-columns:repeat(2,1fr);margin-top:16px;">
          <div class="metric-card"><div class="label">Net Revenue Retention</div><div class="value">{nrr_str}</div><div class="detail">Latest period vs. prior</div></div>
          <div class="metric-card"><div class="label">Logo Retention</div><div class="value">{logo_str}</div><div class="detail">% of prior-period customers still active</div></div>
        </div>"""

    # --- Growth Decomposition Tab ---
    growth_html = ""
    if growth and growth["periods"]:
        # Waterfall for latest period transition
        latest = growth["periods"][-1]
        max_val = max(
            abs(latest["starting_revenue"]),
            abs(latest["new"]),
            abs(latest["expansion"]),
            abs(latest["contraction"]),
            abs(latest["churned"]),
            abs(latest["ending_revenue"]),
            1,
        )

        def bar_h(val):
            return max(4, int(abs(val) / max_val * 180))

        growth_html += f"""
        <h2>Revenue Bridge: {latest['from_period']} to {latest['to_period']}</h2>
        <div class="waterfall">
          <div class="waterfall-bar"><div class="bar-label">${latest['starting_revenue']:,.0f}</div><div class="bar bar-neutral" style="height:{bar_h(latest['starting_revenue'])}px;"></div><div class="bar-name">Starting</div></div>
          <div class="waterfall-bar"><div class="bar-label">+${latest['new']:,.0f}</div><div class="bar bar-positive" style="height:{bar_h(latest['new'])}px;"></div><div class="bar-name">New ({latest['new_customers']})</div></div>
          <div class="waterfall-bar"><div class="bar-label">+${latest['expansion']:,.0f}</div><div class="bar bar-positive" style="height:{bar_h(latest['expansion'])}px;"></div><div class="bar-name">Expansion</div></div>
          <div class="waterfall-bar"><div class="bar-label">-${abs(latest['contraction']):,.0f}</div><div class="bar bar-negative" style="height:{bar_h(latest['contraction'])}px;"></div><div class="bar-name">Contraction</div></div>
          <div class="waterfall-bar"><div class="bar-label">-${abs(latest['churned']):,.0f}</div><div class="bar bar-negative" style="height:{bar_h(latest['churned'])}px;"></div><div class="bar-name">Churned ({latest['lost_customers']})</div></div>
          <div class="waterfall-bar"><div class="bar-label">${latest['ending_revenue']:,.0f}</div><div class="bar bar-neutral" style="height:{bar_h(latest['ending_revenue'])}px;"></div><div class="bar-name">Ending</div></div>
        </div>"""

        # Period-by-period table
        growth_html += """<h2>Period Detail</h2>
        <table><tr><th>Period</th><th class="right">Starting</th><th class="right">New</th><th class="right">Expansion</th><th class="right">Contraction</th><th class="right">Churned</th><th class="right">Ending</th><th class="right">Net Change</th></tr>"""
        for d in growth["periods"]:
            growth_html += f"""<tr>
              <td>{d['from_period']} &rarr; {d['to_period']}</td>
              <td class="right">${d['starting_revenue']:,.0f}</td>
              <td class="right" style="color:#28a745">+${d['new']:,.0f}</td>
              <td class="right" style="color:#28a745">+${d['expansion']:,.0f}</td>
              <td class="right" style="color:#dc3545">-${abs(d['contraction']):,.0f}</td>
              <td class="right" style="color:#dc3545">-${abs(d['churned']):,.0f}</td>
              <td class="right">${d['ending_revenue']:,.0f}</td>
              <td class="right" style="color:{'#28a745' if d['net_change'] >= 0 else '#dc3545'}">{'+' if d['net_change'] >= 0 else ''}{d['net_change']:,.0f}</td>
            </tr>"""
        growth_html += "</table>"

        # Summary
        grr_str = f"{growth['grr']:.1f}%" if growth["grr"] is not None else "N/A"
        nrr_str = f"{growth['nrr']:.1f}%" if growth["nrr"] is not None else "N/A"
        growth_html += f"""
        <div class="metric-grid" style="grid-template-columns:repeat(2,1fr);margin-top:16px;">
          <div class="metric-card"><div class="label">Gross Revenue Retention</div><div class="value">{grr_str}</div><div class="detail">Excluding new + expansion</div></div>
          <div class="metric-card"><div class="label">Net Revenue Retention</div><div class="value">{nrr_str}</div><div class="detail">Including expansion from existing</div></div>
        </div>"""

    # --- Tenure Tab ---
    tenure_html = ""
    if tenure:
        tenure_html += """<h2>Customer Tenure Distribution</h2>
        <table><tr><th>Tenure Bucket</th><th class="right">Customers</th><th class="right">Revenue</th><th class="right">% of Revenue</th></tr>"""
        for b in tenure["buckets"]:
            bar_w = min(b["pct_revenue"], 100)
            tenure_html += f"""<tr>
              <td>{b['label']}</td><td class="right">{b['count']}</td>
              <td class="right">${b['revenue']:,.0f}</td>
              <td class="bar-cell right"><div class="bar-bg" style="width:{bar_w}%"></div><span>{b['pct_revenue']:.1f}%</span></td>
            </tr>"""
        tenure_html += "</table>"
        tenure_html += f"""
        <div class="metric-grid" style="grid-template-columns:repeat(3,1fr);margin-top:16px;">
          <div class="metric-card"><div class="label">Median Tenure</div><div class="value">{tenure['median_tenure_years']:.1f} yr</div></div>
          <div class="metric-card"><div class="label">Average Tenure</div><div class="value">{tenure['avg_tenure_years']:.1f} yr</div></div>
          <div class="metric-card"><div class="label">Revenue-Weighted Tenure</div><div class="value">{tenure['revenue_weighted_tenure']:.1f} yr</div></div>
        </div>"""
        if tenure.get("risk_flag"):
            tenure_html += f'<div class="highlight warn"><strong>Risk Flag:</strong> {tenure["risk_flag"]}</div>'

    # --- Segment Tab ---
    segment_html = ""
    if seg:
        segment_html += f"""<h2>Revenue by Segment — {seg['period']}</h2>
        <table><tr><th>Segment</th><th class="right">Revenue</th><th class="right">% of Total</th><th class="right">Customers</th></tr>"""
        for s in seg["segments"]:
            bar_w = min(s["pct"], 100)
            segment_html += f"""<tr>
              <td>{s['name']}</td><td class="right">${s['revenue']:,.0f}</td>
              <td class="bar-cell right"><div class="bar-bg" style="width:{bar_w}%"></div><span>{s['pct']:.1f}%</span></td>
              <td class="right">{s['customer_count']}</td>
            </tr>"""
        segment_html += "</table>"

    # --- Geography Tab ---
    geo_html = ""
    if geo:
        geo_html += f"""<h2>Revenue by Geography — {geo['period']}</h2>
        <table><tr><th>Region</th><th class="right">Revenue</th><th class="right">% of Total</th><th class="right">Customers</th></tr>"""
        for g in geo["regions"]:
            bar_w = min(g["pct"], 100)
            geo_html += f"""<tr>
              <td>{g['name']}</td><td class="right">${g['revenue']:,.0f}</td>
              <td class="bar-cell right"><div class="bar-bg" style="width:{bar_w}%"></div><span>{g['pct']:.1f}%</span></td>
              <td class="right">{g['customer_count']}</td>
            </tr>"""
        geo_html += "</table>"

    # --- Risk & QA Tab ---
    all_flags = (conc.get("risk_flags", []) if conc else [])
    related_warnings = check_related_entities(conc["concentration_table"]) if conc else None
    if related_warnings:
        all_flags.extend(related_warnings)
    if tenure and tenure.get("risk_flag"):
        all_flags.append({"severity": "MEDIUM", "flag": tenure["risk_flag"], "reference": "operating-review-cadence.md"})

    flags_html = ""
    if all_flags:
        flags_html += '<table><tr><th>Severity</th><th>Finding</th><th>Reference</th></tr>'
        for f in all_flags:
            sev = f["severity"]
            badge_class = "badge-high" if sev == "HIGH" else "badge-medium"
            flags_html += f'<tr><td><span class="badge {badge_class}">{sev}</span></td><td>{f["flag"]}</td><td><code>{f.get("reference", "")}</code></td></tr>'
        flags_html += "</table>"
    else:
        flags_html = '<div class="highlight">No risk flags identified.</div>'

    qa = qa_results
    qa_html = '<div class="qa-grid">'
    for check_name, label in [
        ("source_verification", "Source Verification"),
        ("structural_consistency", "Structural Consistency"),
        ("adversarial_review", "Adversarial Review"),
        ("assumption_flagging", "Assumption Flagging"),
    ]:
        check = qa.get(check_name, {})
        passed = check.get("passed", False)
        css = "pass" if passed else "warn"
        status = "PASS" if passed else "FLAG"
        qa_html += f"""<div class="qa-card {css}">
          <div class="qa-title">{label}: <span class="rag rag-{'green' if passed else 'amber'}">{status}</span></div>
          <div class="qa-detail">{check.get('notes', '')}</div>
        </div>"""
    qa_html += "</div>"

    # Assumptions
    assumptions_html = ""
    if qa.get("assumptions"):
        assumptions_html = "<h3>Assumptions</h3><ul>"
        for a in qa["assumptions"]:
            assumptions_html += f"<li style='font-size:13px;'>{a}</li>"
        assumptions_html += "</ul>"

    # Warnings
    warnings_html = ""
    if qa.get("warnings"):
        warnings_html = "<h3>Warnings</h3>"
        for w in qa["warnings"]:
            warnings_html += f'<div class="highlight warn" style="font-size:13px;">{w}</div>'

    # Full HTML
    generated_date = datetime.now().strftime("%B %d, %Y")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Cube — {entity_name} — Due Diligence</title>
<style>{_build_css()}</style>
</head>
<body>
<div class="dashboard">

<div class="header">
  <h1>{entity_name} — Customer Cube Analysis</h1>
  <div class="subtitle">Due Diligence | {deal_data.get('period_format', 'monthly').title()} Data | {len(deal_data.get('periods', []))} Periods Analyzed</div>
  <div class="meta">CONFIDENTIAL — Northwood Capital | Generated {generated_date} | {deal_data.get('total_rows', 0)} data rows | {len(deal_data.get('columns_detected', []))} columns detected</div>
</div>

<div class="metric-grid">
  <div class="metric-card">
    <div class="label">Total Revenue (Latest)</div>
    <div class="value">${total_rev:,.0f}</div>
    <div class="detail">{conc['latest_period'] if conc else 'N/A'}</div>
  </div>
  <div class="metric-card">
    <div class="label">Customer Count</div>
    <div class="value">{cust_count:,}</div>
    <div class="detail">Active in latest period</div>
  </div>
  <div class="metric-card {top1_class}">
    <div class="label">Top Customer</div>
    <div class="value">{top_1_pct:.1f}%</div>
    <div class="detail">{conc['top_1_name'] if conc else 'N/A'} | Flag: &gt;{CONCENTRATION_FLAG_THRESHOLD:.0f}%</div>
  </div>
  <div class="metric-card {hhi_class}">
    <div class="label">HHI Index</div>
    <div class="value">{hhi:,.0f}</div>
    <div class="detail">{hhi_interp} concentration</div>
  </div>
</div>

<div class="tabs">{tabs_html}</div>

<!-- Tab: Concentration -->
<div id="tab-concentration" class="tab-content active">
  <div class="search-box">
    <input type="text" id="conc-search" placeholder="Search customers..." oninput="filterTable('conc-table','conc-search')">
  </div>
  <table id="conc-table">
    <tr>
      <th class="right" onclick="sortTable('conc-table',0,true)"># <span class="sort-icon">&#9650;&#9660;</span></th>
      <th onclick="sortTable('conc-table',1,false)">Customer <span class="sort-icon">&#9650;&#9660;</span></th>
      <th class="right" onclick="sortTable('conc-table',2,true)">Revenue <span class="sort-icon">&#9650;&#9660;</span></th>
      <th class="right" onclick="sortTable('conc-table',3,true)">% of Total <span class="sort-icon">&#9650;&#9660;</span></th>
      <th class="right" onclick="sortTable('conc-table',4,true)">Cumulative <span class="sort-icon">&#9650;&#9660;</span></th>
    </tr>
    {conc_rows}
  </table>
  <div class="metric-grid" style="grid-template-columns:repeat(4,1fr);margin-top:16px;">
    <div class="metric-card"><div class="label">Top 5</div><div class="value">{conc['top_5_pct'] if conc else 0:.1f}%</div></div>
    <div class="metric-card"><div class="label">Top 10</div><div class="value">{conc['top_10_pct'] if conc else 0:.1f}%</div></div>
    <div class="metric-card"><div class="label">Top 20</div><div class="value">{conc['top_20_pct'] if conc else 0:.1f}%</div></div>
    <div class="metric-card"><div class="label">Rev / Customer</div><div class="value">${conc['revenue_per_customer'] if conc else 0:,.0f}</div></div>
  </div>
</div>

<!-- Tab: Cohort Retention -->
<div id="tab-cohort" class="tab-content">
  {cohort_html if cohort_html else '<div class="highlight">Cohort analysis requires 2+ periods of data.</div>'}
</div>

<!-- Tab: Growth Decomposition -->
<div id="tab-growth" class="tab-content">
  {growth_html if growth_html else '<div class="highlight">Growth decomposition requires 2+ periods of data.</div>'}
</div>

<!-- Tab: Tenure -->
<div id="tab-tenure" class="tab-content">
  {tenure_html if tenure_html else '<div class="highlight">Tenure analysis requires customer data with revenue in the latest period.</div>'}
</div>

{"" if not seg else f'<div id="tab-segment" class="tab-content">{segment_html}</div>'}
{"" if not geo else f'<div id="tab-geography" class="tab-content">{geo_html}</div>'}

<!-- Tab: Risk & QA -->
<div id="tab-qa" class="tab-content">
  <h2>Risk Flags</h2>
  {flags_html}
  <h2 style="margin-top:24px;">QA Protocol Results</h2>
  {qa_html}
  {assumptions_html}
  {warnings_html}
  <h3 style="margin-top:16px;">Data Sources</h3>
  <ul style="font-size:13px;">
    <li>Customer revenue CSV — management-provided data [CSV Data]</li>
    <li>Screening criteria: <code>_reference/screening-criteria.md</code></li>
    <li>QA protocol: <code>_reference/qa-protocol.md</code></li>
  </ul>
  <p style="margin-top:12px;font-size:12px;color:#6c757d;">
    This analysis supports IC Memo Appendix H: Customer concentration analysis (top 10/20)
  </p>
</div>

<div class="footer-bar">
  CONFIDENTIAL — Northwood Capital | Generated {generated_date} | Tool: customer_cube.py | QA protocol applied per qa-protocol.md
</div>

</div>
<script>{_build_js()}</script>
</body>
</html>"""

    return html


def generate_html_portco(portco_data, analytics, qa_results):
    """Generate interactive HTML dashboard for portfolio monitoring mode."""
    portco = portco_data["portco"]
    cm = portco_data["customer_metrics"]
    period = portco_data["period"]
    fc = rc_utils.fc
    fp = rc_utils.fp
    fi = rc_utils.fi

    company = portco.get("portco_name", "Portfolio Company")
    sector = portco.get("sector_detail") or portco.get("sector", "")
    fund = portco.get("fund", "").replace("_", " ").title()

    cust_count = cm.get("customer_count", 0)
    top_pct = cm.get("top_customer_concentration_pct", 0)
    rev_per_cust = cm.get("revenue_per_customer")
    current_rev = cm.get("current_revenue", 0)
    entry_rev = cm.get("entry_revenue", 0)

    churn = cm.get("churn_rate")
    retention = cm.get("retention_rate")
    nrr = cm.get("nrr")
    renewal = cm.get("renewal_rate")

    top1_class = "danger" if top_pct > 40 else ("flag" if top_pct > 25 else "")

    # Performance status
    perf = portco.get("performance_status", "")
    if perf in ["strong", "performing_on_plan", "steady_on_plan", "performing_above_plan", "strong_exit_prep"]:
        rag, rag_label = "green", "GREEN"
    elif perf in ["below_plan"]:
        rag, rag_label = "amber", "AMBER"
    elif perf in ["early_100_day_plan", "early_integration"]:
        rag, rag_label = "amber", "AMBER"
    else:
        rag, rag_label = "green", "GREEN"

    generated_date = datetime.now().strftime("%B %d, %Y")

    # Build KPI table rows
    kpi_rows = ""
    kpi_data = [
        ("Customer Count", fi(cust_count) if cust_count else "N/A", "—", "—"),
        ("Top Customer Concentration", f"{top_pct:.1f}%" if top_pct else "N/A", f"Flag: >{CONCENTRATION_FLAG_THRESHOLD:.0f}%", "green" if top_pct < 25 else ("amber" if top_pct < 40 else "red")),
        ("Revenue per Customer", f"${rev_per_cust:.2f}M" if rev_per_cust else "N/A", "—", "—"),
    ]
    if churn is not None:
        kpi_data.append(("Churn Rate", f"{churn:.1f}%", "<5% annually", "green" if churn < 5 else "amber"))
    if retention is not None:
        kpi_data.append(("Customer Retention", f"{retention:.1f}%", ">80%", "green" if retention > 80 else "amber"))
    if nrr is not None:
        kpi_data.append(("Net Revenue Retention", f"{nrr:.1f}%", ">100%", "green" if nrr > 100 else "amber"))
    if renewal is not None:
        kpi_data.append(("Contract Renewal Rate", f"{renewal:.1f}%", ">85%", "green" if renewal > 85 else "amber"))

    for metric, current, threshold, rag_status in kpi_data:
        rag_badge = f'<span class="rag rag-{rag_status}">{rag_status.upper()}</span>' if rag_status not in ("—",) else "—"
        kpi_rows += f"<tr><td>{metric}</td><td class='right'>{current}</td><td class='right'>{threshold}</td><td>{rag_badge}</td></tr>"

    # Entry comparison
    entry_comparison = ""
    entry_count = cm.get("entry_customer_count")
    if entry_count and cust_count:
        count_change = cust_count - entry_count
        entry_comparison = f"""
        <h2>Entry vs. Current</h2>
        <table>
          <tr><th>Metric</th><th class="right">At Entry</th><th class="right">Current</th><th class="right">Change</th></tr>
          <tr><td>Revenue</td><td class="right">{fc(entry_rev)}</td><td class="right">{fc(current_rev)}</td><td class="right">{fc(current_rev - entry_rev)}</td></tr>
          <tr><td>Customer Count</td><td class="right">{fi(entry_count)}</td><td class="right">{fi(cust_count)}</td><td class="right">{'+' if count_change >= 0 else ''}{fi(count_change)}</td></tr>
          <tr><td>Rev / Customer</td><td class="right">${entry_rev / entry_count:.2f}M</td><td class="right">${rev_per_cust:.2f}M</td><td class="right">{'+' if rev_per_cust > entry_rev / entry_count else ''}{(rev_per_cust - entry_rev / entry_count):.2f}M</td></tr>
        </table>"""

    # Risk flags
    risk_flags = portco.get("key_risks", [])
    customer_risks = [r for r in risk_flags if any(w in r.lower() for w in ("customer", "concentration", "churn", "retention", "contract"))]

    risks_html = ""
    if customer_risks:
        risks_html = '<table><tr><th>Customer-Related Risk</th><th>Status</th></tr>'
        for r in customer_risks:
            risks_html += f'<tr><td>{r}</td><td><span class="rag rag-{rag}">{rag_label}</span></td></tr>'
        risks_html += "</table>"

    # QA section
    qa = qa_results
    qa_html = '<div class="qa-grid">'
    for check_name, label in [
        ("source_verification", "Source Verification"),
        ("structural_consistency", "Structural Consistency"),
        ("adversarial_review", "Adversarial Review"),
        ("assumption_flagging", "Assumption Flagging"),
    ]:
        check = qa.get(check_name, {})
        passed = check.get("passed", False)
        css = "pass" if passed else "warn"
        status = "PASS" if passed else "FLAG"
        qa_html += f"""<div class="qa-card {css}">
          <div class="qa-title">{label}: <span class="rag rag-{'green' if passed else 'amber'}">{status}</span></div>
          <div class="qa-detail">{check.get('notes', '')}</div>
        </div>"""
    qa_html += "</div>"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Health — {company}</title>
<style>{_build_css()}</style>
</head>
<body>
<div class="dashboard">

<div class="header">
  <h1>{company} — Customer Health Dashboard</h1>
  <div class="subtitle">{sector} | {fund} | Portfolio Monitoring</div>
  <div class="meta">CONFIDENTIAL — Northwood Capital | Period: {period} | Generated {generated_date}</div>
</div>

<div class="metric-grid">
  <div class="metric-card">
    <div class="label">Customer Count</div>
    <div class="value">{fi(cust_count) if cust_count else 'N/A'}</div>
    <div class="detail">Active accounts</div>
  </div>
  <div class="metric-card {top1_class}">
    <div class="label">Top Customer</div>
    <div class="value">{top_pct:.1f}%</div>
    <div class="detail">of total revenue</div>
  </div>
  <div class="metric-card">
    <div class="label">Rev / Customer</div>
    <div class="value">${rev_per_cust:.2f}M</div>
    <div class="detail">LTM revenue / count</div>
  </div>
  <div class="metric-card">
    <div class="label">Status</div>
    <div class="value"><span class="rag rag-{rag}">{rag_label}</span></div>
    <div class="detail">{perf.replace('_', ' ').title()}</div>
  </div>
</div>

<div class="tabs">
  <div class="tab active" data-tab="tab-kpis" onclick="showTab('tab-kpis')">Customer KPIs</div>
  <div class="tab" data-tab="tab-entry" onclick="showTab('tab-entry')">Entry Comparison</div>
  <div class="tab" data-tab="tab-risks" onclick="showTab('tab-risks')">Risks</div>
  <div class="tab" data-tab="tab-qa" onclick="showTab('tab-qa')">QA</div>
</div>

<div id="tab-kpis" class="tab-content active">
  <h2>Customer KPI Dashboard</h2>
  <table>
    <tr><th>Metric</th><th class="right">Current</th><th class="right">Threshold</th><th>RAG</th></tr>
    {kpi_rows}
  </table>
  <div class="highlight" style="margin-top:16px;font-size:13px;">
    <strong>Sector:</strong> {cm.get('sector_config', {}).get('entity_label', 'customers').title()} analysis |
    <strong>Analysis type:</strong> {cm.get('sector_config', {}).get('analysis_type', 'standard')}
  </div>
</div>

<div id="tab-entry" class="tab-content">
  {entry_comparison if entry_comparison else '<div class="highlight">Entry customer count not available in spine — comparison requires historical data.</div>'}
</div>

<div id="tab-risks" class="tab-content">
  <h2>Customer-Related Risks</h2>
  {risks_html if risks_html else '<div class="highlight">No customer-specific risks flagged in risk register.</div>'}
</div>

<div id="tab-qa" class="tab-content">
  <h2>QA Protocol Results</h2>
  {qa_html}
  <h3 style="margin-top:16px;">Data Sources</h3>
  <ul style="font-size:13px;">
    <li>Canonical data: <code>_reference/data-spine.json</code> [Spine]</li>
    <li>KPI dashboard: <code>portfolio/{portco_data['portco_slug']}/financial-reporting/kpi-dashboard.md</code></li>
    <li>Portco status: <code>portfolio/{portco_data['portco_slug']}/portco-status.md</code></li>
  </ul>
</div>

<div class="footer-bar">
  CONFIDENTIAL — Northwood Capital | Generated {generated_date} | Tool: customer_cube.py | QA protocol applied per qa-protocol.md
</div>

</div>
<script>{_build_js()}</script>
</body>
</html>"""

    return html


# ============================================================
# JSON OUTPUT
# ============================================================

def build_json_output(mode, entity_name, analytics, qa_results, raw_data=None):
    """Build JSON output dict."""
    result = {
        "mode": mode,
        "entity": entity_name,
        "generated_date": datetime.now().strftime("%Y-%m-%d"),
        "tool": "customer_cube.py",
        "confidential": "Northwood Capital",
    }

    if analytics.get("concentration"):
        c = analytics["concentration"]
        result["concentration"] = {
            "total_revenue": c["total_revenue"],
            "customer_count": c["customer_count"],
            "top_1_pct": c["top_1_pct"],
            "top_1_name": c["top_1_name"],
            "top_5_pct": c["top_5_pct"],
            "top_10_pct": c["top_10_pct"],
            "top_20_pct": c["top_20_pct"],
            "hhi": c["hhi"],
            "hhi_interpretation": c["hhi_interpretation"],
            "revenue_per_customer": c["revenue_per_customer"],
            "top_customers": c["concentration_table"][:20],
            "risk_flags": c["risk_flags"],
        }

    if analytics.get("cohort"):
        result["cohort_retention"] = {
            "nrr": analytics["cohort"]["nrr"],
            "logo_retention": analytics["cohort"]["logo_retention"],
            "cohorts": [
                {"cohort": c["cohort"], "customer_count": c["customer_count"], "retention_rate": c.get("retention_rate")}
                for c in analytics["cohort"]["cohorts"]
            ],
        }

    if analytics.get("growth"):
        g = analytics["growth"]
        result["growth_decomposition"] = {
            "grr": g["grr"],
            "nrr": g["nrr"],
            "summary": g["summary"],
            "periods": g["periods"],
        }

    if analytics.get("tenure"):
        result["tenure"] = analytics["tenure"]

    if analytics.get("segment"):
        result["segments"] = analytics["segment"]["segments"]

    if analytics.get("geography"):
        result["geography"] = analytics["geography"]["regions"]

    result["qa"] = {
        "source_verification": qa_results["source_verification"],
        "structural_consistency": qa_results["structural_consistency"],
        "adversarial_review": qa_results["adversarial_review"],
        "assumption_flagging": qa_results["assumption_flagging"],
        "warnings": qa_results["warnings"],
    }

    return result


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Northwood Capital — Customer Cube Analysis",
        usage=(
            "python tools/customer_cube.py --dd <codename> --data <csv_path>\n"
            "       python tools/customer_cube.py --portco <slug> [--period YYYY-MM]\n"
            "       [--json]"
        ),
    )

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        "--dd", metavar="CODENAME",
        help="DD mode: deal pipeline codename (e.g., everest, falcon)",
    )
    mode_group.add_argument(
        "--portco", metavar="SLUG",
        help="Portfolio mode: portco slug (e.g., meridian-business-solutions)",
    )

    parser.add_argument(
        "--data", metavar="CSV_PATH",
        help="Path to customer revenue CSV (required for --dd mode)",
    )
    parser.add_argument(
        "--period", metavar="YYYY-MM", default=None,
        help="Reporting period for portfolio mode (default: current month)",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output JSON instead of HTML dashboard",
    )

    args = parser.parse_args()

    # Validate: --dd requires --data
    if args.dd and not args.data:
        parser.error("--dd mode requires --data <csv_path>")

    exec_id = None
    try:
        # ---- DD MODE ----
        if args.dd:
            codename = args.dd.lower()
            entity_name = f"Project {codename.title()}"

            exec_id = rc_utils.log_execution_start(
                process_type="customer-cube",
                entity=entity_name,
                input_files=[args.data],
                input_params={"mode": "dd", "codename": codename},
            )

            # Parse CSV
            print(f"[customer_cube] Parsing CSV: {args.data}")
            csv_data = ingest_dd_csv(args.data)
            print(f"[customer_cube] {csv_data['total_rows']} rows, {len(csv_data['periods'])} periods, format: {csv_data['period_format']}")
            print(f"[customer_cube] Columns detected: {csv_data['columns_detected']}")

            if csv_data["warnings"]:
                for w in csv_data["warnings"][:5]:
                    print(f"[customer_cube] WARNING: {w}")

            # Run analytics
            customers = csv_data["customers"]
            periods = csv_data["periods"]

            analytics = {
                "concentration": concentration_analysis(customers, periods),
                "cohort": cohort_retention_analysis(customers, periods),
                "growth": growth_decomposition(customers, periods),
                "tenure": tenure_distribution(customers, periods),
                "segment": segment_analysis(customers, periods),
                "geography": geography_analysis(customers, periods),
            }

            # QA
            qa = run_qa_checks(
                analytics, "dd",
                input_sources=[f"CSV: {args.data}"],
                data_warnings=csv_data["warnings"],
            )

            # Output
            if args.json:
                result = build_json_output("dd", entity_name, analytics, qa, csv_data)
                output_str = json.dumps(result, indent=2)
                print(output_str)
                filename = f"customer-cube-project-{codename}-{datetime.now().strftime('%Y-%m')}-v1.json"
                filepath = rc_utils.write_output(output_str, "customer-cubes", filename)
            else:
                html = generate_html_dd(entity_name, csv_data, analytics, qa)
                filename = f"customer-cube-project-{codename}-{datetime.now().strftime('%Y-%m')}-v1.html"
                filepath = rc_utils.write_output(html, "customer-cubes", filename)

            # Log completion
            rc_utils.log_execution_complete(
                exec_id,
                output_file=str(filepath),
                output_type="json" if args.json else "html",
            )
            rc_utils.log_qa_results(
                exec_id,
                source_verification=qa["source_verification"],
                structural_consistency=qa["structural_consistency"],
                adversarial_review=qa["adversarial_review"],
                assumption_flagging=qa["assumption_flagging"],
                warnings=qa["warnings"],
                blocking_issues=qa["blocking_issues"],
            )

            conc = analytics.get("concentration")
            print(f"\n[customer_cube] Dashboard generated: {filepath}")
            print(f"  Entity: {entity_name}")
            print(f"  Customers: {conc['customer_count'] if conc else 'N/A'}")
            print(f"  Top customer: {conc['top_1_pct']:.1f}% ({conc['top_1_name']})" if conc else "  Top customer: N/A")
            print(f"  HHI: {conc['hhi']:.0f} ({conc['hhi_interpretation']})" if conc else "  HHI: N/A")
            print(f"  Risk flags: {len(conc.get('risk_flags', []))} " if conc else "  Risk flags: 0")
            print(f"  QA: {qa.get('source_verification', {}).get('passed', False) and qa.get('structural_consistency', {}).get('passed', False)}")

        # ---- PORTFOLIO MODE ----
        else:
            portco_slug = args.portco
            period = args.period or datetime.now().strftime("%Y-%m")

            exec_id = rc_utils.log_execution_start(
                process_type="customer-cube",
                entity=portco_slug,
                input_files=["data-spine.json", f"kpi-dashboard.md"],
                input_params={"mode": "portco", "portco": portco_slug, "period": period},
            )

            print(f"[customer_cube] Loading portco data: {portco_slug}")
            portco_data = assemble_portco_data(portco_slug, period)
            company = portco_data["portco"].get("portco_name", portco_slug)
            print(f"[customer_cube] {company} | Sector: {portco_data['sector']}")

            # Portfolio mode: aggregate metrics only (no transaction-level CSV)
            analytics = {
                "concentration": None,
                "cohort": None,
                "growth": None,
                "tenure": None,
                "segment": None,
                "geography": None,
            }

            qa = run_qa_checks(
                analytics, "portco",
                input_sources=["data-spine.json", "kpi-dashboard.md", "portco-status.md"],
            )

            if args.json:
                result = {
                    "mode": "portco",
                    "entity": company,
                    "portco_slug": portco_slug,
                    "period": period,
                    "customer_metrics": portco_data["customer_metrics"],
                    "sector": portco_data["sector"],
                    "qa": {
                        "source_verification": qa["source_verification"],
                        "structural_consistency": qa["structural_consistency"],
                        "adversarial_review": qa["adversarial_review"],
                        "assumption_flagging": qa["assumption_flagging"],
                        "warnings": qa["warnings"],
                    },
                    "generated_date": datetime.now().strftime("%Y-%m-%d"),
                    "tool": "customer_cube.py",
                    "confidential": "Northwood Capital",
                }
                output_str = json.dumps(result, indent=2)
                print(output_str)
                filename = f"customer-cube-{portco_slug}-{period}-v1.json"
                filepath = rc_utils.write_output(output_str, "customer-cubes", filename)
            else:
                html = generate_html_portco(portco_data, analytics, qa)
                filename = f"customer-cube-{portco_slug}-{period}-v1.html"
                filepath = rc_utils.write_output(html, "customer-cubes", filename)

            rc_utils.log_execution_complete(
                exec_id,
                output_file=str(filepath),
                output_type="json" if args.json else "html",
            )
            rc_utils.log_qa_results(
                exec_id,
                source_verification=qa["source_verification"],
                structural_consistency=qa["structural_consistency"],
                adversarial_review=qa["adversarial_review"],
                assumption_flagging=qa["assumption_flagging"],
                warnings=qa["warnings"],
                blocking_issues=qa["blocking_issues"],
            )

            cm = portco_data["customer_metrics"]
            print(f"\n[customer_cube] Dashboard generated: {filepath}")
            print(f"  Company: {company}")
            print(f"  Customer count: {cm.get('customer_count', 'N/A')}")
            print(f"  Top customer: {cm.get('top_customer_concentration_pct', 0):.1f}%")
            print(f"  Rev/customer: ${cm.get('revenue_per_customer', 0):.2f}M")

    except FileNotFoundError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        if exec_id:
            rc_utils.log_execution_failed(exec_id, str(e))
        sys.exit(1)
    except ValueError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        if exec_id:
            rc_utils.log_execution_failed(exec_id, str(e))
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Unexpected failure: {e}", file=sys.stderr)
        if exec_id:
            rc_utils.log_execution_failed(exec_id, str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
