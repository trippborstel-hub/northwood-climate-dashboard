#!/usr/bin/env python3
"""
Northwood Capital — Board Deck Generator

Generates quarterly HTML board decks for portfolio companies.
Reads from data-spine.json and portco markdown files.

Usage:
    python tools/board_deck.py meridian-business-solutions --quarter q4-2025
    python tools/board_deck.py novacare-health-partners --quarter q4-2025
    python tools/board_deck.py patriot-staffing-solutions --quarter q4-2025 --json
"""

import json
import sys
import argparse
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rc_utils


# ============================================================
# DATA ASSEMBLY
# ============================================================

def assemble_deck_data(portco_slug, quarter):
    """Assemble all data needed for board deck from multiple sources.
    
    Handles missing files gracefully — deck generates with available data.
    """
    # Parse quarter string (e.g., "q4-2025")
    parts = quarter.lower().split("-")
    q_num = int(parts[0].replace("q", ""))
    q_year = int(parts[1]) if len(parts) > 1 else 2025
    
    # Load spine data
    portco_id = portco_slug.replace("-", "_")
    try:
        portco = rc_utils.load_portco(portco_id)
    except ValueError:
        portco = rc_utils.load_portco(portco_slug)
    
    # Load supplemental files
    status_md = rc_utils.load_portco_status(portco_slug)
    kpi_md = rc_utils.load_portco_kpi_dashboard(portco_slug)
    
    # Try to load most recent monthly package
    # For Q4, try Dec, Nov, Oct
    months_in_quarter = {1: ["03", "02", "01"], 2: ["06", "05", "04"],
                         3: ["09", "08", "07"], 4: ["12", "11", "10"]}
    # Also try January of next year for Q4 (LTM reporting)
    monthly_md = None
    months_to_try = months_in_quarter.get(q_num, ["12", "11", "10"])
    for month in months_to_try:
        monthly_md = rc_utils.load_portco_monthly_package(portco_slug, f"{q_year}-{month}")
        if monthly_md:
            break
    if not monthly_md and q_num == 4:
        monthly_md = rc_utils.load_portco_monthly_package(portco_slug, f"{q_year + 1}-01")
    
    budget_md = rc_utils.load_portco_annual_budget(portco_slug, q_year + 1)
    if not budget_md:
        budget_md = rc_utils.load_portco_annual_budget(portco_slug, q_year)
    
    initiatives_md = rc_utils.load_portco_strategic_initiatives(portco_slug)
    closing_md = rc_utils.load_portco_closing_summary(portco_slug)
    
    # Resolve team
    deal_lead = rc_utils.resolve_team_member(portco.get("deal_lead", ""))
    
    # Compute derived metrics
    entry_ev = portco.get("entry_ev", 0)
    entry_ebitda = portco.get("entry_ebitda", 0)
    entry_revenue = portco.get("entry_revenue", 0)
    current_revenue = portco.get("current_revenue", 0)
    current_ebitda = portco.get("current_ebitda", 0)
    current_debt = portco.get("current_debt", 0)
    entry_debt = portco.get("entry_debt", 0)
    exit_mult = portco.get("exit_multiple_assumption", 0)
    equity_invested = portco.get("equity_invested_total", 0)
    distributions = portco.get("distributions", 0)
    
    entry_multiple = round(entry_ev / entry_ebitda, 1) if entry_ebitda else 0
    entry_margin = round(entry_ebitda / entry_revenue * 100, 1) if entry_revenue else 0
    current_margin = round(current_ebitda / current_revenue * 100, 1) if current_revenue else 0
    current_leverage = round(current_debt / current_ebitda, 1) if current_ebitda else 0
    entry_leverage = round(entry_debt / entry_ebitda, 1) if entry_ebitda else 0
    implied_ev = round(current_ebitda * exit_mult, 1) if exit_mult else 0
    equity_value = round(implied_ev - current_debt, 1) if implied_ev else 0
    total_value = round(equity_value + distributions, 1)
    gross_moic = round(total_value / equity_invested, 1) if equity_invested else 0
    
    revenue_growth = round((current_revenue / entry_revenue - 1) * 100, 0) if entry_revenue else 0
    ebitda_growth = round((current_ebitda / entry_ebitda - 1) * 100, 0) if entry_ebitda else 0
    debt_paydown = round(entry_debt - current_debt, 1)
    margin_change = round(current_margin - entry_margin, 1)
    
    # RAG status
    perf = portco.get("performance_status", "")
    if perf in ["strong", "performing_on_plan", "steady_on_plan", "performing_above_plan", "strong_exit_prep"]:
        rag = "GREEN"
    elif perf in ["below_plan"]:
        rag = "AMBER"
    elif perf in ["early_100_day_plan", "early_integration"]:
        rag = "AMBER"
    else:
        rag = "GREEN"
    
    return {
        "portco": portco,
        "portco_slug": portco_slug,
        "quarter": quarter,
        "q_num": q_num,
        "q_year": q_year,
        "deal_lead": deal_lead,
        "rag": rag,
        "status_md": status_md,
        "kpi_md": kpi_md,
        "monthly_md": monthly_md,
        "budget_md": budget_md,
        "initiatives_md": initiatives_md,
        "closing_md": closing_md,
        "metrics": {
            "entry_ev": entry_ev,
            "entry_ebitda": entry_ebitda,
            "entry_revenue": entry_revenue,
            "entry_multiple": entry_multiple,
            "entry_margin": entry_margin,
            "entry_leverage": entry_leverage,
            "entry_debt": entry_debt,
            "current_revenue": current_revenue,
            "current_ebitda": current_ebitda,
            "current_margin": current_margin,
            "current_debt": current_debt,
            "current_leverage": current_leverage,
            "implied_ev": implied_ev,
            "equity_value": equity_value,
            "total_value": total_value,
            "gross_moic": gross_moic,
            "gross_irr": portco.get("gross_irr", 0),
            "distributions": distributions,
            "exit_multiple": exit_mult,
            "revenue_growth_pct": revenue_growth,
            "ebitda_growth_pct": ebitda_growth,
            "debt_paydown": debt_paydown,
            "margin_change_bps": round(margin_change * 100),
            "headcount": portco.get("headcount", 0),
            "headcount_at_entry": portco.get("headcount_at_entry", 0),
            "customer_count": portco.get("customer_count", 0),
            "top_customer_concentration": portco.get("top_customer_concentration", 0),
            "equity_invested": equity_invested,
        },
    }


# ============================================================
# HTML GENERATION
# ============================================================

def generate_html(data):
    """Generate the complete HTML board deck."""
    p = data["portco"]
    m = data["metrics"]
    fc = rc_utils.fc
    fp = rc_utils.fp
    fm = rc_utils.fm
    fi = rc_utils.fi
    
    company = p.get("portco_name", "Portfolio Company")
    quarter_label = f"Q{data['q_num']} {data['q_year']}"
    board_date = p.get("next_board_date", "TBD")
    if board_date and board_date != "TBD":
        board_date = rc_utils.fd(board_date)
    
    rag = data["rag"]
    rag_color = {"GREEN": "#28a745", "AMBER": "#ffc107", "RED": "#dc3545"}.get(rag, "#6c757d")
    rag_bg = {"GREEN": "#d4edda", "AMBER": "#fff3cd", "RED": "#f8d7da"}.get(rag, "#e2e3e5")
    
    fund = p.get("fund", "").replace("_", " ").title()
    sector = p.get("sector_detail") or p.get("sector", "")
    acq_date = rc_utils.fd(p.get("acq_date", ""))
    
    deal_lead = data["deal_lead"]
    ceo = p.get("management_ceo", "N/A")
    cfo = p.get("management_cfo", "N/A")
    coo = p.get("management_coo", "N/A")
    
    # Check for data availability
    has_kpi = data["kpi_md"] is not None
    has_monthly = data["monthly_md"] is not None
    has_initiatives = data["initiatives_md"] is not None
    has_closing = data["closing_md"] is not None
    
    irr_display = f"~{m['gross_irr']}%" if m['gross_irr'] > 0 else "N/M"
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{company} — {quarter_label} Board Deck</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; background: #fff; color: #333; }}
  
  .slide {{
    width: 1920px; min-height: 1080px; padding: 60px 80px;
    page-break-after: always; position: relative;
    border-bottom: 3px solid #e0e0e0;
  }}
  .slide-header {{
    background: #1B365D; color: white; padding: 24px 40px;
    margin: -60px -80px 40px -80px; font-size: 28px; font-weight: 600;
  }}
  .slide-header .subtitle {{ font-size: 16px; font-weight: 400; opacity: 0.85; margin-top: 4px; }}
  
  .cover {{
    display: flex; flex-direction: column; align-items: center;
    justify-content: center; text-align: center;
    background: linear-gradient(135deg, #1B365D 0%, #2a4a7f 100%);
    color: white;
  }}
  .cover h1 {{ font-size: 48px; margin-bottom: 16px; }}
  .cover h2 {{ font-size: 32px; font-weight: 400; margin-bottom: 8px; }}
  .cover h3 {{ font-size: 24px; font-weight: 300; margin-bottom: 40px; }}
  .cover .meta {{ font-size: 18px; opacity: 0.85; line-height: 1.8; }}
  
  h2 {{ color: #1B365D; font-size: 22px; margin: 24px 0 12px 0; border-bottom: 2px solid #1B365D; padding-bottom: 6px; }}
  h3 {{ color: #1B365D; font-size: 18px; margin: 16px 0 8px 0; }}
  
  table {{ width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 15px; }}
  th {{ background: #1B365D; color: white; padding: 10px 14px; text-align: left; font-weight: 600; }}
  th.right, td.right {{ text-align: right; }}
  td {{ padding: 8px 14px; border-bottom: 1px solid #dee2e6; }}
  tr:nth-child(even) td {{ background: #f8f9fa; }}
  tr:hover td {{ background: #e9ecef; }}
  
  .metric-grid {{
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0;
  }}
  .metric-card {{
    background: #f8f9fa; border-radius: 8px; padding: 20px;
    border-left: 4px solid #1B365D;
  }}
  .metric-card .label {{ font-size: 13px; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; }}
  .metric-card .value {{ font-size: 28px; font-weight: 700; color: #1B365D; margin: 4px 0; }}
  .metric-card .detail {{ font-size: 13px; color: #495057; }}
  
  .rag {{ display: inline-block; padding: 4px 12px; border-radius: 4px; font-weight: 600; font-size: 14px; }}
  .rag-green {{ background: #d4edda; color: #155724; }}
  .rag-amber {{ background: #fff3cd; color: #856404; }}
  .rag-red {{ background: #f8d7da; color: #721c24; }}
  
  .footer {{
    position: absolute; bottom: 20px; left: 80px; right: 80px;
    font-size: 12px; color: #6c757d; border-top: 1px solid #dee2e6;
    padding-top: 8px; display: flex; justify-content: space-between;
  }}
  
  .two-col {{ display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }}
  .highlight {{ background: {rag_bg}; border-left: 4px solid {rag_color}; padding: 16px 20px; margin: 12px 0; border-radius: 4px; }}
  
  ul {{ margin: 8px 0 8px 24px; }}
  li {{ margin: 4px 0; line-height: 1.5; }}
  
  .risk-table td:nth-child(3), .risk-table td:nth-child(4) {{ text-align: center; }}
  .badge {{ display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 12px; font-weight: 600; }}
  .badge-high {{ background: #f8d7da; color: #721c24; }}
  .badge-medium {{ background: #fff3cd; color: #856404; }}
  .badge-low {{ background: #d4edda; color: #155724; }}
  .badge-new {{ background: #cce5ff; color: #004085; }}
  
  .na {{ color: #999; font-style: italic; }}
</style>
</head>
<body>

<!-- SLIDE 1: COVER -->
<div class="slide cover">
  <h1>{company}</h1>
  <h2>Board of Directors Meeting</h2>
  <h3>{quarter_label} Operating Review</h3>
  <div class="meta">
    <p>{board_date}</p>
    <p>&nbsp;</p>
    <p>CONFIDENTIAL</p>
    <p>Prepared for the Board of Directors</p>
    <p>Northwood Capital Partners — Sponsor Representative</p>
  </div>
  <div style="margin-top: 40px; font-size: 16px; opacity: 0.8;">
    <p><strong>Board Members:</strong> {deal_lead['name']}, {deal_lead['title']} — Northwood Capital</p>
    <p><strong>Management:</strong> {ceo} (CEO), {cfo} (CFO), {coo} (COO)</p>
  </div>
  <div class="footer" style="color: rgba(255,255,255,0.6); border-top-color: rgba(255,255,255,0.3);">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 1</span>
  </div>
</div>

<!-- SLIDE 2: EXECUTIVE SUMMARY -->
<div class="slide">
  <div class="slide-header">
    Executive Summary
    <div class="subtitle">{company} — {quarter_label}</div>
  </div>
  
  <div class="highlight">
    <strong>Status:</strong> <span class="rag rag-{rag.lower()}">{rag}</span>
    &nbsp;&mdash;&nbsp; {p.get('sector_detail', p.get('sector', ''))} | {fund} | Acquired {acq_date}
  </div>
  
  <div class="metric-grid">
    <div class="metric-card">
      <div class="label">LTM Revenue</div>
      <div class="value">{fc(m['current_revenue'])}</div>
      <div class="detail">Entry: {fc(m['entry_revenue'])} (+{m['revenue_growth_pct']:.0f}%)</div>
    </div>
    <div class="metric-card">
      <div class="label">LTM Adj. EBITDA</div>
      <div class="value">{fc(m['current_ebitda'])}</div>
      <div class="detail">Entry: {fc(m['entry_ebitda'])} (+{m['ebitda_growth_pct']:.0f}%)</div>
    </div>
    <div class="metric-card">
      <div class="label">Gross MOIC</div>
      <div class="value">{fm(m['gross_moic'])}</div>
      <div class="detail">IRR: {irr_display}</div>
    </div>
    <div class="metric-card">
      <div class="label">Net Leverage</div>
      <div class="value">{fm(m['current_leverage'])}</div>
      <div class="detail">Entry: {fm(m['entry_leverage'])} ({fm(m['debt_paydown'])} paydown)</div>
    </div>
  </div>
  
  <div class="two-col">
    <div>
      <h3>Key Highlights</h3>
      <ul>
        <li>Revenue growth of {m['revenue_growth_pct']:.0f}% since entry ({fc(m['entry_revenue'])} to {fc(m['current_revenue'])})</li>
        <li>EBITDA growth of {m['ebitda_growth_pct']:.0f}% ({fc(m['entry_ebitda'])} to {fc(m['current_ebitda'])})</li>
        <li>Margin: {fp(m['current_margin'])} (entry {fp(m['entry_margin'])}, {'+' if m['margin_change_bps'] >= 0 else ''}{m['margin_change_bps']} bps)</li>
        <li>Deleveraging: {fm(m['entry_leverage'])} to {fm(m['current_leverage'])} ({fc(m['debt_paydown'])} debt paydown)</li>
      </ul>
    </div>
    <div>
      <h3>Investment Thesis</h3>
      <p>{p.get('key_thesis', '[Data not available]')}</p>
      <h3 style="margin-top: 16px;">Next Board Agenda</h3>
      <p>{p.get('next_board_agenda', '[Data not available]')}</p>
    </div>
  </div>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 2</span>
  </div>
</div>

<!-- SLIDE 3: FINANCIAL RESULTS -->
<div class="slide">
  <div class="slide-header">
    Financial Results
    <div class="subtitle">Entry vs. Current Performance — LTM as of January 31, 2026</div>
  </div>
  
  <h2>Performance Summary</h2>
  <table>
    <tr>
      <th>Metric</th>
      <th class="right">At Entry</th>
      <th class="right">Current (LTM)</th>
      <th class="right">Change</th>
      <th class="right">Change %</th>
    </tr>
    <tr>
      <td>Revenue</td>
      <td class="right">{fc(m['entry_revenue'])}</td>
      <td class="right">{fc(m['current_revenue'])}</td>
      <td class="right">{fc(m['current_revenue'] - m['entry_revenue'])}</td>
      <td class="right">+{m['revenue_growth_pct']:.0f}%</td>
    </tr>
    <tr>
      <td>Adjusted EBITDA</td>
      <td class="right">{fc(m['entry_ebitda'])}</td>
      <td class="right">{fc(m['current_ebitda'])}</td>
      <td class="right">{fc(m['current_ebitda'] - m['entry_ebitda'])}</td>
      <td class="right">+{m['ebitda_growth_pct']:.0f}%</td>
    </tr>
    <tr>
      <td>EBITDA Margin</td>
      <td class="right">{fp(m['entry_margin'])}</td>
      <td class="right">{fp(m['current_margin'])}</td>
      <td class="right">{'+' if m['margin_change_bps'] >= 0 else ''}{m['margin_change_bps']} bps</td>
      <td class="right">—</td>
    </tr>
    <tr>
      <td>Total Debt</td>
      <td class="right">{fc(m['entry_debt'])}</td>
      <td class="right">{fc(m['current_debt'])}</td>
      <td class="right">{fc(m['current_debt'] - m['entry_debt'])}</td>
      <td class="right">—</td>
    </tr>
    <tr>
      <td>Net Leverage</td>
      <td class="right">{fm(m['entry_leverage'])}</td>
      <td class="right">{fm(m['current_leverage'])}</td>
      <td class="right">{fm(m['current_leverage'] - m['entry_leverage'])}</td>
      <td class="right">—</td>
    </tr>
    <tr>
      <td>Headcount</td>
      <td class="right">{fi(m['headcount_at_entry'])}</td>
      <td class="right">{fi(m['headcount'])}</td>
      <td class="right">+{fi(m['headcount'] - m['headcount_at_entry'])}</td>
      <td class="right">+{round((m['headcount'] / m['headcount_at_entry'] - 1) * 100) if m['headcount_at_entry'] else 0:.0f}%</td>
    </tr>
  </table>
  
  <h2>Returns Analysis</h2>
  <table>
    <tr>
      <th>Metric</th>
      <th class="right">Value</th>
    </tr>
    <tr><td>Entry EV</td><td class="right">{fc(m['entry_ev'])}</td></tr>
    <tr><td>Entry Multiple</td><td class="right">{fm(m['entry_multiple'])}</td></tr>
    <tr><td>Total Equity Invested</td><td class="right">{fc(m['equity_invested'])}</td></tr>
    <tr><td>Implied EV ({fm(m['exit_multiple'])} exit)</td><td class="right">{fc(m['implied_ev'])}</td></tr>
    <tr><td>Less: Current Debt</td><td class="right">{fc(-m['current_debt'])}</td></tr>
    <tr><td>Equity Value</td><td class="right">{fc(m['equity_value'])}</td></tr>
    <tr><td>Plus: Cumulative Distributions</td><td class="right">{fc(m['distributions'])}</td></tr>
    <tr><td><strong>Total Value</strong></td><td class="right"><strong>{fc(m['total_value'])}</strong></td></tr>
    <tr><td><strong>Gross MOIC</strong></td><td class="right"><strong>{fm(m['gross_moic'])}</strong></td></tr>
    <tr><td><strong>Gross IRR</strong></td><td class="right"><strong>{irr_display}</strong></td></tr>
  </table>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 3</span>
  </div>
</div>

<!-- SLIDE 4: KPI DASHBOARD -->
<div class="slide">
  <div class="slide-header">
    KPI Dashboard
    <div class="subtitle">Key Performance Indicators — LTM as of January 31, 2026</div>
  </div>
  
  <div class="metric-grid">
    <div class="metric-card" style="border-left-color: {rag_color};">
      <div class="label">Revenue</div>
      <div class="value">{fc(m['current_revenue'])}</div>
      <div class="detail">+{m['revenue_growth_pct']:.0f}% vs entry</div>
    </div>
    <div class="metric-card" style="border-left-color: {rag_color};">
      <div class="label">EBITDA Margin</div>
      <div class="value">{fp(m['current_margin'])}</div>
      <div class="detail">Entry: {fp(m['entry_margin'])}</div>
    </div>
    <div class="metric-card" style="border-left-color: #28a745;">
      <div class="label">Leverage</div>
      <div class="value">{fm(m['current_leverage'])}</div>
      <div class="detail">Entry: {fm(m['entry_leverage'])}</div>
    </div>
    <div class="metric-card" style="border-left-color: {rag_color};">
      <div class="label">Headcount</div>
      <div class="value">{fi(m['headcount'])}</div>
      <div class="detail">Entry: {fi(m['headcount_at_entry'])}</div>
    </div>
  </div>
  
  <h2>Operating KPIs</h2>
  <table>
    <tr>
      <th>KPI</th>
      <th class="right">Current</th>
      <th class="right">At Entry</th>
      <th class="right">Change</th>
      <th>RAG</th>
    </tr>
    <tr>
      <td>LTM Revenue</td>
      <td class="right">{fc(m['current_revenue'])}</td>
      <td class="right">{fc(m['entry_revenue'])}</td>
      <td class="right">+{m['revenue_growth_pct']:.0f}%</td>
      <td><span class="rag rag-green">GREEN</span></td>
    </tr>
    <tr>
      <td>LTM EBITDA</td>
      <td class="right">{fc(m['current_ebitda'])}</td>
      <td class="right">{fc(m['entry_ebitda'])}</td>
      <td class="right">+{m['ebitda_growth_pct']:.0f}%</td>
      <td><span class="rag rag-{'green' if m['ebitda_growth_pct'] > 0 else 'amber'}">{('GREEN' if m['ebitda_growth_pct'] > 0 else 'AMBER')}</span></td>
    </tr>
    <tr>
      <td>EBITDA Margin</td>
      <td class="right">{fp(m['current_margin'])}</td>
      <td class="right">{fp(m['entry_margin'])}</td>
      <td class="right">{'+' if m['margin_change_bps'] >= 0 else ''}{m['margin_change_bps']} bps</td>
      <td><span class="rag rag-{'green' if m['margin_change_bps'] >= 0 else 'amber'}">{('GREEN' if m['margin_change_bps'] >= 0 else 'AMBER')}</span></td>
    </tr>
    <tr>
      <td>Net Leverage</td>
      <td class="right">{fm(m['current_leverage'])}</td>
      <td class="right">{fm(m['entry_leverage'])}</td>
      <td class="right">{fm(m['current_leverage'] - m['entry_leverage'])}</td>
      <td><span class="rag rag-green">GREEN</span></td>
    </tr>
    <tr>
      <td>Headcount</td>
      <td class="right">{fi(m['headcount'])}</td>
      <td class="right">{fi(m['headcount_at_entry'])}</td>
      <td class="right">+{fi(m['headcount'] - m['headcount_at_entry'])}</td>
      <td><span class="rag rag-green">GREEN</span></td>
    </tr>
    <tr>
      <td>Customer Count</td>
      <td class="right">{fi(m['customer_count']) if m['customer_count'] else '<span class="na">N/A</span>'}</td>
      <td class="right">—</td>
      <td class="right">—</td>
      <td><span class="rag rag-green">GREEN</span></td>
    </tr>
    <tr>
      <td>Top Customer Concentration</td>
      <td class="right">{fp(m['top_customer_concentration']) if m['top_customer_concentration'] else '<span class="na">N/A</span>'}</td>
      <td class="right">—</td>
      <td class="right">—</td>
      <td><span class="rag rag-green">GREEN</span></td>
    </tr>
  </table>
  
  {"<p class='na' style='margin-top: 20px;'>[Detailed KPI dashboard data available in portco financial reporting]</p>" if has_kpi else "<p class='na' style='margin-top: 20px;'>[KPI dashboard data not available]</p>"}
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 4</span>
  </div>
</div>

<!-- SLIDE 5: REVENUE DETAIL -->
<div class="slide">
  <div class="slide-header">
    Revenue Detail
    <div class="subtitle">{company} — Revenue Composition and Growth</div>
  </div>
  
  <div class="two-col">
    <div>
      <h2>Revenue Growth Since Entry</h2>
      <table>
        <tr><th>Period</th><th class="right">Revenue</th><th class="right">Growth</th></tr>
        <tr><td>At Entry ({p.get('acq_date', 'N/A')[:4]})</td><td class="right">{fc(m['entry_revenue'])}</td><td class="right">—</td></tr>
        <tr><td>Current (LTM Jan 2026)</td><td class="right">{fc(m['current_revenue'])}</td><td class="right">+{m['revenue_growth_pct']:.0f}%</td></tr>
      </table>
      
      <h3>Revenue Drivers</h3>
      <ul>
        <li>Organic growth from existing operations</li>
        {"".join(f"<li>Add-on: {a}</li>" for a in p.get("add_ons_completed", []))}
      </ul>
    </div>
    <div>
      <h2>Sector Context</h2>
      <p><strong>Sector:</strong> {p.get('sector_detail', p.get('sector', 'N/A'))}</p>
      <p><strong>Customers:</strong> {fi(m['customer_count']) if m['customer_count'] else 'N/A'}</p>
      <p><strong>Top Customer:</strong> {fp(m['top_customer_concentration']) if m['top_customer_concentration'] else 'N/A'}</p>
      
      <h3 style="margin-top: 24px;">Add-On Acquisitions</h3>
      {"".join(f"<p>&#8226; {a}</p>" for a in p.get("add_ons_completed", [])) if p.get("add_ons_completed") else "<p class='na'>[No add-ons completed to date]</p>"}
    </div>
  </div>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 5</span>
  </div>
</div>

<!-- SLIDE 6: OPERATIONS -->
<div class="slide">
  <div class="slide-header">
    Operations Update
    <div class="subtitle">People, Capacity, and Operational Health</div>
  </div>
  
  <h2>Headcount Summary</h2>
  <table>
    <tr>
      <th>Metric</th>
      <th class="right">At Entry</th>
      <th class="right">Current</th>
      <th class="right">Change</th>
    </tr>
    <tr>
      <td>Total Headcount</td>
      <td class="right">{fi(m['headcount_at_entry'])}</td>
      <td class="right">{fi(m['headcount'])}</td>
      <td class="right">+{fi(m['headcount'] - m['headcount_at_entry'])}</td>
    </tr>
  </table>
  
  <h2>Management Team</h2>
  <table>
    <tr><th>Role</th><th>Name</th></tr>
    <tr><td>Chief Executive Officer</td><td>{ceo}</td></tr>
    <tr><td>Chief Financial Officer</td><td>{cfo}</td></tr>
    <tr><td>Chief Operating Officer</td><td>{coo}</td></tr>
  </table>
  
  <h2>Northwood Oversight</h2>
  <table>
    <tr><th>Role</th><th>Name</th><th>Title</th></tr>
    <tr><td>Deal Lead</td><td>{deal_lead['name']}</td><td>{deal_lead['title']}</td></tr>
  </table>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 6</span>
  </div>
</div>

<!-- SLIDE 7: STRATEGIC INITIATIVES -->
<div class="slide">
  <div class="slide-header">
    Strategic Initiatives & Value Creation
    <div class="subtitle">Progress Against Investment Thesis</div>
  </div>
  
  <h2>Investment Thesis</h2>
  <div class="highlight">
    <p>{p.get('key_thesis', '[Data not available]')}</p>
  </div>
  
  <h2>Value Creation Summary</h2>
  <table>
    <tr>
      <th>Metric</th>
      <th class="right">At Entry</th>
      <th class="right">Current</th>
      <th class="right">Value Created</th>
    </tr>
    <tr>
      <td>Revenue</td>
      <td class="right">{fc(m['entry_revenue'])}</td>
      <td class="right">{fc(m['current_revenue'])}</td>
      <td class="right">{fc(m['current_revenue'] - m['entry_revenue'])}</td>
    </tr>
    <tr>
      <td>EBITDA</td>
      <td class="right">{fc(m['entry_ebitda'])}</td>
      <td class="right">{fc(m['current_ebitda'])}</td>
      <td class="right">{fc(m['current_ebitda'] - m['entry_ebitda'])}</td>
    </tr>
    <tr>
      <td>Debt Paydown</td>
      <td class="right">{fc(m['entry_debt'])}</td>
      <td class="right">{fc(m['current_debt'])}</td>
      <td class="right">{fc(m['debt_paydown'])}</td>
    </tr>
    <tr>
      <td>Distributions</td>
      <td class="right">—</td>
      <td class="right">{fc(m['distributions'])}</td>
      <td class="right">{fc(m['distributions'])}</td>
    </tr>
    <tr>
      <td><strong>Total Value (vs. Equity Invested)</strong></td>
      <td class="right"><strong>{fc(m['equity_invested'])}</strong></td>
      <td class="right"><strong>{fc(m['total_value'])}</strong></td>
      <td class="right"><strong>{fm(m['gross_moic'])} MOIC</strong></td>
    </tr>
  </table>
  
  {f'<p style="margin-top: 16px;"><em>[Detailed strategic initiative tracking available in portco value-creation folder]</em></p>' if has_initiatives else '<p class="na" style="margin-top: 16px;">[Strategic initiatives data not available]</p>'}
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 7</span>
  </div>
</div>

<!-- SLIDE 8: RISKS -->
<div class="slide">
  <div class="slide-header">
    Risk Assessment
    <div class="subtitle">Key Risks and Mitigants</div>
  </div>
  
  <h2>Risk Register</h2>
  <table class="risk-table">
    <tr>
      <th>#</th>
      <th>Risk</th>
      <th>Severity</th>
      <th>Status</th>
    </tr>
    {"".join(f'<tr><td>{i+1}</td><td>{risk}</td><td><span class="badge badge-{"high" if i == 0 else "medium"}">{"High" if i == 0 else "Medium"}</span></td><td>Monitoring</td></tr>' for i, risk in enumerate(p.get("key_risks", ["No risks identified"])[:5]))}
  </table>
  
  <h2>Performance Status</h2>
  <div class="highlight">
    <p><strong>Overall RAG:</strong> <span class="rag rag-{rag.lower()}">{rag}</span></p>
    <p><strong>Performance:</strong> {p.get('performance_status', 'N/A').replace('_', ' ').title()}</p>
    {f"<p><strong>Below Plan Detail:</strong> {p.get('below_plan_detail', '')}</p>" if p.get('below_plan_detail') else ""}
  </div>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 8</span>
  </div>
</div>

<!-- SLIDE 9: CAPITAL STRUCTURE -->
<div class="slide">
  <div class="slide-header">
    Capital Structure & Covenant Compliance
    <div class="subtitle">Debt, Leverage, and Liquidity</div>
  </div>
  
  <h2>Debt Summary</h2>
  <table>
    <tr>
      <th>Facility</th>
      <th class="right">Original</th>
      <th class="right">Current</th>
      <th>Terms</th>
    </tr>
    <tr>
      <td>Term Loan</td>
      <td class="right">{fc(m['entry_debt'])}</td>
      <td class="right">{fc(m['current_debt'])}</td>
      <td>{p.get('debt_terms', 'N/A')}</td>
    </tr>
    <tr>
      <td>Revolver ({fc(p.get('revolver_size', 0))})</td>
      <td class="right">—</td>
      <td class="right">{fc(p.get('revolver_drawn_current', 0))}</td>
      <td>{p.get('debt_lender', 'N/A')[:40]}</td>
    </tr>
  </table>
  
  <h2>Leverage Profile</h2>
  <div class="metric-grid" style="grid-template-columns: repeat(3, 1fr);">
    <div class="metric-card" style="border-left-color: #28a745;">
      <div class="label">Entry Leverage</div>
      <div class="value">{fm(m['entry_leverage'])}</div>
      <div class="detail">Debt: {fc(m['entry_debt'])}</div>
    </div>
    <div class="metric-card" style="border-left-color: #28a745;">
      <div class="label">Current Leverage</div>
      <div class="value">{fm(m['current_leverage'])}</div>
      <div class="detail">Debt: {fc(m['current_debt'])}</div>
    </div>
    <div class="metric-card" style="border-left-color: #28a745;">
      <div class="label">Debt Paydown</div>
      <div class="value">{fc(m['debt_paydown'])}</div>
      <div class="detail">{fm(m['entry_leverage'] - m['current_leverage'])} deleveraging</div>
    </div>
  </div>
  
  <h2>Cumulative Distributions</h2>
  <p>{fc(m['distributions'])} {f"— {p.get('distributions_detail', '')}" if p.get('distributions_detail') else ""}</p>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 9</span>
  </div>
</div>

<!-- SLIDE 10: APPENDIX -->
<div class="slide">
  <div class="slide-header">
    Appendix
    <div class="subtitle">Entry Terms, Fund Context, and Data Sources</div>
  </div>
  
  <h2>Entry Terms</h2>
  <table>
    <tr><th>Metric</th><th class="right">Value</th></tr>
    <tr><td>Acquisition Date</td><td class="right">{acq_date}</td></tr>
    <tr><td>Enterprise Value</td><td class="right">{fc(m['entry_ev'])}</td></tr>
    <tr><td>Entry Multiple</td><td class="right">{fm(m['entry_multiple'])}</td></tr>
    <tr><td>LTM Revenue (at entry)</td><td class="right">{fc(m['entry_revenue'])}</td></tr>
    <tr><td>LTM EBITDA (at entry)</td><td class="right">{fc(m['entry_ebitda'])}</td></tr>
    <tr><td>Total Equity Invested</td><td class="right">{fc(m['equity_invested'])}</td></tr>
    <tr><td>Fund Equity (80%)</td><td class="right">{fc(p.get('equity_invested_fund', 0))}</td></tr>
    <tr><td>Management Rollover (20%)</td><td class="right">{fc(p.get('equity_invested_mgmt', 0))}</td></tr>
    <tr><td>Entry Debt</td><td class="right">{fc(m['entry_debt'])}</td></tr>
    <tr><td>Entry Leverage</td><td class="right">{fm(m['entry_leverage'])}</td></tr>
    <tr><td>Transaction Type</td><td class="right">{p.get('transaction_type', 'N/A')[:60]}</td></tr>
  </table>
  
  <h2>Fund Context</h2>
  <table>
    <tr><th>Metric</th><th class="right">Value</th></tr>
    <tr><td>Fund</td><td class="right">{fund}</td></tr>
    <tr><td>Sector</td><td class="right">{p.get('sector', 'N/A')}</td></tr>
    <tr><td>Sector Detail</td><td class="right">{p.get('sector_detail', 'N/A')}</td></tr>
  </table>
  
  <h2>Data Sources</h2>
  <ul>
    <li>Canonical data: <code>_reference/data-spine.json</code> [Spine]</li>
    <li>Portfolio status: <code>portfolio/{data['portco_slug']}/portco-status.md</code> {"[Available]" if data['status_md'] else "[Not available]"}</li>
    <li>KPI dashboard: {"[Available]" if has_kpi else "[Not available]"}</li>
    <li>Monthly financial package: {"[Available]" if has_monthly else "[Not available]"}</li>
    <li>Annual budget: {"[Available]" if data['budget_md'] else "[Not available]"}</li>
    <li>Strategic initiatives: {"[Available]" if has_initiatives else "[Not available]"}</li>
    <li>Closing summary: {"[Available]" if has_closing else "[Not available]"}</li>
  </ul>
  
  <p style="margin-top: 24px; font-size: 13px; color: #6c757d;">
    Generated: {datetime.now().strftime('%B %d, %Y')} | Tool: board_deck.py | 
    All figures per deliverable-standards.md precision rules | 
    QA protocol applied per qa-protocol.md
  </p>
  
  <div class="footer">
    <span>CONFIDENTIAL — Northwood Capital</span>
    <span>Page 10</span>
  </div>
</div>

</body>
</html>"""
    
    return html


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Northwood Capital — Board Deck Generator",
        usage="python tools/board_deck.py <portco_slug> --quarter <q#-yyyy> [--json]"
    )
    parser.add_argument("portco_slug", help="Portfolio company slug (e.g., meridian-business-solutions)")
    parser.add_argument("--quarter", required=True, help="Quarter (e.g., q4-2025)")
    parser.add_argument("--json", action="store_true", help="Output JSON data instead of HTML")
    
    args = parser.parse_args()
    
    # Assemble data
    data = assemble_deck_data(args.portco_slug, args.quarter)
    
    if args.json:
        # Output JSON summary
        result = {
            "portco": args.portco_slug,
            "quarter": args.quarter,
            "rag_status": data["rag"],
            "metrics": data["metrics"],
            "data_availability": {
                "status_md": data["status_md"] is not None,
                "kpi_md": data["kpi_md"] is not None,
                "monthly_md": data["monthly_md"] is not None,
                "budget_md": data["budget_md"] is not None,
                "initiatives_md": data["initiatives_md"] is not None,
                "closing_md": data["closing_md"] is not None,
            },
            "meta": {
                "generated_date": datetime.now().strftime("%Y-%m-%d"),
                "tool": "board_deck.py",
                "confidential": "Northwood Capital",
            },
        }
        print(json.dumps(result, indent=2))
    else:
        # Generate HTML
        html = generate_html(data)
        
        # Save to file
        slug = args.portco_slug
        quarter = args.quarter
        filename = f"board-deck-{slug}-{quarter}-v1.html"
        filepath = rc_utils.write_output(html, "board-decks", filename)
        
        print(f"Board deck generated: {filepath}")
        print(f"  Company: {data['portco'].get('portco_name', 'N/A')}")
        print(f"  Quarter: Q{data['q_num']} {data['q_year']}")
        print(f"  RAG Status: {data['rag']}")
        print(f"  MOIC: {rc_utils.fm(data['metrics']['gross_moic'])}")
        print(f"  Slides: 10")
        print(f"  Data sources: {sum(1 for v in [data['status_md'], data['kpi_md'], data['monthly_md'], data['budget_md'], data['initiatives_md'], data['closing_md']] if v is not None)}/6 available")


if __name__ == "__main__":
    main()
