#!/usr/bin/env python3
"""
Northwood Capital — LBO Model

Parameterized, re-runnable model for deal-level returns analysis.
Reads from data-spine.json. Data access abstracted for future Supabase migration.

Usage:
    python tools/lbo_model.py orion                    # Base case
    python tools/lbo_model.py orion --sensitivity      # + sensitivity tables
    python tools/lbo_model.py orion --scenarios         # + scenario analysis
    python tools/lbo_model.py orion --all               # Full output
    python tools/lbo_model.py orion --json              # Machine-readable output
"""

import json
import sys
import os
from pathlib import Path


# ============================================================
# DATA ACCESS LAYER
# Swap this function to migrate from JSON to Supabase.
# Replace JSON reads with SQL queries; model logic unchanged.
# ============================================================

def load_deal_assumptions(deal_id, base_dir=None):
    """Load LBO assumptions for a deal from data spine.

    Abstraction layer: to migrate to Supabase, modify only this function.
    """
    if base_dir is None:
        base_dir = Path(__file__).resolve().parent.parent

    spine_path = base_dir / "_reference" / "data-spine.json"
    with open(spine_path) as f:
        spine = json.load(f)

    # Find deal in pipeline_active
    deal = spine.get("pipeline_active", {}).get(deal_id)
    if not deal:
        # Check portfolio_companies
        deal = spine.get("portfolio_companies", {}).get(deal_id)
    if not deal:
        raise ValueError(f"Deal '{deal_id}' not found in data spine")

    # LBO assumptions stored under lbo_assumptions key
    assumptions = deal.get("lbo_assumptions")
    if not assumptions:
        raise ValueError(
            f"Deal '{deal_id}' has no lbo_assumptions in data spine. "
            f"Add time-series data to pipeline_active.{deal_id}.lbo_assumptions"
        )

    # Attach deal metadata for display
    assumptions["_deal"] = {
        "codename": deal.get("codename", deal_id),
        "target_name": deal.get("target_name", "N/A"),
        "sector": deal.get("sector", "N/A"),
        "deal_lead": deal.get("deal_lead", "N/A"),
        "stage": deal.get("stage", "N/A"),
    }

    return assumptions


# ============================================================
# IRR CALCULATION
# ============================================================

def compute_irr(cashflows, guess=0.15, max_iter=1000, tol=1e-8):
    """Newton-Raphson IRR solver.

    Args:
        cashflows: [CF0, CF1, ..., CFn] where CF0 is typically negative.

    Returns:
        IRR as decimal (0.22 = 22%).
    """
    rate = guess
    for _ in range(max_iter):
        npv = sum(cf / (1 + rate) ** t for t, cf in enumerate(cashflows))
        dnpv = sum(-t * cf / (1 + rate) ** (t + 1) for t, cf in enumerate(cashflows))
        if abs(dnpv) < 1e-12:
            break
        new_rate = rate - npv / dnpv
        if abs(new_rate - rate) < tol:
            return new_rate
        rate = new_rate
    return rate


# ============================================================
# LBO MODEL ENGINE
# ============================================================

def run_lbo(assumptions):
    """Execute full LBO model from structured assumptions.

    Returns dict with: sources_uses, entry, annual, exit, returns, value_bridge
    """
    entry = assumptions["entry"]
    debt_params = assumptions["debt"]
    operating = assumptions["operating"]
    exit_params = assumptions["exit"]
    projections = operating["projections"]
    hold_period = exit_params["hold_period"]

    # ---- Entry ----
    ev = entry["ev"]
    total_debt = entry["total_debt"]
    total_equity = entry["total_equity"]
    fund_pct = entry.get("fund_pct", 0.80)
    fund_equity = total_equity * fund_pct
    mgmt_equity = total_equity * (1.0 - fund_pct)
    txn_fees = entry.get("transaction_fees", 0.0)
    entry_ebitda = entry["ebitda"]
    entry_revenue = entry["revenue"]
    entry_multiple = ev / entry_ebitda
    entry_leverage = total_debt / entry_ebitda

    # ---- Sources & Uses ----
    sources_uses = {
        "uses": {
            "enterprise_value": ev,
            "transaction_fees": txn_fees,
            "total_uses": ev + txn_fees,
        },
        "sources": {
            "senior_debt": total_debt,
            "fund_equity": round(fund_equity, 1),
            "management_rollover": round(mgmt_equity, 1),
            "total_equity": total_equity,
            "total_sources": total_debt + total_equity + txn_fees,
        },
    }

    # ---- Debt Schedule ----
    all_in_rate = debt_params["all_in_rate"]
    annual_amort_pct = debt_params.get("annual_amort_pct", 0.01)
    base_mandatory_amort = total_debt * annual_amort_pct

    # ---- Annual Projection Loop ----
    annual = []
    debt_balance = total_debt
    cumulative_paydown = 0.0
    excess_cash = 0.0

    for proj in projections:
        yr = proj["year"]
        revenue = proj["revenue"]
        ebitda = proj["ebitda"]

        # Prior year revenue for NWC calc
        if yr == 1:
            prev_revenue = entry_revenue
        else:
            prev_revenue = projections[yr - 2]["revenue"]

        # Cash interest on BOY debt balance
        cash_interest = debt_balance * all_in_rate

        # D&A for tax calculation
        da = revenue * operating.get("da_pct_revenue", 0.025)

        # Cash taxes
        ebt = ebitda - cash_interest - da
        cash_taxes = max(0.0, ebt * operating["tax_rate"])

        # Capex
        maint_capex = revenue * operating["maintenance_capex_pct"]
        growth_capex = proj.get("growth_capex", 0.0)

        # Net working capital change
        nwc_change = (revenue - prev_revenue) * operating["nwc_pct_revenue"]

        # Mandatory amortization (capped at remaining debt)
        mand_amort = min(base_mandatory_amort, debt_balance)

        # Levered FCF (after mandatory amort)
        levered_fcf = (ebitda - cash_interest - cash_taxes
                       - maint_capex - growth_capex - nwc_change - mand_amort)

        # Voluntary prepayment from excess FCF
        remaining_debt_after_mand = debt_balance - mand_amort
        voluntary_paydown = 0.0
        if levered_fcf > 0 and remaining_debt_after_mand > 0:
            voluntary_paydown = min(levered_fcf, remaining_debt_after_mand)

        total_paydown = mand_amort + voluntary_paydown
        debt_balance_eoy = debt_balance - total_paydown
        cumulative_paydown += total_paydown

        # Excess cash accumulation (FCF beyond debt paydown)
        period_excess = levered_fcf - voluntary_paydown
        if period_excess > 0:
            excess_cash += period_excess

        annual.append({
            "year": yr,
            "revenue": round(revenue, 1),
            "revenue_growth": round((revenue / prev_revenue - 1) * 100, 1),
            "ebitda": round(ebitda, 1),
            "ebitda_margin": round(ebitda / revenue * 100, 1),
            "cash_interest": round(cash_interest, 1),
            "cash_taxes": round(cash_taxes, 1),
            "maintenance_capex": round(maint_capex, 1),
            "growth_capex": round(growth_capex, 1),
            "nwc_change": round(nwc_change, 1),
            "mandatory_amort": round(mand_amort, 1),
            "levered_fcf": round(levered_fcf, 1),
            "debt_balance_eoy": round(debt_balance_eoy, 1),
            "cumulative_paydown": round(cumulative_paydown, 1),
        })

        debt_balance = debt_balance_eoy

    # ---- Exit ----
    exit_ebitda = annual[-1]["ebitda"]
    exit_multiple = exit_params["exit_multiple"]
    exit_ev = exit_ebitda * exit_multiple
    net_debt_at_exit = annual[-1]["debt_balance_eoy"] - excess_cash
    exit_equity = exit_ev - net_debt_at_exit

    # ---- Returns ----
    gross_moic = exit_equity / total_equity
    irr_cashflows = [-total_equity] + [0.0] * (hold_period - 1) + [exit_equity]
    gross_irr = compute_irr(irr_cashflows)

    # ---- Value Creation Bridge ----
    ebitda_growth_value = (exit_ebitda - entry_ebitda) * entry_multiple
    multiple_expansion_value = (exit_multiple - entry_multiple) * exit_ebitda
    deleverage_value = cumulative_paydown + excess_cash
    total_drivers = ebitda_growth_value + multiple_expansion_value + deleverage_value

    return {
        "sources_uses": sources_uses,
        "entry": {
            "ev": ev,
            "ebitda": entry_ebitda,
            "revenue": entry_revenue,
            "multiple": round(entry_multiple, 1),
            "total_debt": total_debt,
            "leverage": round(entry_leverage, 1),
            "total_equity": total_equity,
            "fund_equity": round(fund_equity, 1),
            "mgmt_equity": round(mgmt_equity, 1),
        },
        "annual": annual,
        "exit": {
            "ebitda": round(exit_ebitda, 1),
            "multiple": exit_multiple,
            "ev": round(exit_ev, 1),
            "net_debt": round(net_debt_at_exit, 1),
            "equity_value": round(exit_equity, 1),
            "excess_cash": round(excess_cash, 1),
        },
        "returns": {
            "gross_moic": round(gross_moic, 1),
            "gross_moic_precise": round(gross_moic, 2),
            "gross_irr": round(gross_irr * 100, 1),
            "gross_irr_display": f"~{round(gross_irr * 100)}%",
        },
        "value_bridge": {
            "ebitda_growth": {
                "value": round(ebitda_growth_value, 1),
                "pct": round(ebitda_growth_value / total_drivers * 100) if total_drivers else 0,
            },
            "multiple_expansion": {
                "value": round(multiple_expansion_value, 1),
                "pct": round(multiple_expansion_value / total_drivers * 100) if total_drivers else 0,
            },
            "deleveraging": {
                "value": round(deleverage_value, 1),
                "pct": round(deleverage_value / total_drivers * 100) if total_drivers else 0,
            },
        },
    }


# ============================================================
# SENSITIVITY ANALYSIS
# ============================================================

def sensitivity_table(base_result, assumptions, exit_ebitda_range, exit_multiple_range):
    """MOIC and IRR sensitivity: exit EBITDA x exit multiple.

    Operating period cash flows (and thus net debt at exit) held constant.
    Only exit valuation varies.
    """
    total_equity = assumptions["entry"]["total_equity"]
    hold_period = assumptions["exit"]["hold_period"]
    net_debt = base_result["exit"]["net_debt"]

    moic_matrix = []
    irr_matrix = []

    for exit_mult in exit_multiple_range:
        moic_row = []
        irr_row = []
        for exit_eb in exit_ebitda_range:
            exit_ev = exit_eb * exit_mult
            exit_eq = exit_ev - net_debt
            moic = round(exit_eq / total_equity, 1)
            cf = [-total_equity] + [0.0] * (hold_period - 1) + [exit_eq]
            irr = round(compute_irr(cf) * 100)
            moic_row.append(moic)
            irr_row.append(irr)
        moic_matrix.append(moic_row)
        irr_matrix.append(irr_row)

    return {
        "exit_ebitda_range": exit_ebitda_range,
        "exit_multiple_range": exit_multiple_range,
        "moic_matrix": moic_matrix,
        "irr_matrix": irr_matrix,
    }


# ============================================================
# SCENARIO ANALYSIS
# ============================================================

def run_scenarios(base_assumptions):
    """Run base, downside, and upside scenarios.

    Scenarios are defined relative to the base case within the assumptions.
    """
    scenarios = base_assumptions.get("scenarios", {})
    results = {"base": run_lbo(base_assumptions)}

    for name, scenario in scenarios.items():
        modified = json.loads(json.dumps(base_assumptions))
        # Override operating projections
        if "projections" in scenario:
            modified["operating"]["projections"] = scenario["projections"]
        # Override exit assumptions
        if "exit_multiple" in scenario:
            modified["exit"]["exit_multiple"] = scenario["exit_multiple"]
        results[name] = run_lbo(modified)

    return results


# ============================================================
# OUTPUT FORMATTING
# ============================================================

def fc(val, d=1):
    """Format currency in millions."""
    if abs(val) < 0.05:
        return f"$0.0M"
    if val < 0:
        return f"(${abs(val):,.{d}f}M)"
    return f"${val:,.{d}f}M"

def fp(val, d=1):
    """Format percentage."""
    return f"{val:.{d}f}%"

def fm(val, d=1):
    """Format multiple."""
    return f"{val:.{d}f}x"


def print_results(result, assumptions, show_sensitivity=False, show_scenarios=False):
    """Print formatted LBO model output."""
    deal = assumptions.get("_deal", {})
    e = result["entry"]
    su = result["sources_uses"]
    ann = result["annual"]
    ex = result["exit"]
    ret = result["returns"]
    vb = result["value_bridge"]

    W = 80
    print("=" * W)
    print(f"LBO MODEL — PROJECT {deal.get('codename', '').upper()}")
    print(f"Target: {deal.get('target_name', 'N/A')}")
    print(f"Sector: {deal.get('sector', 'N/A')}")
    print(f"Stage: {deal.get('stage', 'N/A')}")
    print(f"Date: February 2026")
    print(f"Status: Pre-exclusivity base case — subject to confirmatory DD")
    print("=" * W)

    # Entry
    print(f"\nENTRY ASSUMPTIONS")
    print("-" * 50)
    rows = [
        ("Enterprise Value", fc(e["ev"])),
        ("Entry Multiple", fm(e["multiple"])),
        ("LTM Adjusted EBITDA", fc(e["ebitda"])),
        ("LTM Revenue", fc(e["revenue"])),
        ("LTM EBITDA Margin", fp(e["ebitda"] / e["revenue"] * 100)),
        ("Total Debt at Entry", fc(e["total_debt"])),
        ("Leverage at Entry", fm(e["leverage"])),
        ("Total Equity", fc(e["total_equity"])),
        ("  Fund Equity (80%)", fc(e["fund_equity"])),
        ("  Mgmt Rollover (20%)", fc(e["mgmt_equity"])),
    ]
    for label, val in rows:
        print(f"  {label:<28} {val}")

    # Sources & Uses
    print(f"\nSOURCES & USES")
    print("-" * 50)
    print(f"  Uses:")
    print(f"    Enterprise Value         {fc(su['uses']['enterprise_value'])}")
    print(f"    Transaction Fees         {fc(su['uses']['transaction_fees'])}")
    print(f"    Total Uses               {fc(su['uses']['total_uses'])}")
    print(f"  Sources:")
    print(f"    Senior Debt              {fc(su['sources']['senior_debt'])}")
    print(f"    Fund Equity              {fc(su['sources']['fund_equity'])}")
    print(f"    Management Rollover      {fc(su['sources']['management_rollover'])}")
    print(f"    Total Sources            {fc(su['sources']['total_sources'])}")

    # Operating Projections
    n = len(ann)
    cw = 10  # column width
    print(f"\nOPERATING PROJECTIONS")
    print("-" * (28 + cw * n))
    hdr = f"  {'Metric':<26}" + "".join(f"{'Year ' + str(a['year']):>{cw}}" for a in ann)
    print(hdr)
    print("  " + "-" * (26 + cw * n))

    def row(label, key, fmt_fn):
        r = f"  {label:<26}"
        for a in ann:
            r += f"{fmt_fn(a[key]):>{cw}}"
        print(r)

    row("Revenue", "revenue", fc)
    row("Revenue Growth", "revenue_growth", fp)
    row("Adjusted EBITDA", "ebitda", fc)
    row("EBITDA Margin", "ebitda_margin", fp)

    # Cash Flow
    print(f"\nCASH FLOW BUILD")
    print("-" * (28 + cw * n))
    print(hdr)
    print("  " + "-" * (26 + cw * n))

    row("Adjusted EBITDA", "ebitda", fc)
    row("(-) Cash Interest", "cash_interest", lambda x: fc(-x))
    row("(-) Cash Taxes", "cash_taxes", lambda x: fc(-x))
    row("(-) Maint. Capex", "maintenance_capex", lambda x: fc(-x))
    row("(-) Growth Capex", "growth_capex", lambda x: fc(-x))
    row("(-) NWC Change", "nwc_change", lambda x: fc(-x))
    row("(-) Mandatory Amort.", "mandatory_amort", lambda x: fc(-x))
    print("  " + "-" * (26 + cw * n))
    row("Levered FCF", "levered_fcf", fc)
    print()
    row("Cumul. Debt Paydown", "cumulative_paydown", fc)
    row("Debt Balance (EOY)", "debt_balance_eoy", fc)

    # Exit & Returns
    print(f"\nEXIT ANALYSIS — BASE CASE ({assumptions['exit']['hold_period']}-YEAR HOLD)")
    print("-" * 50)
    rows = [
        ("Exit EBITDA", fc(ex["ebitda"])),
        ("Exit Multiple", fm(ex["multiple"])),
        ("Exit Enterprise Value", fc(ex["ev"])),
        ("(-) Net Debt at Exit", fc(ex["net_debt"])),
        ("Exit Equity Value", fc(ex["equity_value"])),
        ("", ""),
        ("Entry Equity", fc(ret.get("total_equity_invested", e["total_equity"]))),
        ("Gross MOIC", fm(ret["gross_moic"])),
        ("Gross IRR", ret["gross_irr_display"]),
    ]
    for label, val in rows:
        if label:
            print(f"  {label:<28} {val}")
        else:
            print(f"  {'─' * 45}")

    # Value Bridge
    print(f"\nVALUE CREATION BRIDGE")
    print("-" * 50)
    print(f"  {'Driver':<28}{'Value':>10}{'% Total':>10}")
    print(f"  {'─' * 48}")
    for driver_key, data in vb.items():
        label = driver_key.replace("_", " ").title()
        print(f"  {label:<28}{fc(data['value']):>10}{str(data['pct']) + '%':>10}")

    # Sensitivity
    if show_sensitivity:
        base_ebitda = ex["ebitda"]
        base_mult = ex["multiple"]
        ebitda_range = [
            round(base_ebitda * 0.80, 1),
            round(base_ebitda * 0.90, 1),
            base_ebitda,
            round(base_ebitda * 1.10, 1),
            round(base_ebitda * 1.20, 1),
        ]
        mult_range = [
            base_mult - 2.0,
            base_mult - 1.0,
            base_mult - 0.5,
            base_mult,
            base_mult + 0.5,
            base_mult + 1.0,
        ]
        sens = sensitivity_table(result, assumptions, ebitda_range, mult_range)
        print_sensitivity_tables(sens, base_ebitda, base_mult)

    # Scenarios
    if show_scenarios and "scenarios" in assumptions:
        scenario_results = run_scenarios(assumptions)
        print_scenario_summary(scenario_results, assumptions)

    print("\n" + "=" * W)
    print("Northwood Capital | Chicago, IL | Confidential")
    print(f"Model validated: MOIC {ret['gross_moic_precise']}x | IRR {ret['gross_irr']:.1f}%")
    print("=" * W)


def print_sensitivity_tables(sens, base_ebitda, base_mult):
    """Print MOIC and IRR sensitivity matrices."""
    eb_range = sens["exit_ebitda_range"]
    m_range = sens["exit_multiple_range"]
    cw = 10

    for matrix_name, matrix in [("GROSS MOIC", sens["moic_matrix"]),
                                  ("GROSS IRR", sens["irr_matrix"])]:
        unit = "x" if "MOIC" in matrix_name else "%"
        print(f"\nRETURNS SENSITIVITY — {matrix_name}")
        print("-" * (18 + cw * len(eb_range)))

        col_label = "Mult \\ EBITDA"
        hdr = f"  {col_label:<16}"
        for eb in eb_range:
            marker = " *" if abs(eb - base_ebitda) < 0.05 else ""
            hdr += f"{'$' + str(eb) + 'M' + marker:>{cw}}"
        print(hdr)
        print("  " + "-" * (16 + cw * len(eb_range)))

        for i, mult in enumerate(m_range):
            marker = " *" if abs(mult - base_mult) < 0.05 else ""
            r = f"  {str(mult) + 'x' + marker:<16}"
            for j, val in enumerate(matrix[i]):
                is_base = (abs(mult - base_mult) < 0.05 and
                           abs(eb_range[j] - base_ebitda) < 0.05)
                if "MOIC" in matrix_name:
                    cell = f"[{val:.1f}x]" if is_base else f"{val:.1f}x"
                else:
                    cell = f"[~{val:.0f}%]" if is_base else f"~{val:.0f}%"
                r += f"{cell:>{cw}}"
            print(r)

        print(f"\n  * = base case   [ ] = base case intersection")


def print_scenario_summary(scenario_results, assumptions):
    """Print scenario comparison table."""
    print(f"\nSCENARIO ANALYSIS")
    print("-" * 70)
    print(f"  {'Metric':<28}{'Base':>12}{'Downside':>12}{'Upside':>12}")
    print(f"  {'─' * 64}")

    scenarios_config = assumptions.get("scenarios", {})

    for name, label in [("base", "Base"), ("downside", "Downside"), ("upside", "Upside")]:
        if name not in scenario_results:
            continue

    base_r = scenario_results.get("base", {})
    down_r = scenario_results.get("downside", {})
    up_r = scenario_results.get("upside", {})

    if not (base_r and down_r and up_r):
        return

    metrics = [
        ("Exit EBITDA", lambda r: fc(r["exit"]["ebitda"])),
        ("Exit Multiple", lambda r: fm(r["exit"]["multiple"])),
        ("Exit EV", lambda r: fc(r["exit"]["ev"])),
        ("Exit Equity", lambda r: fc(r["exit"]["equity_value"])),
        ("Gross MOIC", lambda r: fm(r["returns"]["gross_moic"])),
        ("Gross IRR", lambda r: r["returns"]["gross_irr_display"]),
    ]
    for label, fn in metrics:
        print(f"  {label:<28}{fn(base_r):>12}{fn(down_r):>12}{fn(up_r):>12}")

    # Scenario narratives
    for name in ["downside", "upside"]:
        if name in scenarios_config and "narrative" in scenarios_config[name]:
            print(f"\n  {name.title()}: {scenarios_config[name]['narrative']}")


# ============================================================
# MAIN
# ============================================================

def main():
    args = sys.argv[1:]
    if not args:
        print("Usage: python lbo_model.py <deal_id> [--sensitivity] [--scenarios] [--all] [--json]")
        print("\nAvailable deals (with lbo_assumptions in data spine):")
        print("  orion    — CloudFirst Technologies (IC memo stage)")
        print("  everest  — Specialty Chemical Solutions Inc. (LOI submitted)")
        sys.exit(1)

    deal_id = args[0]
    show_sens = "--sensitivity" in args or "--all" in args
    show_scenarios = "--scenarios" in args or "--all" in args
    output_json = "--json" in args

    # Load and run
    assumptions = load_deal_assumptions(deal_id)
    result = run_lbo(assumptions)

    if output_json:
        print(json.dumps(result, indent=2))
    else:
        print_results(result, assumptions,
                      show_sensitivity=show_sens,
                      show_scenarios=show_scenarios)


if __name__ == "__main__":
    main()
