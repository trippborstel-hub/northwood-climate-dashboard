#!/usr/bin/env python3
"""
Northwood Capital — Comparable Company Analysis

Evaluates deal valuations against transaction and trading comparables.
Reads from data-spine.json (pipeline) and comp-data.json (comparables).

Usage:
    python tools/comp_analysis.py falcon                # Base output
    python tools/comp_analysis.py falcon --detailed     # + comp descriptions
    python tools/comp_analysis.py orion --json          # Machine-readable
"""

import json
import sys
import argparse
from pathlib import Path
from statistics import median, mean

# Add tools directory to path for rc_utils import
sys.path.insert(0, str(Path(__file__).resolve().parent))
import rc_utils


# ============================================================
# COMP ANALYSIS ENGINE
# ============================================================

def gather_comps(deal, comp_data):
    """Gather transaction and trading comps for a deal's sector(s).
    
    Maps deal sector to comp-data keys, collects all comps,
    sorts transaction comps by date (most recent first).
    """
    sector_keys = rc_utils.map_sector_to_comp_keys(deal.get("sector", ""))
    sectors = comp_data.get("sectors", {})
    
    txn_comps = []
    trading_comps = []
    
    for key in sector_keys:
        sector_data = sectors.get(key, {})
        txn_comps.extend(sector_data.get("transaction_comps", []))
        trading_comps.extend(sector_data.get("trading_comps", []))
    
    # Deduplicate by target/company name
    seen_txn = set()
    unique_txn = []
    for c in txn_comps:
        name = c.get("target", "")
        if name not in seen_txn:
            seen_txn.add(name)
            unique_txn.append(c)
    
    seen_trading = set()
    unique_trading = []
    for c in trading_comps:
        name = c.get("company", "")
        if name not in seen_trading:
            seen_trading.add(name)
            unique_trading.append(c)
    
    # Sort transaction comps by date descending, take up to 8
    unique_txn.sort(key=lambda x: x.get("date", ""), reverse=True)
    unique_txn = unique_txn[:8]
    
    return unique_txn, unique_trading


def compute_stats(values):
    """Compute low, median, mean, high for a list of numbers."""
    if not values:
        return {"low": None, "median": None, "mean": None, "high": None}
    return {
        "low": min(values),
        "median": median(values),
        "mean": mean(values),
        "high": max(values),
    }


def analyze_valuation(deal, txn_stats, trading_stats):
    """Assess where deal valuation falls vs comps and guardrails."""
    ebitda = deal.get("ebitda_adjusted", 0)
    ev_low = deal.get("ev_range_low", 0)
    ev_high = deal.get("ev_range_high", 0)
    
    if ebitda and ebitda > 0:
        mult_low = round(ev_low / ebitda, 1)
        mult_high = round(ev_high / ebitda, 1)
        mult_mid = round((mult_low + mult_high) / 2, 1)
    else:
        mult_low = mult_high = mult_mid = None
    
    # Sector guardrails
    sector_keys = rc_utils.map_sector_to_comp_keys(deal.get("sector", ""))
    guardrail = None
    for key in sector_keys:
        if key in rc_utils.SECTOR_VALUATION_RANGES:
            guardrail = rc_utils.SECTOR_VALUATION_RANGES[key]
            guardrail["sector"] = key
            break
    if not guardrail:
        guardrail = {"low": 7.0, "high": 10.0, "sector": "General", "note": "Default range"}
    
    # Positioning vs comps
    txn_median = txn_stats.get("ev_ebitda", {}).get("median")
    trading_median = trading_stats.get("ev_ebitda", {}).get("median")
    
    positioning = "N/A"
    if mult_mid and txn_median:
        diff = mult_mid - txn_median
        if abs(diff) < 0.3:
            positioning = "In-line with transaction comp median"
        elif diff > 0:
            positioning = f"{abs(diff):.1f}x above transaction comp median"
        else:
            positioning = f"{abs(diff):.1f}x below transaction comp median"
    
    # Guardrail checks
    checks = []
    if mult_high and guardrail:
        within_range = mult_low >= guardrail["low"] - 0.5 and mult_high <= guardrail["high"] + 0.5
        checks.append({
            "test": "Multiple within sector range",
            "result": "PASS" if within_range else "FLAG",
            "detail": f"{rc_utils.fm(mult_low)} - {rc_utils.fm(mult_high)} vs {rc_utils.fm(guardrail['low'])} - {rc_utils.fm(guardrail['high'])} ({guardrail['sector']})"
        })
    
    if mult_high:
        below_ceiling = mult_high <= rc_utils.HARD_CEILING_MULTIPLE
        checks.append({
            "test": "Multiple below hard ceiling",
            "result": "PASS" if below_ceiling else "FLAG",
            "detail": f"{rc_utils.fm(mult_high)} vs {rc_utils.fm(rc_utils.HARD_CEILING_MULTIPLE)}"
        })
    
    return {
        "mult_low": mult_low,
        "mult_high": mult_high,
        "mult_mid": mult_mid,
        "txn_median": txn_median,
        "trading_median": trading_median,
        "positioning": positioning,
        "guardrail": guardrail,
        "checks": checks,
    }


# ============================================================
# OUTPUT FORMATTING
# ============================================================

def print_results(deal, txn_comps, trading_comps, txn_stats, trading_stats,
                  valuation, detailed=False):
    """Print formatted comp analysis output."""
    fc = rc_utils.fc
    fp = rc_utils.fp
    fm = rc_utils.fm
    
    codename = deal.get("codename", "UNKNOWN")
    team = rc_utils.resolve_deal_team(deal)
    lead_name = team[0]["name"] if team else "N/A"
    
    ebitda = deal.get("ebitda_adjusted", 0)
    revenue = deal.get("revenue_reported", 0)
    margin = round(ebitda / revenue * 100, 1) if revenue else 0
    
    W = 80
    print("=" * W)
    print(f"COMPARABLE COMPANY ANALYSIS \u2014 PROJECT {codename.upper()}")
    print(f"Target: {deal.get('target_name', 'N/A')}")
    print(f"Sector: {deal.get('sector', 'N/A')}")
    print(f"Date: February 2026")
    print("=" * W)
    
    # Deal Overview
    print(f"\nDEAL OVERVIEW")
    print("-" * 50)
    rows = [
        ("Target", deal.get("target_name", "N/A")),
        ("Sector", deal.get("sector", "N/A")),
        ("Stage", deal.get("stage", "N/A")),
        ("Deal Lead", lead_name),
        ("LTM Revenue", fc(revenue)),
        ("Adjusted EBITDA", fc(ebitda)),
        ("EBITDA Margin", fp(margin)),
        ("EV Range", f"{fc(deal.get('ev_range_low', 0))} - {fc(deal.get('ev_range_high', 0))}"),
        ("Implied Multiple Range", f"{fm(valuation['mult_low'])} - {fm(valuation['mult_high'])}"),
    ]
    for label, val in rows:
        print(f"  {label:<28} {val}")
    
    # Transaction Comps
    print(f"\nTRANSACTION COMPARABLES ({len(txn_comps)} deals)")
    print("-" * W)
    
    # Header
    hdr = f"  {'Target':<26}{'EV':>8}{'EV/EBITDA':>11}{'EV/Rev':>8}{'Buyer':>14}{'Date':>8}"
    print(hdr)
    print(f"  {'-' * 75}")
    
    for c in txn_comps:
        name = c.get("target", "")[:24]
        ev = fc(c.get("ev", 0))
        ev_eb = fm(c.get("ev_ebitda", 0))
        ev_rev = fm(c.get("ev_revenue", 0))
        buyer = c.get("buyer_type", "")[:12]
        date = c.get("date", "")
        print(f"  {name:<26}{ev:>8}{ev_eb:>11}{ev_rev:>8}{buyer:>14}{date:>8}")
    
    # Transaction comp stats
    ts = txn_stats
    print(f"\n  {'Summary Statistics':}")
    print(f"    {'Metric':<28}{'EV/EBITDA':>11}{'EV/Revenue':>12}")
    for stat_name in ["low", "median", "mean", "high"]:
        eb_val = ts["ev_ebitda"].get(stat_name)
        rev_val = ts["ev_revenue"].get(stat_name)
        print(f"    {stat_name.capitalize():<28}{fm(eb_val):>11}{fm(rev_val):>12}")
    
    # Trading Comps
    print(f"\nTRADING COMPARABLES ({len(trading_comps)} companies)")
    print("-" * W)
    
    hdr = f"  {'Company':<26}{'Ticker':>7}{'EV/EBITDA':>11}{'EV/Rev':>8}{'Margin':>8}{'Growth':>8}"
    print(hdr)
    print(f"  {'-' * 66}")
    
    for c in trading_comps:
        name = c.get("company", "")[:24]
        ticker = c.get("ticker", "")
        ev_eb = fm(c.get("ev_ebitda", 0))
        ev_rev = fm(c.get("ev_revenue", 0))
        margin_val = fp(c.get("ebitda_margin", 0))
        growth = fp(c.get("revenue_growth", 0))
        print(f"  {name:<26}{ticker:>7}{ev_eb:>11}{ev_rev:>8}{margin_val:>8}{growth:>8}")
    
    # Trading comp stats
    trs = trading_stats
    print(f"\n  {'Summary Statistics':}")
    print(f"    {'Metric':<28}{'EV/EBITDA':>11}{'EV/Revenue':>12}")
    for stat_name in ["low", "median", "mean", "high"]:
        eb_val = trs["ev_ebitda"].get(stat_name)
        rev_val = trs["ev_revenue"].get(stat_name)
        print(f"    {stat_name.capitalize():<28}{fm(eb_val):>11}{fm(rev_val):>12}")
    
    # Valuation Context
    v = valuation
    print(f"\nVALUATION CONTEXT")
    print("-" * 50)
    print(f"  {'Target Implied Multiple:':<28} {fm(v['mult_low'])} - {fm(v['mult_high'])} (midpoint {fm(v['mult_mid'])})")
    print(f"  {'Transaction Comp Median:':<28} {fm(v['txn_median'])}")
    print(f"  {'Trading Comp Median:':<28} {fm(v['trading_median'])}")
    print(f"  {'Position:':<28} {v['positioning']}")
    if v["guardrail"]:
        g = v["guardrail"]
        print(f"  {'Sector Range:':<28} {fm(g['low'])} - {fm(g['high'])} ({g['sector']})")
        if g.get("note"):
            print(f"  {'Note:':<28} {g['note']}")
    print(f"  {'Hard Ceiling:':<28} {fm(rc_utils.HARD_CEILING_MULTIPLE)}")
    
    # Guardrails Assessment
    print(f"\nGUARDRAILS ASSESSMENT")
    print("-" * 50)
    for check in v["checks"]:
        tag = "PASS" if check["result"] == "PASS" else "FLAG"
        print(f"  [{tag}] {check['test']}: {check['detail']}")
    print(f"  [INFO] Target positioning: {v['positioning']}")
    
    # Detailed comp notes
    if detailed:
        print(f"\nDETAILED COMP NOTES")
        print("-" * W)
        for c in txn_comps:
            print(f"  {c.get('target', '')} ({c.get('date', '')})")
            print(f"    {c.get('description', '')}")
            print(f"    Acquirer: {c.get('acquirer', '')} | {c.get('citation', '')}")
            print()
    
    # Footer with source citations
    all_citations = set()
    for c in txn_comps:
        all_citations.add(c.get("citation", ""))
    for c in trading_comps:
        all_citations.add(c.get("citation", ""))
    
    print("\n" + "=" * W)
    print("Northwood Capital | Chicago, IL | Confidential")
    print(f"Comp sectors matched: {', '.join(rc_utils.map_sector_to_comp_keys(deal.get('sector', '')))}")
    print(f"Sources: {len(all_citations)} citations from PitchBook, Capital IQ, public filings")
    print("=" * W)


def build_json_output(deal, txn_comps, trading_comps, txn_stats, trading_stats, valuation):
    """Build JSON output dict for --json flag."""
    return {
        "deal": {
            "codename": deal.get("codename"),
            "target_name": deal.get("target_name"),
            "sector": deal.get("sector"),
            "stage": deal.get("stage"),
            "revenue": deal.get("revenue_reported"),
            "ebitda_adjusted": deal.get("ebitda_adjusted"),
            "ev_range_low": deal.get("ev_range_low"),
            "ev_range_high": deal.get("ev_range_high"),
        },
        "transaction_comps": txn_comps,
        "trading_comps": trading_comps,
        "statistics": {
            "transaction": txn_stats,
            "trading": trading_stats,
        },
        "valuation_assessment": {
            "implied_multiple_low": valuation["mult_low"],
            "implied_multiple_high": valuation["mult_high"],
            "implied_multiple_mid": valuation["mult_mid"],
            "txn_comp_median": valuation["txn_median"],
            "trading_comp_median": valuation["trading_median"],
            "positioning": valuation["positioning"],
            "guardrail_sector": valuation["guardrail"]["sector"] if valuation["guardrail"] else None,
            "guardrail_range": [valuation["guardrail"]["low"], valuation["guardrail"]["high"]] if valuation["guardrail"] else None,
            "checks": valuation["checks"],
        },
        "meta": {
            "generated_date": "2026-02-22",
            "tool": "comp_analysis.py",
            "confidential": "Northwood Capital",
        },
    }


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Northwood Capital \u2014 Comparable Company Analysis",
        usage="python tools/comp_analysis.py <deal_id> [--detailed] [--json]"
    )
    parser.add_argument("deal_id", help="Pipeline deal codename (e.g., falcon, orion)")
    parser.add_argument("--detailed", action="store_true", help="Include detailed comp descriptions")
    parser.add_argument("--json", action="store_true", help="Output JSON instead of formatted text")
    
    args = parser.parse_args()
    
    # Load data
    deal = rc_utils.load_pipeline_deal(args.deal_id)
    comp_data = rc_utils.load_comp_data()
    
    # Gather comps
    txn_comps, trading_comps = gather_comps(deal, comp_data)
    
    if not txn_comps and not trading_comps:
        print(f"No comparable data found for sector: {deal.get('sector', 'N/A')}")
        sys.exit(1)
    
    # Compute statistics
    txn_ev_ebitda = [c["ev_ebitda"] for c in txn_comps if c.get("ev_ebitda")]
    txn_ev_rev = [c["ev_revenue"] for c in txn_comps if c.get("ev_revenue")]
    txn_stats = {
        "ev_ebitda": compute_stats(txn_ev_ebitda),
        "ev_revenue": compute_stats(txn_ev_rev),
    }
    
    trd_ev_ebitda = [c["ev_ebitda"] for c in trading_comps if c.get("ev_ebitda")]
    trd_ev_rev = [c["ev_revenue"] for c in trading_comps if c.get("ev_revenue")]
    trading_stats = {
        "ev_ebitda": compute_stats(trd_ev_ebitda),
        "ev_revenue": compute_stats(trd_ev_rev),
    }
    
    # Valuation assessment
    valuation = analyze_valuation(deal, txn_stats, trading_stats)
    
    # Output
    if args.json:
        result = build_json_output(deal, txn_comps, trading_comps, txn_stats, trading_stats, valuation)
        print(json.dumps(result, indent=2))
        # Also save to file
        codename = deal.get("codename", args.deal_id).lower()
        filename = f"comp-analysis-{codename}-2026-02-v1.json"
        filepath = rc_utils.write_output(json.dumps(result, indent=2), "comp-analyses", filename)
        print(f"\nSaved to: {filepath}", file=sys.stderr)
    else:
        print_results(deal, txn_comps, trading_comps, txn_stats, trading_stats,
                      valuation, detailed=args.detailed)


if __name__ == "__main__":
    main()
