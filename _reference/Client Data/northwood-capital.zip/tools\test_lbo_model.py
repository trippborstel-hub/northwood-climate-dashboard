#!/usr/bin/env python3
"""
Northwood Capital — LBO Model Test Suite
tools/test_lbo_model.py

Tests aligned with specific Python error vectors, not features.
Each test names the failure mode it catches, shows the expected value
analytically, and explains why the check is non-trivial.

Run:
    python tools/test_lbo_model.py

All tests pass → model integrity confirmed.
Any failure → specific error vector identified with delta.
"""

import sys
import math
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from tools.lbo_model import load_deal_assumptions, run_lbo, compute_irr

# ── Result tracking ───────────────────────────────────────────────────────────

results = []

def check(name, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    results.append((name, status, detail))
    marker = "✓" if condition else "✗"
    print(f"  [{marker}] {name}")
    if not condition:
        print(f"       → {detail}")


# ── Minimal-assumptions factory ───────────────────────────────────────────────

def minimal(
    ev=100.0, ebitda=10.0, revenue=80.0,
    debt=40.0, equity=60.0,
    hold=5, exit_mult=12.0,
    rate=0.08, amort_pct=0.01,
    rev_growth=0.05, ebitda_growth=0.05,
    tax_rate=0.0, nwc_pct=0.0, maint_capex_pct=0.0
):
    """
    Minimal valid assumptions for isolated unit tests.
    All optional mechanics (taxes, NWC, capex) default to zero
    so individual vectors can be tested in isolation.
    """
    proj = []
    r, e = revenue, ebitda
    for yr in range(1, hold + 1):
        r = round(r * (1 + rev_growth), 4)
        e = round(e * (1 + ebitda_growth), 4)
        proj.append({"year": yr, "revenue": r, "ebitda": e, "growth_capex": 0.0})
    return {
        "entry": {
            "ev": ev, "ebitda": ebitda, "revenue": revenue,
            "total_debt": debt, "total_equity": equity,
            "fund_pct": 0.80, "transaction_fees": 0.0,
        },
        "debt": {
            "all_in_rate": rate,
            "annual_amort_pct": amort_pct,
            "revolver_size": 0.0,
            "revolver_drawn": 0,
        },
        "operating": {
            "projections": proj,
            "maintenance_capex_pct": maint_capex_pct,
            "nwc_pct_revenue": nwc_pct,
            "tax_rate": tax_rate,
            "da_pct_revenue": 0.0,
        },
        "exit": {"hold_period": hold, "exit_multiple": exit_mult},
    }


# ════════════════════════════════════════════════════════════════════
# GROUP 1 — IRR SOLVER
# Error vectors: Newton-Raphson convergence failure, wrong period
# indexing (CF0 vs CF1), off-by-one in hold period, sign inversion.
# ════════════════════════════════════════════════════════════════════

def test_irr_solver_known_answers():
    """
    Validate against analytically exact IRRs before trusting any
    model output that depends on it.

    $100 → $200 in 1 year:   IRR = 100.0%   (trivial: 200/100 - 1)
    $100 → $200 in 5 years:  IRR = 14.8698%  (2^(1/5) - 1)
    $100 → $100 in 5 years:  IRR = 0.0%     (no gain)
    $100 → $50  in 5 years:  IRR = -12.94%  (loss case)
    """
    r1 = compute_irr([-100, 200])
    check(
        "IRR: $100→$200 in 1 year = 100.0000%",
        abs(r1 - 1.0) < 1e-6,
        f"Got {r1*100:.6f}%"
    )

    expected_5yr = 2 ** 0.2 - 1  # exact: 14.8698...%
    r5 = compute_irr([-100, 0, 0, 0, 0, 200])
    check(
        f"IRR: $100→$200 in 5 years = {expected_5yr*100:.4f}%",
        abs(r5 - expected_5yr) < 1e-6,
        f"Got {r5*100:.6f}%, expected {expected_5yr*100:.6f}%"
    )

    r_flat = compute_irr([-100, 0, 0, 0, 0, 100])
    check(
        "IRR: $100→$100 in 5 years = 0.0000%",
        abs(r_flat) < 1e-6,
        f"Got {r_flat*100:.6f}%"
    )

    r_loss = compute_irr([-100, 0, 0, 0, 0, 50])
    expected_loss = 0.5 ** 0.2 - 1  # ≈ -12.9449%
    check(
        f"IRR: $100→$50 in 5 years = {expected_loss*100:.4f}%  (loss case)",
        abs(r_loss - expected_loss) < 1e-6,
        f"Got {r_loss*100:.6f}%, expected {expected_loss*100:.6f}%"
    )


def test_irr_npv_at_irr_equals_zero():
    """
    Vector: Solver returning a rate that satisfies a different equation.
    By definition, NPV at IRR must equal zero.
    Tested against the actual Orion cashflows — not synthetic.
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    irr = result["returns"]["gross_irr"] / 100.0
    equity = result["entry"]["total_equity"]
    exit_eq = result["exit"]["equity_value"]
    hold = a["exit"]["hold_period"]

    cfs = [-equity] + [0.0] * (hold - 1) + [exit_eq]
    npv = sum(cf / (1 + irr) ** t for t, cf in enumerate(cfs))
    check(
        f"NPV at computed IRR ({irr*100:.2f}%) ≈ $0  (definition of IRR)",
        abs(npv) < 0.10,
        f"NPV = ${npv:.4f}M — solver may not have converged"
    )


# ════════════════════════════════════════════════════════════════════
# GROUP 2 — MODEL ARITHMETIC
# Error vectors: sources/uses misconstruction, exit EV using wrong
# EBITDA (entry vs exit), MOIC numerator/denominator inversion.
# ════════════════════════════════════════════════════════════════════

def test_sources_equals_uses():
    """
    Vector: Arithmetic error in sources/uses table construction.
    Total sources must equal total uses to the cent.
    Failure here means the capitalization table doesn't balance —
    a partner or lender would catch this immediately.
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    su = result["sources_uses"]
    uses = su["uses"]["total_uses"]
    sources = su["sources"]["total_sources"]
    check(
        f"Sources (${sources}M) = Uses (${uses}M)",
        abs(uses - sources) < 0.01,
        f"Imbalance: ${uses - sources:+.4f}M"
    )


def test_exit_ev_uses_exit_ebitda_not_entry():
    """
    Vector: exit_ev computed from entry_ebitda instead of final-year EBITDA.
    This is the single most consequential input swap in the exit block.

    Check: exit_ev must equal final-year EBITDA × exit_multiple exactly.
    If it used entry EBITDA ($9.5M × 10.5x = $99.75M vs correct $175.35M),
    the error would be $75.6M — obviously wrong, but only if tested.
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    exit_ebitda = result["exit"]["ebitda"]    # must be Year 5, not entry
    exit_mult = result["exit"]["multiple"]
    expected_ev = round(exit_ebitda * exit_mult, 1)
    actual_ev = result["exit"]["ev"]

    check(
        f"Exit EV = Year 5 EBITDA × exit multiple: ${exit_ebitda}M × {exit_mult}x = ${expected_ev}M",
        abs(actual_ev - expected_ev) < 0.05,
        f"Got ${actual_ev}M — possible entry EBITDA (${a['entry']['ebitda']}M × {exit_mult}x = ${a['entry']['ebitda']*exit_mult:.1f}M) used instead"
    )


def test_moic_not_inverted():
    """
    Vector: MOIC = entry_equity / exit_equity (inverted).
    A 2.8x deal would show as 0.35x. Catches sign/direction errors.

    Also validates against direct arithmetic: exit_equity / total_equity.
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    model_moic = result["returns"]["gross_moic_precise"]
    direct_moic = result["exit"]["equity_value"] / result["entry"]["total_equity"]

    check(
        "MOIC = exit equity / entry equity (not inverted)",
        abs(model_moic - direct_moic) < 0.005,
        f"Model: {model_moic:.4f}x, Direct: {direct_moic:.4f}x"
    )
    check(
        "MOIC > 1.0 for a profitable deal",
        model_moic > 1.0,
        f"Got {model_moic:.4f}x — inverted MOIC would typically be < 1"
    )


# ════════════════════════════════════════════════════════════════════
# GROUP 3 — DEBT MECHANICS
# Error vectors: interest on wrong balance (EOY vs BOY), debt going
# negative from uncapped sweep, cumulative paydown counter drift.
# ════════════════════════════════════════════════════════════════════

def test_interest_computed_on_boy_balance():
    """
    Vector: Cash interest applied to end-of-year balance instead of
    beginning-of-year. This understates interest in all years after Y1.

    Year 1 analytical check (cleanest — BOY is unambiguous entry debt):
      BOY = $33.0M, rate = 8.5%
      Expected: $33.0M × 8.5% = $2.805M → $2.8M
      If EOY used ($29.8M): $29.8M × 8.5% = $2.533M → $2.5M  ← wrong
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    entry_debt = a["entry"]["total_debt"]
    rate = a["debt"]["all_in_rate"]
    expected = round(entry_debt * rate, 1)
    actual = result["annual"][0]["cash_interest"]
    wrong_eoy = a["operating"]["projections"][0]  # for context in failure msg
    check(
        f"Year 1 interest on BOY debt: ${entry_debt}M × {rate*100:.1f}% = ${expected}M",
        abs(actual - expected) < 0.05,
        f"Got ${actual}M. If EOY balance (${result['annual'][0]['debt_balance_eoy']}M) used: "
        f"${result['annual'][0]['debt_balance_eoy']*rate:.3f}M"
    )


def test_debt_balance_never_negative():
    """
    Vector: Voluntary prepayment not capped at remaining debt balance.
    If FCF > remaining debt, uncapped sweep drives balance negative —
    phantom deleveraging that inflates exit equity.

    Particularly relevant in high-FCF years (Year 4-5 for Orion).
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    negatives = [(yr["year"], yr["debt_balance_eoy"])
                 for yr in result["annual"]
                 if yr["debt_balance_eoy"] < -0.01]
    check(
        "Debt balance ≥ $0 in all years (FCF sweep capped at remaining balance)",
        len(negatives) == 0,
        f"Negative balances: {negatives}"
    )


def test_debt_schedule_year_over_year_continuity():
    """
    Vector: Debt balance not carried forward correctly between years.
    Each year's interest must be consistent with the prior year's EOY balance.

    Reconstructs BOY externally and validates interest for all 5 years.
    A gap between modeled BOY and reconstructed BOY reveals a carry error.
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    rate = a["debt"]["all_in_rate"]
    boy = a["entry"]["total_debt"]

    for yr in result["annual"]:
        expected_interest = round(boy * rate, 1)
        actual_interest = yr["cash_interest"]
        check(
            f"Year {yr['year']} interest on reconstructed BOY (${boy:.1f}M × {rate*100:.1f}% = ${expected_interest}M)",
            abs(actual_interest - expected_interest) < 0.11,  # 0.1 rounding tolerance
            f"Got ${actual_interest}M — BOY may not be ${boy:.1f}M"
        )
        boy = yr["debt_balance_eoy"]


def test_cumulative_paydown_ties_to_debt_reduction():
    """
    Vector: Cumulative paydown counter accumulating incorrectly
    (e.g., double-counting mandatory + voluntary, or missing a year).

    Invariant: entry_debt − cumulative_paydown = EOY debt balance (final year).
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    entry_debt = a["entry"]["total_debt"]
    final = result["annual"][-1]
    implied_exit = round(entry_debt - final["cumulative_paydown"], 2)
    actual_exit = final["debt_balance_eoy"]
    check(
        f"Entry debt (${entry_debt}M) − cumulative paydown (${final['cumulative_paydown']}M) = exit balance (${actual_exit}M)",
        abs(implied_exit - actual_exit) < 0.05,
        f"Implied exit debt: ${implied_exit}M, Actual: ${actual_exit}M"
    )


# ════════════════════════════════════════════════════════════════════
# GROUP 4 — YEAR INDEXING
# Error vector: off-by-one in prior-year revenue lookup for NWC.
# Year 1 should reference entry revenue (year 0), not year 1 revenue.
# ════════════════════════════════════════════════════════════════════

def test_nwc_year1_uses_entry_revenue():
    """
    Vector: projections[yr - 2] off-by-one — Year 1 using Year 1
    revenue as prior (delta = 0) instead of entry revenue.

    If wrong:  (64.0 - 64.0) × 8% = $0.0M   ← flat, clearly wrong
    If right:  (64.0 - 58.0) × 8% = $0.48M → $0.5M
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    entry_rev = a["entry"]["revenue"]
    yr1_rev = a["operating"]["projections"][0]["revenue"]
    nwc_pct = a["operating"]["nwc_pct_revenue"]
    expected = round((yr1_rev - entry_rev) * nwc_pct, 1)
    actual = result["annual"][0]["nwc_change"]
    check(
        f"Year 1 NWC uses entry revenue: (${yr1_rev}M − ${entry_rev}M) × {nwc_pct*100:.0f}% = ${expected}M",
        abs(actual - expected) < 0.05,
        f"Got ${actual}M. If Year 1 used as prior: $0.0M"
    )


# ════════════════════════════════════════════════════════════════════
# GROUP 5 — EDGE CASES
# Error vectors: negative tax benefit inflating FCF; model failure
# when debt = 0 (division, negative balance, or unhandled sweep).
# ════════════════════════════════════════════════════════════════════

def test_tax_floor_when_ebt_negative():
    """
    Vector: max(0, EBT) not applied — negative EBT produces negative
    tax expense, which inflates levered FCF in distressed years.

    Test construction: high leverage forces EBT < 0 in Year 1.
      EBITDA = $2.0M, interest = $80M × 10% = $8.0M
      EBT = $2.0M − $8.0M = −$6.0M
      Taxes must be $0 (not −$1.5M as a 25% credit)
    """
    a = minimal(
        ev=100.0, ebitda=2.0, revenue=20.0,
        debt=80.0, equity=20.0,
        rate=0.10, amort_pct=0.01,
        rev_growth=0.0, ebitda_growth=0.0,
        tax_rate=0.25
    )
    result = run_lbo(a)
    yr1_taxes = result["annual"][0]["cash_taxes"]
    yr1_interest = result["annual"][0]["cash_interest"]
    yr1_ebitda = result["annual"][0]["ebitda"]
    check(
        f"Cash taxes = $0 when EBT < 0 (EBITDA ${yr1_ebitda}M − interest ${yr1_interest}M < 0)",
        yr1_taxes >= 0.0,
        f"Got cash_taxes = ${yr1_taxes}M — negative tax benefit leaking into FCF"
    )


def test_zero_debt_model_runs_cleanly():
    """
    Vector: Model failing or producing nonsensical output when debt = 0.
    Specifically: division errors, negative 'remaining debt', or the
    voluntary sweep driving balance below zero when debt starts at zero.

    Checks: model completes, all debt balances = 0, MOIC > 1.0.
    """
    a = minimal(
        ev=100.0, ebitda=10.0, revenue=80.0,
        debt=0.0, equity=100.0,
        hold=5, exit_mult=12.0,
        rate=0.0, amort_pct=0.0,
        rev_growth=0.0, ebitda_growth=0.05,
        tax_rate=0.0
    )
    try:
        result = run_lbo(a)
        debt_balances = [yr["debt_balance_eoy"] for yr in result["annual"]]
        check(
            "Zero-debt model runs without exception",
            True
        )
        check(
            "Zero-debt model: all EOY debt balances = $0.0M",
            all(abs(b) < 0.01 for b in debt_balances),
            f"Non-zero balances: {debt_balances}"
        )
        check(
            "Zero-debt model: MOIC > 1.0 (profitable at 12x exit)",
            result["returns"]["gross_moic_precise"] > 1.0,
            f"Got {result['returns']['gross_moic_precise']:.3f}x"
        )
    except Exception as e:
        check("Zero-debt model runs without exception", False, f"{type(e).__name__}: {e}")
        check("Zero-debt model: all EOY debt balances = $0.0M", False, "Not reached")
        check("Zero-debt model: MOIC > 1.0 (profitable at 12x exit)", False, "Not reached")


# ════════════════════════════════════════════════════════════════════
# GROUP 6 — VALUE ATTRIBUTION
# Error vector: wrong formula for EBITDA growth value or multiple
# expansion component — silently misstates the value creation story.
# ════════════════════════════════════════════════════════════════════

def test_value_bridge_sums_to_equity_gain():
    """
    Vector: Incorrect bridge formula producing components that don't
    add up to the actual equity gain.

    Invariant:
      EBITDA growth value + multiple expansion value + deleveraging value
      ≈ exit equity − entry equity
      (within $0.50M rounding tolerance from one-decimal truncation)
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    vb = result["value_bridge"]
    bridge_total = (
        vb["ebitda_growth"]["value"]
        + vb["multiple_expansion"]["value"]
        + vb["deleveraging"]["value"]
    )
    equity_gain = result["exit"]["equity_value"] - result["entry"]["total_equity"]
    check(
        f"Bridge sum (${bridge_total:.1f}M) ≈ exit equity − entry equity (${equity_gain:.1f}M)",
        abs(bridge_total - equity_gain) < 0.50,
        f"Delta: ${bridge_total - equity_gain:+.2f}M  (tolerance: $0.50M)"
    )


def test_value_bridge_components_positive_for_profitable_deal():
    """
    Vector: Sign errors in bridge formulas producing negative components
    for a deal where every driver contributed positively.

    For Orion base case:
      EBITDA growth: exit EBITDA > entry EBITDA → must be positive
      Multiple expansion: exit mult > entry mult → must be positive
      Deleveraging: debt paid down → must be positive
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    vb = result["value_bridge"]
    for driver, data in vb.items():
        check(
            f"Bridge component '{driver}' > 0 (all drivers positive for Orion base case)",
            data["value"] > 0,
            f"Got ${data['value']}M — sign error in bridge formula"
        )


# ════════════════════════════════════════════════════════════════════
# GROUP 7 — DATA LOADING
# Error vectors: silent None return on missing deal; missing
# lbo_assumptions block not raising an informative error.
# ════════════════════════════════════════════════════════════════════

def test_missing_deal_raises_value_error():
    """
    Vector: load_deal_assumptions returning None (or empty dict) for
    an unknown deal ID instead of raising. Downstream code would fail
    with a confusing AttributeError, masking the real problem.
    """
    try:
        load_deal_assumptions("deal_id_that_does_not_exist_xyz")
        check("Missing deal ID raises ValueError", False, "No exception raised — returned None or empty")
    except ValueError as e:
        check("Missing deal ID raises ValueError", True)
    except Exception as e:
        check("Missing deal ID raises ValueError", False, f"Wrong exception type: {type(e).__name__}: {e}")


def test_deal_without_lbo_assumptions_raises_value_error():
    """
    Vector: load_deal_assumptions silently returning a portco dict
    that has no lbo_assumptions block, causing a KeyError inside run_lbo
    rather than a clear error at load time.

    meridian_business_solutions exists in data spine but has no
    lbo_assumptions — valid test subject.
    """
    try:
        load_deal_assumptions("meridian_business_solutions")
        check("Deal without lbo_assumptions raises ValueError", False,
              "No exception — would cause opaque KeyError inside run_lbo")
    except ValueError as e:
        check("Deal without lbo_assumptions raises ValueError", True)
    except Exception as e:
        check("Deal without lbo_assumptions raises ValueError", False,
              f"Wrong exception type: {type(e).__name__}: {e}")


# ════════════════════════════════════════════════════════════════════
# GROUP 8 — REGRESSION BASELINE
# Any change to lbo_model.py or Orion's data spine entry will cause
# this group to fail. Intentional: forces explicit acknowledgment
# before outputs are changed.
# ════════════════════════════════════════════════════════════════════

def test_regression_orion_baseline():
    """
    Orion baseline established: February 2026.
    IC memo values: 2.8x gross MOIC / ~23% gross IRR.

    If any of these checks fail, either:
      (a) lbo_model.py logic was changed — update this test intentionally, or
      (b) data-spine.json Orion assumptions were changed — same.
    Either way, the change is now explicit and auditable.
    """
    a = load_deal_assumptions("orion")
    result = run_lbo(a)
    r = result["returns"]
    e = result["entry"]
    ex = result["exit"]

    baseline = [
        ("Entry EV",                e["ev"],                     95.0),
        ("Entry EBITDA",            e["ebitda"],                  9.5),
        ("Entry multiple",          e["multiple"],               10.0),
        ("Entry total debt",        e["total_debt"],             33.0),
        ("Entry leverage",          e["leverage"],                3.5),
        ("Entry total equity",      e["total_equity"],           62.0),
        ("Entry fund equity",       e["fund_equity"],            49.6),
        ("Entry mgmt equity",       e["mgmt_equity"],            12.4),
        ("Year 5 EBITDA",           ex["ebitda"],                16.7),
        ("Exit multiple",           ex["multiple"],              10.5),
        ("Exit EV",                 ex["ev"],                   175.3),
        ("Exit net debt",           ex["net_debt"],               0.2),
        ("Exit equity value",       ex["equity_value"],         175.2),
        ("Gross MOIC (precise)",    r["gross_moic_precise"],      2.83),
        ("Gross IRR (%)",           r["gross_irr"],              23.1),
        ("Year 5 debt balance",     result["annual"][-1]["debt_balance_eoy"], 0.2),
        ("Total debt paydown",      result["annual"][-1]["cumulative_paydown"], 32.8),
    ]

    for label, actual, expected in baseline:
        check(
            f"Regression — {label}: {expected}",
            abs(actual - expected) < 0.06,
            f"Got {actual}, expected {expected}, delta {actual-expected:+.4f}"
        )


# ════════════════════════════════════════════════════════════════════
# RUNNER
# ════════════════════════════════════════════════════════════════════

def main():
    W = 72
    print("=" * W)
    print("NORTHWOOD CAPITAL — LBO MODEL TEST SUITE")
    print("tools/lbo_model.py  ×  _reference/data-spine.json")
    print("Baseline: February 2026  |  Deal: Project Orion")
    print("=" * W)

    groups = [
        ("IRR Solver",
            [test_irr_solver_known_answers,
             test_irr_npv_at_irr_equals_zero]),

        ("Model Arithmetic",
            [test_sources_equals_uses,
             test_exit_ev_uses_exit_ebitda_not_entry,
             test_moic_not_inverted]),

        ("Debt Mechanics",
            [test_interest_computed_on_boy_balance,
             test_debt_balance_never_negative,
             test_debt_schedule_year_over_year_continuity,
             test_cumulative_paydown_ties_to_debt_reduction]),

        ("Year Indexing",
            [test_nwc_year1_uses_entry_revenue]),

        ("Edge Cases",
            [test_tax_floor_when_ebt_negative,
             test_zero_debt_model_runs_cleanly]),

        ("Value Attribution",
            [test_value_bridge_sums_to_equity_gain,
             test_value_bridge_components_positive_for_profitable_deal]),

        ("Data Loading",
            [test_missing_deal_raises_value_error,
             test_deal_without_lbo_assumptions_raises_value_error]),

        ("Regression — Orion Baseline",
            [test_regression_orion_baseline]),
    ]

    for group_name, tests in groups:
        print(f"\n{group_name}")
        print("─" * 44)
        for fn in tests:
            fn()

    passed = sum(1 for _, s, _ in results if s == "PASS")
    failed = sum(1 for _, s, _ in results if s == "FAIL")
    total = len(results)

    print(f"\n{'=' * W}")
    if failed == 0:
        print(f"  {passed}/{total} checks passed — model integrity confirmed")
    else:
        print(f"  {passed}/{total} passed  |  {failed} FAILED — integrity not confirmed")
        print()
        for name, status, detail in results:
            if status == "FAIL":
                print(f"  FAIL: {name}")
                if detail:
                    print(f"        {detail}")
    print("=" * W)

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
