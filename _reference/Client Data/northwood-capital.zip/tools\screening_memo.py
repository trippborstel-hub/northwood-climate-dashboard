#!/usr/bin/env python3
"""
Northwood Capital — Screening Memo Generator

Auto-generates 1-page screening memos for pipeline deals.
Applies auto-pass rules, flag-for-review criteria, and scoring dimensions.

Usage:
    python tools/screening_memo.py falcon              # Generate screening memo
    python tools/screening_memo.py falcon --json       # Machine-readable output
"""

import json
import sys
import argparse
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rc_utils


# ============================================================
# AUTO-PASS RULES
# From screening-criteria.md — hard gates
# ============================================================

def check_auto_pass(deal):
    """Check 6 auto-pass rules. Returns list of triggered rules."""
    triggered = []
    
    # Get EBITDA — handle both active and passed deals
    ebitda = deal.get("ebitda_adjusted") or deal.get("ebitda") or 0
    
    # Rule 1: EBITDA < $10M
    if ebitda > 0 and ebitda < 10.0:
        triggered.append({
            "rule": "Below EBITDA threshold",
            "detail": f"Adjusted EBITDA {rc_utils.fc(ebitda)} is below $10.0M minimum for platform investments",
            "source": "[Screening Criteria, Rule 1]"
        })
    
    # Rule 2: EV > $300M
    ev_high = deal.get("ev_range_high") or deal.get("seller_ask_ev") or 0
    if ev_high > 300.0:
        triggered.append({
            "rule": "Above EV target range",
            "detail": f"EV {rc_utils.fc(ev_high)} exceeds $300.0M upper bound",
            "source": "[Screening Criteria, Rule 2]"
        })
    
    # Rule 3: Turnaround / operational distress
    # Check for turnaround keywords in deal data
    stage = deal.get("stage", "").lower()
    desc_fields = [
        deal.get("seller_rationale", ""),
        deal.get("key_thesis", ""),
        " ".join(deal.get("key_risks", [])),
    ]
    combined = " ".join(str(f) for f in desc_fields).lower()
    if "turnaround" in combined or "distress" in combined or "restructuring" in stage:
        triggered.append({
            "rule": "Turnaround / operational distress",
            "detail": "Deal involves turnaround or operationally distressed business — outside Northwood competency",
            "source": "[Screening Criteria, Rule 3]"
        })
    
    # Rule 4: Pure commodity / cyclicality > 30%
    # Heuristic: check for explicit cyclicality mentions
    sector = deal.get("sector", "").lower()
    if "commodity" in combined and ("cyclical" in combined or "30%" in combined):
        triggered.append({
            "rule": "Pure commodity / high cyclicality",
            "detail": "Peak-to-trough cyclicality exceeds 30% threshold",
            "source": "[Screening Criteria, Rule 4]"
        })
    
    # Rule 5: International > 75%
    if "international" in combined and ("75%" in combined or ">75%" in combined):
        triggered.append({
            "rule": "International-only operations",
            "detail": ">75% non-U.S. revenue — outside Northwood operating playbook",
            "source": "[Screening Criteria, Rule 5]"
        })
    
    # Rule 6: Venture-stage / pre-profitability
    founding_year = deal.get("founding_year_target", 0)
    if founding_year and founding_year > 2024:
        triggered.append({
            "rule": "Venture-stage / pre-profitability",
            "detail": f"Founded {founding_year} — requires 2+ year operating track record",
            "source": "[Screening Criteria, Rule 6]"
        })
    if ebitda <= 0:
        triggered.append({
            "rule": "Venture-stage / pre-profitability",
            "detail": "No positive EBITDA — requires proven profitability track record",
            "source": "[Screening Criteria, Rule 6]"
        })
    
    # Also check if already passed
    if deal.get("pass_type") == "auto_pass_size":
        if not any(r["rule"] == "Below EBITDA threshold" for r in triggered):
            triggered.append({
                "rule": "Below EBITDA threshold",
                "detail": deal.get("pass_reason", "Below minimum EBITDA threshold"),
                "source": "[Spine, pipeline_passed]"
            })
    
    return triggered


# ============================================================
# FLAG-FOR-REVIEW CRITERIA
# ============================================================

def check_flags(deal):
    """Check 7 flag-for-review criteria + seeded_risk. Returns list of flags."""
    flags = []
    
    ebitda = deal.get("ebitda_adjusted") or deal.get("ebitda") or 0
    revenue = deal.get("revenue_reported") or deal.get("revenue") or 0
    risks = deal.get("key_risks", [])
    combined_text = " ".join(str(r) for r in risks).lower()
    attractions = deal.get("key_attractions", [])
    combined_attract = " ".join(str(a) for a in attractions).lower()
    seller = deal.get("seller_rationale", "").lower()
    
    # Flag 1: Small platform ($10-15M EBITDA)
    if 10.0 <= ebitda <= 15.0:
        flags.append({
            "flag": "Small for platform",
            "severity": "Medium",
            "detail": f"EBITDA {rc_utils.fc(ebitda)} is within $10-15M range — requires clear path to $20M+ within 24 months",
            "source": "[Screening Criteria, Flag 1]"
        })
    
    # Flag 2: Customer concentration > 25%
    # Check explicit concentration data or seeded_risk
    seeded = deal.get("seeded_risk", "")
    if seeded:
        # Seeded risks are always flagged as High — they represent hidden issues
        # that require independent verification regardless of stated percentage
        flags.append({
            "flag": "Customer concentration (hidden)",
            "severity": "High",
            "detail": seeded,
            "source": "[Spine, seeded_risk — requires independent verification]"
        })
    
    if "concentration" in combined_text and "25%" in combined_text:
        flags.append({
            "flag": "Customer concentration",
            "severity": "High",
            "detail": "Customer concentration exceeds 25% threshold — requires detailed diligence",
            "source": "[Screening Criteria, Flag 2]"
        })
    
    # Flag 3: Cyclical end markets
    if "cyclical" in combined_text or "cycle" in combined_text:
        flags.append({
            "flag": "Cyclical end markets",
            "severity": "Medium",
            "detail": "Exposure to cyclical end markets — requires -20% stress testing",
            "source": "[Screening Criteria, Flag 3]"
        })
    
    # Flag 4: Regulatory overhang
    if "regulatory" in combined_text or "regulation" in combined_text or "certification" in combined_text:
        flags.append({
            "flag": "Regulatory considerations",
            "severity": "Medium",
            "detail": "Regulatory factors identified — requires probability/timeline/magnitude sizing",
            "source": "[Screening Criteria, Flag 4]"
        })
    
    # Flag 5: Founder/CEO transition risk
    if "founder" in seller or "retirement" in seller:
        flags.append({
            "flag": "Founder transition risk",
            "severity": "Medium",
            "detail": f"Seller rationale: {deal.get('seller_rationale', 'N/A')} — requires succession plan assessment",
            "source": "[Screening Criteria, Flag 5]"
        })
    
    # Flag 6: Working capital intensity > 15%
    # Check for WC mentions in risks
    if "working capital" in combined_text or "nwc" in combined_text or "inventory" in combined_text:
        flags.append({
            "flag": "Working capital intensity",
            "severity": "Medium",
            "detail": "Working capital intensity flagged — requires detailed WC analysis",
            "source": "[Screening Criteria, Flag 6]"
        })
    
    # Flag 7: Technology disruption
    if "technology disruption" in combined_text or "tech disruption" in combined_text:
        flags.append({
            "flag": "Technology disruption risk",
            "severity": "Medium",
            "detail": "Technology disruption risk identified — requires 5-year horizon assessment",
            "source": "[Screening Criteria, Flag 7]"
        })
    
    # Geographic concentration (additional flag from deal data)
    for risk in risks:
        if "geographic concentration" in risk.lower() or "geographic" in risk.lower() and "75%" in risk:
            flags.append({
                "flag": "Geographic concentration",
                "severity": "Medium",
                "detail": risk,
                "source": "[Spine, key_risks]"
            })
            break
    
    return flags


# ============================================================
# SCREENING SCORES
# 5 dimensions, 1-5 scale, heuristic-based
# ============================================================

def compute_scores(deal):
    """Compute 5-dimension screening scores from deal data."""
    attractions = " ".join(deal.get("key_attractions", [])).lower()
    risks = " ".join(deal.get("key_risks", [])).lower()
    ebitda = deal.get("ebitda_adjusted") or deal.get("ebitda") or 0
    revenue = deal.get("revenue_reported") or deal.get("revenue") or 0
    margin = (ebitda / revenue * 100) if revenue > 0 else 0
    sector_keys = rc_utils.map_sector_to_comp_keys(deal.get("sector", ""))
    
    scores = []
    
    # 1. Market Position
    mp_score = 3
    mp_rationale = "Moderate market position"
    if "fragmented" in attractions or "#1" in attractions or "#2" in attractions:
        mp_score += 1
        mp_rationale = "Operates in fragmented market with positioning advantages"
    if "market leader" in attractions or "leading" in attractions:
        mp_score += 1
        mp_rationale = "Market leader with defensible position"
    if "niche" in attractions or "specialized" in attractions or "barriers" in attractions or "switching cost" in attractions:
        mp_score = min(mp_score + 1, 5)
        mp_rationale += "; barriers to entry identified"
    if "commodity" in risks:
        mp_score -= 1
        mp_rationale = "Commodity exposure limits positioning"
    scores.append({"dimension": "Market Position", "score": min(max(mp_score, 1), 5), "rationale": mp_rationale})
    
    # 2. Management Quality
    mq_score = 3
    mq_rationale = "Management assessment pending"
    founding_year = deal.get("founding_year_target", 0)
    employees = deal.get("employee_count_target", 0)
    if founding_year and founding_year < 2005 and employees > 200:
        mq_score = 4
        mq_rationale = f"Established business (founded {founding_year}), {employees} employees — institutional-quality operations likely"
    elif founding_year and founding_year < 2015:
        mq_score = 3
        mq_rationale = f"Founded {founding_year} — proven operating track record"
    if "management" in risks and "transition" in risks:
        mq_score -= 1
        mq_rationale += "; founder transition risk noted"
    scores.append({"dimension": "Management Quality", "score": min(max(mq_score, 1), 5), "rationale": mq_rationale})
    
    # 3. Growth Visibility
    gv_score = 3
    gv_rationale = "Moderate growth visibility"
    rev_proj = deal.get("revenue_projected", 0)
    rev_rep = deal.get("revenue_reported") or deal.get("revenue") or 0
    if rev_proj and rev_rep and rev_proj > rev_rep:
        growth_rate = (rev_proj / rev_rep - 1) * 100
        if growth_rate > 8:
            gv_score = 4
            gv_rationale = f"Projected revenue growth ~{growth_rate:.0f}%"
        elif growth_rate > 4:
            gv_score = 3
            gv_rationale = f"Moderate projected growth ~{growth_rate:.0f}%"
    if "recurring" in attractions or "contract" in attractions:
        gv_score = min(gv_score + 1, 5)
        gv_rationale += "; recurring/contractual revenue base provides visibility"
    if "tailwind" in attractions or "momentum" in attractions or "regulatory momentum" in attractions:
        gv_score = min(gv_score + 1, 5)
        gv_rationale += "; sector tailwinds support growth"
    scores.append({"dimension": "Growth Visibility", "score": min(max(gv_score, 1), 5), "rationale": gv_rationale})
    
    # 4. Margin Profile
    mp2_score = 3
    mp2_rationale = f"EBITDA margin {margin:.1f}%"
    # Compare to sector averages
    if margin >= 18:
        mp2_score = 4
        mp2_rationale = f"Strong margin profile at {margin:.1f}%"
    elif margin >= 14:
        mp2_score = 3
        mp2_rationale = f"Adequate margin at {margin:.1f}% with expansion potential"
    elif margin >= 10:
        mp2_score = 2
        mp2_rationale = f"Thin margins at {margin:.1f}% — expansion thesis required"
    else:
        mp2_score = 1
        mp2_rationale = f"Low margins at {margin:.1f}% — structural concern"
    scores.append({"dimension": "Margin Profile", "score": min(max(mp2_score, 1), 5), "rationale": mp2_rationale})
    
    # 5. Fragmentation / Consolidation
    frag_score = 3
    frag_rationale = "Consolidation opportunity assessment pending"
    if "fragmented" in attractions:
        frag_score = 4
        frag_rationale = "Fragmented market with consolidation opportunity"
    if "$12b" in attractions or "$10b" in attractions or "$15b" in attractions or "billion" in attractions:
        frag_score = min(frag_score + 1, 5)
        frag_rationale += "; large addressable market"
    if "add-on" in attractions or "tuck-in" in attractions or "consolidat" in attractions:
        frag_score = min(frag_score + 1, 5)
        frag_rationale += "; identified add-on targets"
    scores.append({"dimension": "Fragmentation", "score": min(max(frag_score, 1), 5), "rationale": frag_rationale})
    
    return scores


def determine_recommendation(auto_pass, flags, scores):
    """Determine recommendation: ADVANCE / MONITOR / PASS."""
    if auto_pass:
        return "PASS", auto_pass[0]["detail"]
    
    avg_score = sum(s["score"] for s in scores) / len(scores) if scores else 0
    min_score = min(s["score"] for s in scores) if scores else 0
    has_high_severity = any(f["severity"] == "High" for f in flags)
    
    if min_score < 2:
        return "PASS", f"Minimum screening score {min_score}/5 is below threshold (requires 2+)"
    
    if avg_score >= 3.0 and not has_high_severity:
        return "ADVANCE", f"Average score {avg_score:.1f}/5.0 meets threshold, no high-severity flags"
    
    if has_high_severity:
        high_flags = [f["flag"] for f in flags if f["severity"] == "High"]
        return "MONITOR", f"High-severity flags require resolution before advancing: {', '.join(high_flags)}"
    
    return "MONITOR", f"Average score {avg_score:.1f}/5.0 — borderline, additional diligence recommended"


# ============================================================
# MEMO GENERATION
# ============================================================

def generate_memo(deal, auto_pass, flags, scores, recommendation, rationale):
    """Generate the screening memo markdown content."""
    codename = deal.get("codename", "UNKNOWN")
    target = deal.get("target_name", "N/A")
    sector = deal.get("sector", "N/A")
    
    team = rc_utils.resolve_deal_team(deal)
    lead = team[0] if team else {"name": "N/A", "title": ""}
    
    ebitda = deal.get("ebitda_adjusted") or deal.get("ebitda") or 0
    revenue = deal.get("revenue_reported") or deal.get("revenue") or 0
    margin = round(ebitda / revenue * 100, 1) if revenue > 0 else 0
    
    ev_low = deal.get("ev_range_low", 0)
    ev_high = deal.get("ev_range_high", 0)
    mult_low = round(ev_low / ebitda, 1) if ebitda > 0 else 0
    mult_high = round(ev_high / ebitda, 1) if ebitda > 0 else 0
    
    rev_proj = deal.get("revenue_projected", 0)
    rev_rep = deal.get("revenue_reported") or deal.get("revenue") or 0
    rev_cagr = round((rev_proj / rev_rep - 1) * 100, 1) if rev_proj and rev_rep and rev_rep > 0 else 0
    
    attractions = deal.get("key_attractions", [])
    risks = deal.get("key_risks", [])
    
    lines = []
    lines.append(f"# Screening Memo — Project {codename}")
    lines.append("")
    lines.append(f"**{target}** | {sector}")
    lines.append(f"**Date:** {datetime.now().strftime('%B %d, %Y')} | **Deal Lead:** {lead['name']} ({lead.get('title', '')})")
    lines.append(f"**Source:** {deal.get('source', 'N/A')} | **Stage:** {deal.get('stage', 'N/A')}")
    lines.append("")
    lines.append("---")
    lines.append("")
    
    # Company Overview
    lines.append("## Company Overview")
    lines.append("")
    founding = deal.get("founding_year_target", "N/A")
    hq = deal.get("hq_city", "N/A")
    employees = deal.get("employee_count_target", "N/A")
    seller = deal.get("seller_rationale", "N/A")
    lines.append(f"{target} is a {sector.lower()} company headquartered in {hq}, founded in {founding}. "
                  f"The company employs approximately {employees} people and generates {rc_utils.fc(revenue)} in LTM revenue "
                  f"with {rc_utils.fc(ebitda)} in adjusted EBITDA ({rc_utils.fp(margin)} margin). "
                  f"Seller rationale: {seller}.")
    lines.append("")
    
    # Market
    lines.append("## Market")
    lines.append("")
    market_points = []
    for a in attractions:
        if any(kw in a.lower() for kw in ["market", "fragmented", "tailwind", "regulatory", "demand"]):
            market_points.append(a)
    if market_points:
        lines.append(" ".join(market_points[:3]) + ".")
    else:
        lines.append(f"The {sector} market presents characteristics consistent with Northwood's investment thesis.")
    lines.append("")
    
    # Financial Summary
    lines.append("## Financial Summary")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| LTM Revenue | {rc_utils.fc(revenue)} |")
    lines.append(f"| LTM Adj. EBITDA | {rc_utils.fc(ebitda)} |")
    lines.append(f"| EBITDA Margin | {rc_utils.fp(margin)} |")
    if rev_cagr:
        lines.append(f"| Revenue Growth (projected) | {rc_utils.fp(rev_cagr)} |")
    
    # Check for recurring revenue mention
    recurring = ""
    for a in attractions:
        if "recurring" in a.lower() or "contract" in a.lower():
            import re
            pct_match = re.search(r'(\d+)%', a)
            if pct_match:
                recurring = f"{pct_match.group(1)}%"
                break
    if recurring:
        lines.append(f"| Recurring Revenue | {recurring} |")
    
    lines.append(f"| EV Range | {rc_utils.fc(ev_low)} - {rc_utils.fc(ev_high)} |")
    lines.append(f"| Implied Multiple Range | {rc_utils.fm(mult_low)} - {rc_utils.fm(mult_high)} |")
    lines.append(f"| Equity Check | {rc_utils.fc(deal.get('equity_check_low', 0))} - {rc_utils.fc(deal.get('equity_check_high', 0))} |")
    if deal.get("ebitda_adjustments_detail"):
        lines.append(f"| EBITDA Adjustments | {deal['ebitda_adjustments_detail']} |")
    lines.append("")
    
    # Investment Highlights
    lines.append("## Investment Highlights")
    lines.append("")
    for i, attr in enumerate(attractions[:4], 1):
        lines.append(f"{i}. {attr}")
    lines.append("")
    
    # Key Risks
    lines.append("## Key Risks")
    lines.append("")
    lines.append("| # | Risk | Severity | Source |")
    lines.append("|---|------|----------|--------|")
    for i, risk in enumerate(risks[:5], 1):
        severity = "High" if any(kw in risk.lower() for kw in ["concentration", "execution", "regulatory"]) else "Medium"
        lines.append(f"| {i} | {risk} | {severity} | [Spine] |")
    lines.append("")
    
    # Seeded risk
    seeded = deal.get("seeded_risk", "")
    if seeded:
        lines.append(f"**FLAGGED — HIDDEN RISK:** {seeded}")
        lines.append("")
    
    # Flags for review
    if flags:
        lines.append("**Flags for Review:**")
        lines.append("")
        for f in flags:
            lines.append(f"- **{f['flag']}** ({f['severity']}): {f['detail']}")
        lines.append("")
    
    # Screening Scores
    lines.append("## Screening Scores")
    lines.append("")
    lines.append("| Dimension | Score | Assessment |")
    lines.append("|-----------|-------|------------|")
    for s in scores:
        lines.append(f"| {s['dimension']} | {s['score']}/5 | {s['rationale']} |")
    avg_score = sum(s["score"] for s in scores) / len(scores) if scores else 0
    lines.append(f"| **Average** | **{avg_score:.1f}/5.0** | |")
    lines.append("")
    
    # Recommendation
    lines.append("## Recommendation")
    lines.append("")
    lines.append(f"**{recommendation}**")
    lines.append("")
    lines.append(rationale)
    lines.append("")
    
    # QA Summary
    sources = ["[Spine]", "[Screening Criteria]"]
    if seeded:
        sources.append("[Spine, seeded_risk]")
    checks = [
        "All auto-pass rules evaluated",
        "Flag-for-review criteria checked",
        "Screening scores computed from deal data",
        "Valuation guardrails referenced",
        "Numerical precision per deliverable-standards.md",
    ]
    assumptions = [
        "[Spine] — All financial data from data-spine.json pipeline entry",
        "[RC Assumption] — Screening scores are heuristic-based, pending management meeting",
    ]
    warnings_list = None
    if seeded:
        warnings_list = [f"Seeded risk detected: {seeded[:100]}..."]
    
    qa = rc_utils.qa_summary_section(sources, checks, assumptions, warnings_list)
    lines.append(qa)
    
    return "\n".join(lines)


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Northwood Capital — Screening Memo Generator",
        usage="python tools/screening_memo.py <deal_id> [--json]"
    )
    parser.add_argument("deal_id", help="Pipeline deal codename (e.g., falcon, orion, venture)")
    parser.add_argument("--json", action="store_true", help="Output JSON instead of markdown memo")
    
    args = parser.parse_args()
    
    # Load deal
    deal = rc_utils.load_pipeline_deal(args.deal_id)
    
    # Run checks
    auto_pass = check_auto_pass(deal)
    flags = check_flags(deal)
    scores = compute_scores(deal)
    recommendation, rationale = determine_recommendation(auto_pass, flags, scores)
    
    # Handle auto-pass (still generate output but flag it)
    if auto_pass:
        print(f"AUTO-PASS TRIGGERED for Project {deal.get('codename', args.deal_id).upper()}")
        print()
        for rule in auto_pass:
            print(f"  [AUTO-PASS] {rule['rule']}")
            print(f"             {rule['detail']}")
            print(f"             Source: {rule['source']}")
        print()
        print(f"Recommendation: PASS")
        print()
        
        if deal.get("_section") == "pipeline_passed":
            print(f"Note: This deal is already in pipeline_passed.")
            if deal.get("pass_reason"):
                print(f"Pass reason: {deal['pass_reason']}")
        
        if not args.json:
            return
    
    # Generate memo content
    memo = generate_memo(deal, auto_pass, flags, scores, recommendation, rationale)
    
    if args.json:
        result = {
            "deal_id": args.deal_id,
            "codename": deal.get("codename"),
            "target_name": deal.get("target_name"),
            "auto_pass_rules": auto_pass,
            "flags": flags,
            "scores": [{"dimension": s["dimension"], "score": s["score"], "rationale": s["rationale"]} for s in scores],
            "average_score": round(sum(s["score"] for s in scores) / len(scores), 1) if scores else 0,
            "recommendation": recommendation,
            "rationale": rationale,
            "memo_content": memo,
        }
        print(json.dumps(result, indent=2))
    else:
        # Print memo
        print(memo)
        
        # Save to file
        codename = deal.get("codename", args.deal_id).lower()
        date_str = datetime.now().strftime("%Y-%m")
        filename = f"screening-memo-{codename}-{date_str}-v1.md"
        filepath = rc_utils.write_output(memo, "screening-memos", filename)
        print(f"\nSaved to: {filepath}")


if __name__ == "__main__":
    main()
