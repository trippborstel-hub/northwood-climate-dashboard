"""
gen_patriot_package.py
Generates Q4 2025 Management Package Excel for Patriot Staffing Solutions
Northwood Capital Fund II | RAG: AMBER
"""

import os
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.styles.numbers import FORMAT_PERCENTAGE_00
from openpyxl.utils import get_column_letter

# ── Output path ────────────────────────────────────────────────────────────────
BASE = "/Users/diego/Desktop/Claude-Projects/kith-os/environments/clients/northwood-capital"
OUT_DIR = os.path.join(BASE, "portfolio/patriot-staffing-solutions/reporting")
OUT_FILE = os.path.join(OUT_DIR, "patriot-management-package-q4-2025-v1.xlsx")
os.makedirs(OUT_DIR, exist_ok=True)

# ── Colour palette ─────────────────────────────────────────────────────────────
NAVY        = "1F3864"
WHITE       = "FFFFFF"
AMBER       = "ED7D31"
AMBER_LIGHT = "FFF2CC"
RED         = "FF0000"
RED_LIGHT   = "FFCCCC"
GREEN       = "00B050"
GREEN_LIGHT = "E2EFDA"
GREY_LIGHT  = "F2F2F2"
GREY_MED    = "D9D9D9"
DARK_GREY   = "595959"

# ── Seasonality weights ────────────────────────────────────────────────────────
SEA = {
    "Jan": 0.060, "Feb": 0.075, "Mar": 0.090,
    "Apr": 0.085, "May": 0.085, "Jun": 0.085,
    "Jul": 0.090, "Aug": 0.095, "Sep": 0.095,
    "Oct": 0.090, "Nov": 0.085, "Dec": 0.065,
}
MONTHS = list(SEA.keys())

# ── Annual revenue ─────────────────────────────────────────────────────────────
REV_2025 = 308.0
REV_2025B = 318.0
REV_2024 = 295.0

# Monthly revenue
monthly_rev_2025 = {m: REV_2025 * SEA[m] for m in MONTHS}
monthly_rev_2024 = {m: REV_2024 * SEA[m] for m in MONTHS}

# ── Margin structures ──────────────────────────────────────────────────────────
# 2025 Actual
A25 = dict(
    dl=0.720, wcb=0.088, cos=0.808, gp=0.192,
    bsga=0.072, cga=0.043, sga=0.115, ebitda=0.077,
    da=0.015, interest_mo=0.488, tax=0.25,
    capex=0.008, amort_mo=0.052,
)
# 2025 Budget
B25 = dict(
    dl=0.720, wcb=0.080, cos=0.800, gp=0.200,
    bsga=0.075, cga=0.045, sga=0.120, ebitda=0.080,
)
# 2024 Actual
A24 = dict(
    dl=0.720, wcb=0.085, cos=0.805, gp=0.195,
    bsga=0.075, cga=0.043, sga=0.118, ebitda=0.077,
    da=0.015, interest_mo=0.488,
)

# ── Helper styles ──────────────────────────────────────────────────────────────
def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, color="000000", size=11, italic=False):
    return Font(bold=bold, color=color, size=size, italic=italic, name="Calibri")

def center():
    return Alignment(horizontal="center", vertical="center", wrap_text=True)

def left():
    return Alignment(horizontal="left", vertical="center")

def right():
    return Alignment(horizontal="right", vertical="center")

thin = Side(style="thin", color="BFBFBF")
thick = Side(style="medium", color="595959")

def thin_border():
    return Border(left=thin, right=thin, top=thin, bottom=thin)

def bottom_thick():
    return Border(bottom=thick)

def set_col_width(ws, col, width):
    ws.column_dimensions[get_column_letter(col)].width = width

def header_row(ws, row, texts, start_col=1):
    """Navy header row with white bold text."""
    for i, t in enumerate(texts):
        c = ws.cell(row=row, column=start_col + i, value=t)
        c.fill = fill(NAVY)
        c.font = font(bold=True, color=WHITE, size=10)
        c.alignment = center()
        c.border = thin_border()

def money(v):
    """Round to 1 decimal for display."""
    return round(v, 1)

def pct(v):
    return round(v * 100, 1)

def fmt_var_pct(actual, budget):
    if budget == 0:
        return 0.0
    return round((actual - budget) / abs(budget) * 100, 1)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
def build_summary(wb):
    ws = wb.create_sheet("Summary")
    ws.sheet_properties.tabColor = AMBER

    # Column widths
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 17
    ws.column_dimensions["C"].width = 17
    ws.column_dimensions["D"].width = 17
    ws.column_dimensions["E"].width = 13
    ws.column_dimensions["F"].width = 17
    ws.column_dimensions["G"].width = 17
    ws.column_dimensions["H"].width = 13

    # ── Header block ──────────────────────────────────────────────────────────
    r = 1
    ws.merge_cells(f"A{r}:H{r}")
    c = ws.cell(row=r, column=1, value="Patriot Staffing Solutions — Management Package")
    c.font = font(bold=True, size=16, color=NAVY)
    c.alignment = left()
    ws.row_dimensions[r].height = 28

    r = 2
    ws.merge_cells(f"A{r}:H{r}")
    c = ws.cell(row=r, column=1,
                value="December 2025 / Full Year 2025 | Northwood Capital Fund II")
    c.font = font(size=12, color=DARK_GREY)
    c.alignment = left()

    r = 3
    ws.merge_cells(f"A{r}:H{r}")
    c = ws.cell(row=r, column=1,
                value="Deal Lead: Andrew Walsh  |  RAG Status: \u25cf AMBER  |  Prepared: February 2026")
    c.font = Font(bold=True, size=11, color=AMBER, name="Calibri")
    c.alignment = left()

    r = 4  # blank spacer

    # ── Section 2 — Key Metrics ───────────────────────────────────────────────
    r = 5
    ws.merge_cells(f"A{r}:H{r}")
    c = ws.cell(row=r, column=1, value="Key Financial Metrics — Full Year 2025")
    c.font = font(bold=True, size=12, color=NAVY)
    c.alignment = left()

    r = 6
    header_row(ws, r,
               ["Metric", "FY 2025 Actual", "FY 2025 Budget",
                "Variance ($)", "Variance (%)", "FY 2024 Actual", "YoY ($)", "YoY (%)"])

    # Data rows
    metrics = [
        # label, act25, bud25, var$, var%, act24, yoy$, yoy%, is_margin, neg_bad
        ("Revenue ($M)",         308.0, 318.0, -10.0, "-3.1%", 295.0, "+$13.0M", "+4.4%", False, True),
        ("Cost of Services ($M)",249.3, 254.4, "+$5.1M", "+2.0%", 237.5, "+$11.8M", "+4.9%", False, False),
        ("Gross Profit ($M)",    58.7,  63.6,  -4.9, "-7.7%",  57.5,  "+$1.2M",  "+2.1%", False, True),
        ("Gross Margin %",       "19.2%","20.0%","-80bps","—","19.5%","-30bps","—", True, True),
        ("EBITDA ($M)",          23.7,  25.4,  -1.7, "-6.7%",  22.7,  "+$1.0M",  "+4.4%", False, True),
        ("EBITDA Margin %",      "7.7%","8.0%", "-30bps","—","7.7%","0bps","—", True, True),
        ("Net Debt ($M)",        54.7,  "—",   "—",  "—",      56.3,  "—",       "—",     False, False),
        ("Net Leverage (x)",     "2.3x","—",   "—",  "—",      "2.5x","—",       "—",     False, False),
    ]

    for i, row_data in enumerate(metrics):
        rr = 7 + i
        label, a25, b25, vd, vp, a24, yoy_d, yoy_p, is_m, neg_bad = row_data
        row_fill = fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE)
        cells_vals = [label, a25, b25, vd, vp, a24, yoy_d, yoy_p]
        for j, v in enumerate(cells_vals):
            c = ws.cell(row=rr, column=1 + j, value=v)
            c.fill = row_fill
            c.border = thin_border()
            is_label = (j == 0)
            is_bold = is_label
            c.font = font(bold=is_bold, size=10)
            c.alignment = left() if is_label else center()
            # Red variance columns
            if j in (3, 4) and neg_bad:
                if isinstance(v, str) and ("−" in v or "-" in v or "bps" in v):
                    c.font = font(bold=False, color=RED, size=10)
                elif isinstance(v, (int, float)) and v < 0:
                    c.font = font(bold=False, color=RED, size=10)

        # Bold for GP, EBITDA rows
        if "Gross Profit" in label or "EBITDA ($M)" in label:
            for j in range(8):
                ws.cell(row=rr, column=1 + j).font = font(bold=True, size=10)
                if j in (3, 4) and neg_bad:
                    ws.cell(row=rr, column=1 + j).font = font(bold=True, color=RED, size=10)

    # ── Section 3 — Commentary ────────────────────────────────────────────────
    r = 16
    ws.merge_cells(f"A{r}:H{r}")
    c = ws.cell(row=r, column=1, value="Management Commentary — Full Year 2025")
    c.font = font(bold=True, size=12, color=NAVY)
    c.alignment = left()

    bullets = [
        "\u2022  Full year 2025 revenue of $308.0M, -3.1% vs. budget due to softer demand in H2 from select manufacturing clients. "
        "EBITDA of $23.7M, -$1.7M vs. budget. Gross margin of 19.2% vs. 20.0% budget — compression driven by wage inflation "
        "(+8% YoY for temp workers) outpacing bill rate increases (+5%).",

        "\u2022  AMBER status maintained from Q3 2025. Management initiated bill rate renegotiations with 28 client accounts in Q4. "
        "Early results: average bill rate increased $0.15/hr vs. target $0.50/hr. Full renegotiation cycle expected Q1-Q2 2026. "
        "Operating Partner resource gap noted — Andrew Walsh managing operational engagement directly with CFO and COO.",

        "\u2022  Workers compensation loss ratio trending above plan at 68% vs. 62% budget. Management engaged external WC claims "
        "consultant in December. Near-term mitigation: enhanced return-to-work program, pre-placement safety screening. "
        "Revolver $5.0M drawn vs. $0M prior year — seasonal working capital usage; expected repayment Q1 2026.",
    ]

    for i, bullet in enumerate(bullets):
        rr = 17 + i * 2
        ws.merge_cells(f"A{rr}:H{rr}")
        ws.row_dimensions[rr].height = 48
        c = ws.cell(row=rr, column=1, value=bullet)
        c.font = font(size=10)
        c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        if i % 2 == 0:
            c.fill = fill(GREY_LIGHT)

    # ── Section 4 — AMBER Action Tracker ─────────────────────────────────────
    r = 24
    ws.merge_cells(f"A{r}:H{r}")
    c = ws.cell(row=r, column=1,
                value="AMBER Status — Action Tracker  |  Next Review: March 19, 2026 Board")
    c.font = font(bold=True, size=12, color=AMBER)
    c.alignment = left()
    c.fill = fill(AMBER_LIGHT)

    r = 25
    header_row(ws, r, ["Action Item", "Owner", "Status", "Target Date", "Progress"],
               start_col=1)
    # Merge cols 5-8 for Progress
    ws.merge_cells(f"E{r}:H{r}")

    actions = [
        ("Bill rate renegotiations (28 priority accounts)", "Linda Crawford, CEO",
         "In Progress", "Q1-Q2 2026",
         "12/28 accounts initiated; avg +$0.15/hr vs. $0.50/hr target"),
        ("WC loss ratio reduction program", "Brian Mitchell, COO",
         "Initiated", "Q2 2026",
         "External consultant engaged Dec 2025"),
        ("Client contract amendments (rate escalation clauses)", "Thomas Nguyen, CFO",
         "In Progress", "Mar 2026",
         "8 contracts amended; 20 in negotiation"),
        ("Operating consultant evaluation (Northwood internal)", "Andrew Walsh",
         "Under Review", "Feb 2026",
         "Board to assess external consultant engagement"),
        ("Add-on acquisition pipeline activation (post-margin recovery)", "Andrew Walsh",
         "On Hold", "H2 2026",
         "Deferred pending margin stabilization"),
    ]

    status_colors = {
        "In Progress": "00B050",
        "Initiated":   AMBER,
        "Under Review":AMBER,
        "On Hold":     "595959",
    }

    for i, (action, owner, status, target, progress) in enumerate(actions):
        rr = 26 + i
        row_fill = fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE)
        ws.row_dimensions[rr].height = 30
        for j, v in enumerate([action, owner, status, target, progress]):
            col = 1 + j
            if j == 4:
                ws.merge_cells(f"E{rr}:H{rr}")
            c = ws.cell(row=rr, column=col, value=v)
            c.fill = row_fill
            c.border = thin_border()
            c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 2:  # Status column
                sc = status_colors.get(status, "000000")
                c.font = font(bold=True, color=sc, size=10)
            else:
                c.font = font(size=10)

    return ws


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — P&L
# ══════════════════════════════════════════════════════════════════════════════
def build_pl(wb):
    ws = wb.create_sheet("P&L")
    ws.sheet_properties.tabColor = AMBER

    # Column widths
    ws.column_dimensions["A"].width = 30
    for col in range(2, 16):  # Jan-Dec
        ws.column_dimensions[get_column_letter(col)].width = 9
    for col in range(15, 24):
        ws.column_dimensions[get_column_letter(col)].width = 13

    # Title
    last_col = 23
    ws.merge_cells(f"A1:{get_column_letter(last_col)}1")
    c = ws.cell(row=1, column=1,
                value="Income Statement — Full Year 2025 | Actuals vs. Budget vs. Prior Year ($M)")
    c.font = font(bold=True, size=14, color=NAVY)
    c.alignment = left()
    ws.row_dimensions[1].height = 22

    # Column headers row 2
    col_headers = (
        [""] +
        MONTHS +
        ["FY 2025 Actual", "FY 2025 Budget", "Var $", "Var %",
         "FY 2024 Actual", "YoY $", "YoY %"]
    )
    header_row(ws, 2, col_headers)

    # Compute monthly figures
    def monthly_line(rev_dict, pct_val):
        return {m: money(rev_dict[m] * pct_val) for m in MONTHS}

    rev25 = monthly_rev_2025
    rev24 = monthly_rev_2024

    # 2025 Actual lines
    dl25  = monthly_line(rev25, A25["dl"])
    wcb25 = monthly_line(rev25, A25["wcb"])
    cos25 = {m: money(dl25[m] + wcb25[m]) for m in MONTHS}
    gp25  = {m: money(rev25[m] - cos25[m]) for m in MONTHS}
    bsga25= monthly_line(rev25, A25["bsga"])
    cga25 = monthly_line(rev25, A25["cga"])
    sga25 = {m: money(bsga25[m] + cga25[m]) for m in MONTHS}
    ebitda25 = {m: money(gp25[m] - sga25[m]) for m in MONTHS}
    da25     = monthly_line(rev25, A25["da"])
    ebit25   = {m: money(ebitda25[m] - da25[m]) for m in MONTHS}
    int25    = {m: A25["interest_mo"] for m in MONTHS}
    ebt25    = {m: money(ebit25[m] - int25[m]) for m in MONTHS}
    tax25    = {m: money(max(ebt25[m] * A25["tax"], 0)) for m in MONTHS}
    ni25     = {m: money(ebt25[m] - tax25[m]) for m in MONTHS}

    # 2024 Actual lines (annual for totals)
    rev24_ann = REV_2024
    dl24_ann  = money(rev24_ann * A24["dl"])
    wcb24_ann = money(rev24_ann * A24["wcb"])
    cos24_ann = money(dl24_ann + wcb24_ann)
    gp24_ann  = money(rev24_ann - cos24_ann)
    bsga24_ann= money(rev24_ann * A24["bsga"])
    cga24_ann = money(rev24_ann * A24["cga"])
    sga24_ann = money(bsga24_ann + cga24_ann)
    ebitda24_ann = money(gp24_ann - sga24_ann)
    da24_ann  = money(rev24_ann * A24["da"])
    ebit24_ann = money(ebitda24_ann - da24_ann)
    int24_ann  = money(A24["interest_mo"] * 12)
    ebt24_ann  = money(ebit24_ann - int24_ann)
    tax24_ann  = money(max(ebt24_ann * 0.25, 0))
    ni24_ann   = money(ebt24_ann - tax24_ann)

    # 2025 Budget annual
    rev25b_ann = REV_2025B
    dl25b_ann  = money(rev25b_ann * B25["dl"])
    wcb25b_ann = money(rev25b_ann * B25["wcb"])
    cos25b_ann = money(dl25b_ann + wcb25b_ann)
    gp25b_ann  = money(rev25b_ann - cos25b_ann)
    bsga25b_ann= money(rev25b_ann * B25["bsga"])
    cga25b_ann = money(rev25b_ann * B25["cga"])
    sga25b_ann = money(bsga25b_ann + cga25b_ann)
    ebitda25b_ann = money(gp25b_ann - sga25b_ann)

    def fy(d):
        return money(sum(d.values()))

    # Row definitions: (label, monthly_dict_or_None, fy_actual, fy_budget, fy_2024,
    #                   is_bold, is_italic, is_pct, is_blank, highlight)
    rows = [
        # label, monthly, fy_act, fy_bud, fy_24, bold, italic, pct, blank, highlight
        ("Revenue",
         rev25, REV_2025, REV_2025B, REV_2024, True, False, False, False, False),
        ("Direct Labor (wages + payroll taxes)",
         dl25,  money(REV_2025*A25["dl"]), dl25b_ann, dl24_ann, False, False, False, False, False),
        ("Workers Comp & Benefits",
         wcb25, money(REV_2025*A25["wcb"]), wcb25b_ann, wcb24_ann, False, False, False, False, True),
        ("Cost of Services",
         cos25, money(REV_2025*A25["cos"]), cos25b_ann, cos24_ann, True, False, False, False, False),
        ("Gross Profit",
         gp25,  money(REV_2025*A25["gp"]), gp25b_ann, gp24_ann, True, False, False, False, False),
        ("Gross Margin %",
         None,  pct(A25["gp"]), pct(B25["gp"]), pct(A24["gp"]), False, True, True, False, False),
        ("",
         None, None, None, None, False, False, False, True, False),
        ("Branch SG&A",
         bsga25, money(REV_2025*A25["bsga"]), bsga25b_ann, bsga24_ann, False, False, False, False, False),
        ("Corporate G&A",
         cga25,  money(REV_2025*A25["cga"]), cga25b_ann, cga24_ann, False, False, False, False, False),
        ("Total SG&A",
         sga25,  money(REV_2025*A25["sga"]), sga25b_ann, sga24_ann, True, False, False, False, False),
        ("",
         None, None, None, None, False, False, False, True, False),
        ("EBITDA",
         ebitda25, money(REV_2025*A25["ebitda"]), ebitda25b_ann, ebitda24_ann, True, False, False, False, False),
        ("EBITDA Margin %",
         None, pct(A25["ebitda"]), pct(B25["ebitda"]), pct(A24["ebitda"]), False, True, True, False, False),
        ("",
         None, None, None, None, False, False, False, True, False),
        ("D&A",
         da25, money(REV_2025*A25["da"]), None, da24_ann, False, False, False, False, False),
        ("EBIT",
         ebit25, money(REV_2025*A25["ebitda"] - REV_2025*A25["da"]), None, ebit24_ann, True, False, False, False, False),
        ("Interest Expense",
         int25, A25["interest_mo"]*12, None, int24_ann, False, False, False, False, False),
        ("Earnings Before Tax",
         ebt25, money(sum(ebt25.values())), None, ebt24_ann, False, False, False, False, False),
        ("Income Tax (25%)",
         tax25, money(sum(tax25.values())), None, tax24_ann, False, False, False, False, False),
        ("Net Income",
         ni25,  money(sum(ni25.values())), None, ni24_ann, True, False, False, False, False),
    ]

    for i, (label, monthly, fy_act, fy_bud, fy_24, bold, italic, is_pct, blank, highlight) in enumerate(rows):
        rr = 3 + i
        row_fill = fill(AMBER_LIGHT) if highlight else (fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE))

        if blank:
            ws.row_dimensions[rr].height = 6
            continue

        # Label
        c = ws.cell(row=rr, column=1, value=label)
        c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = left()
        c.border = thin_border()

        # Monthly values
        for mi, m in enumerate(MONTHS):
            col = 2 + mi
            if monthly is not None:
                val = monthly[m]
                c = ws.cell(row=rr, column=col, value=val)
                if is_pct:
                    c.number_format = "0.0\"%\""
                else:
                    c.number_format = "#,##0.0"
            else:
                c = ws.cell(row=rr, column=col, value="")
            c.font = font(bold=bold, italic=italic, size=9)
            c.fill = row_fill
            c.alignment = right()
            c.border = thin_border()

        # FY 2025 Actual
        col = 14
        if fy_act is not None:
            c = ws.cell(row=rr, column=col, value=fy_act)
            c.number_format = "0.0\"%\"" if is_pct else "#,##0.0"
        else:
            c = ws.cell(row=rr, column=col, value="")
        c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

        # FY 2025 Budget
        col = 15
        if fy_bud is not None:
            c = ws.cell(row=rr, column=col, value=fy_bud)
            c.number_format = "0.0\"%\"" if is_pct else "#,##0.0"
        else:
            c = ws.cell(row=rr, column=col, value="—")
        c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

        # Var $
        col = 16
        if fy_act is not None and fy_bud is not None and not is_pct:
            var_d = money(fy_act - fy_bud)
            c = ws.cell(row=rr, column=col, value=var_d)
            c.number_format = "#,##0.0"
            is_neg = var_d < 0
            # Revenue, GP, EBITDA: neg is bad (red); costs: pos is bad
            bad_labels = ("Revenue", "Gross Profit", "EBITDA", "Net Income", "EBIT", "Earnings")
            good_bad = any(bl in label for bl in bad_labels)
            if good_bad and is_neg:
                c.font = font(bold=bold, color=RED, size=10)
            else:
                c.font = font(bold=bold, size=10)
        else:
            c = ws.cell(row=rr, column=col, value="—" if is_pct else "")
            c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

        # Var %
        col = 17
        if fy_act is not None and fy_bud is not None and not is_pct:
            vp = fmt_var_pct(fy_act, fy_bud)
            c = ws.cell(row=rr, column=col, value=f"{vp:+.1f}%")
            bad_labels = ("Revenue", "Gross Profit", "EBITDA", "Net Income", "EBIT", "Earnings")
            if any(bl in label for bl in bad_labels) and vp < 0:
                c.font = font(bold=bold, color=RED, size=10)
            else:
                c.font = font(bold=bold, size=10)
        else:
            c = ws.cell(row=rr, column=col, value="—")
            c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

        # FY 2024 Actual
        col = 18
        if fy_24 is not None:
            c = ws.cell(row=rr, column=col, value=fy_24)
            c.number_format = "0.0\"%\"" if is_pct else "#,##0.0"
        else:
            c = ws.cell(row=rr, column=col, value="—")
        c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

        # YoY $
        col = 19
        if fy_act is not None and fy_24 is not None and not is_pct:
            yoy_d = money(fy_act - fy_24)
            c = ws.cell(row=rr, column=col, value=yoy_d)
            c.number_format = "#,##0.0"
            c.font = font(bold=bold, size=10)
        else:
            c = ws.cell(row=rr, column=col, value="—")
            c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

        # YoY %
        col = 20
        if fy_act is not None and fy_24 is not None and not is_pct:
            yp = fmt_var_pct(fy_act, fy_24)
            c = ws.cell(row=rr, column=col, value=f"{yp:+.1f}%")
            c.font = font(bold=bold, size=10)
        else:
            c = ws.cell(row=rr, column=col, value="—")
            c.font = font(bold=bold, italic=italic, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

    return ws


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — BALANCE SHEET
# ══════════════════════════════════════════════════════════════════════════════
def build_bs(wb):
    ws = wb.create_sheet("Balance Sheet")
    ws.sheet_properties.tabColor = AMBER

    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 16
    ws.column_dimensions["D"].width = 16

    # Title
    ws.merge_cells("A1:D1")
    c = ws.cell(row=1, column=1,
                value="Balance Sheet | Northwood Capital Portco Reporting ($M)")
    c.font = font(bold=True, size=14, color=NAVY)
    c.alignment = left()
    ws.row_dimensions[1].height = 22

    # Column headers
    header_row(ws, 2, ["", "Dec 2025", "Nov 2025", "Dec 2024"])

    # Balance sheet data
    # Dec 2025 | Nov 2025 | Dec 2024
    assets = [
        ("ASSETS", None, None, None, True, True),
        ("Cash & Equivalents", 3.2, 2.8, 4.5, False, False),
        ("Accounts Receivable", 32.1, 33.5, 30.8, False, False),
        ("Prepaid & Other Current", 2.1, 2.0, 1.9, False, False),
        ("Total Current Assets", None, None, None, True, False),  # computed
        ("", None, None, None, False, True),
        ("PP&E, net", 4.1, 4.3, 4.8, False, False),
        ("Goodwill", 128.5, 128.5, 128.5, False, False),
        ("Other Intangibles, net", 18.2, 18.8, 21.0, False, False),
        ("Other Long-Term Assets", 1.5, 1.5, 1.4, False, False),
        ("Total Assets", None, None, None, True, False),
    ]

    # Current assets sums
    ca_dec = 3.2 + 32.1 + 2.1     # 37.4
    ca_nov = 2.8 + 33.5 + 2.0     # 38.3
    ca_dec24 = 4.5 + 30.8 + 1.9   # 37.2

    ta_dec  = ca_dec  + 4.1 + 128.5 + 18.2 + 1.5   # 189.8
    ta_nov  = ca_nov  + 4.3 + 128.5 + 18.8 + 1.5   # 191.4
    ta_dec24= ca_dec24+ 4.8 + 128.5 + 21.0 + 1.4   # 192.9

    liab = [
        ("LIABILITIES & EQUITY", None, None, None, True, True),
        ("Accounts Payable", 5.2, 5.5, 5.0, False, False),
        ("Accrued Payroll & Benefits", 8.3, 8.8, 7.9, False, False),
        ("Accrued Expenses & Other", 3.8, 3.6, 3.4, False, False),
        ("Current Portion of Revolver", 5.0, 5.0, 0.0, False, False),
        ("Current Portion of LTD", 0.6, 0.6, 0.7, False, False),
        ("Total Current Liabilities", None, None, None, True, False),
        ("", None, None, None, False, True),
        ("Long-Term Debt", 61.4, 61.7, 62.3, False, False),
        ("Deferred Tax & Other", 2.8, 2.8, 2.6, False, False),
        ("Total Liabilities", None, None, None, True, False),
        ("", None, None, None, False, True),
        ("Total Equity", None, None, None, True, False),
        ("Total Liabilities & Equity", None, None, None, True, False),
    ]

    cl_dec  = 5.2 + 8.3 + 3.8 + 5.0 + 0.6  # 22.9
    cl_nov  = 5.5 + 8.8 + 3.6 + 5.0 + 0.6  # 23.5
    cl_dec24= 5.0 + 7.9 + 3.4 + 0.0 + 0.7  # 17.0

    tl_dec  = cl_dec  + 61.4 + 2.8  # 87.1
    tl_nov  = cl_nov  + 61.7 + 2.8  # 88.0
    tl_dec24= cl_dec24+ 62.3 + 2.6  # 81.9

    eq_dec  = money(ta_dec   - tl_dec)
    eq_nov  = money(ta_nov   - tl_nov)
    eq_dec24= money(ta_dec24 - tl_dec24)

    # Resolve "computed" rows
    computed_assets = {
        "Total Current Assets": (ca_dec, ca_nov, ca_dec24),
        "Total Assets":         (ta_dec, ta_nov, ta_dec24),
    }
    computed_liab = {
        "Total Current Liabilities": (cl_dec, cl_nov, cl_dec24),
        "Total Liabilities":         (tl_dec, tl_nov, tl_dec24),
        "Total Equity":              (eq_dec, eq_nov, eq_dec24),
        "Total Liabilities & Equity":(ta_dec, ta_nov, ta_dec24),
    }

    all_rows = assets + liab
    for i, (label, d25, n25, d24, bold, is_section) in enumerate(all_rows):
        rr = 3 + i
        ws.row_dimensions[rr].height = 16 if not is_section else 18

        if label == "" and not is_section:
            ws.row_dimensions[rr].height = 6
            continue

        # Resolve computed
        if label in computed_assets:
            d25, n25, d24 = computed_assets[label]
        if label in computed_liab:
            d25, n25, d24 = computed_liab[label]

        if is_section and label == "":
            continue

        row_fill = fill(NAVY) if is_section else (fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE))
        fc = WHITE if is_section else "000000"

        c = ws.cell(row=rr, column=1, value=label)
        c.font = font(bold=bold, color=fc, size=10)
        c.fill = row_fill
        c.alignment = left()
        c.border = thin_border()

        for j, v in enumerate([d25, n25, d24]):
            col = 2 + j
            if v is not None:
                c = ws.cell(row=rr, column=col, value=v)
                c.number_format = "#,##0.0"
            else:
                c = ws.cell(row=rr, column=col, value="")
            c.font = font(bold=bold, color=fc, size=10)
            c.fill = row_fill
            c.alignment = right()
            c.border = thin_border()

    # Key Ratios
    rr_start = 3 + len(all_rows) + 1
    ws.merge_cells(f"A{rr_start}:D{rr_start}")
    c = ws.cell(row=rr_start, column=1, value="Key Ratios")
    c.font = font(bold=True, size=11, color=NAVY)
    c.alignment = left()

    net_debt_dec  = money(61.4 + 5.0 + 0.6 - 3.2)   # 63.8 - 3.2 = 63.8 → 63.8
    net_debt_dec  = money(tl_dec - 2.8 - eq_dec - 3.2 + 3.2)
    # simpler: (LTD + revolver + current LTD) - cash
    net_debt_dec  = money(61.4 + 5.0 + 0.6 - 3.2)    # = 63.8
    net_debt_dec24= money(62.3 + 0.0 + 0.7 - 4.5)    # = 58.5

    ratios = [
        ("Net Debt ($M)", net_debt_dec, "—", net_debt_dec24),
        ("LTM EBITDA ($M)", 23.7, "—", 22.7),
        ("Net Leverage (x)", f"{money(net_debt_dec/23.7):.1f}x", "—", f"{money(net_debt_dec24/22.7):.1f}x"),
    ]

    for i, (label, d25, n25, d24) in enumerate(ratios):
        rr = rr_start + 1 + i
        for j, v in enumerate([label, d25, n25, d24]):
            c = ws.cell(row=rr, column=1 + j, value=v)
            c.font = font(bold=(j == 0), size=10)
            c.fill = fill(AMBER_LIGHT)
            c.alignment = left() if j == 0 else center()
            c.border = thin_border()

    # Note
    rr_note = rr_start + len(ratios) + 2
    ws.merge_cells(f"A{rr_note}:D{rr_note}")
    c = ws.cell(row=rr_note, column=1,
                value="Note: Revolver drawn $5.0M at Dec 2025 for seasonal working capital needs. "
                      "Expected repayment by end of Q1 2026.")
    c.font = font(italic=True, size=9, color=DARK_GREY)
    c.alignment = Alignment(horizontal="left", wrap_text=True)

    return ws


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — CASH FLOW
# ══════════════════════════════════════════════════════════════════════════════
def build_cf(wb):
    ws = wb.create_sheet("Cash Flow")
    ws.sheet_properties.tabColor = AMBER

    ws.column_dimensions["A"].width = 32
    for col in range(2, 16):
        ws.column_dimensions[get_column_letter(col)].width = 9
    ws.column_dimensions[get_column_letter(15)].width = 13

    ws.merge_cells("A1:O1")
    c = ws.cell(row=1, column=1,
                value="Statement of Cash Flows — Monthly 2025 ($M)")
    c.font = font(bold=True, size=14, color=NAVY)
    c.alignment = left()
    ws.row_dimensions[1].height = 22

    col_headers = [""] + MONTHS + ["FY 2025 Total"]
    header_row(ws, 2, col_headers)

    rev = monthly_rev_2025

    # EBITDA monthly
    ebitda_mo = {m: money(rev[m] * A25["ebitda"]) for m in MONTHS}
    da_mo = {m: money(rev[m] * A25["da"]) for m in MONTHS}

    # NWC: AR-driven. AR ≈ revenue × (38/365) * 12 months scaling.
    # Monthly change in NWC ≈ change in AR ≈ change in (monthly_rev × 10.4%)
    nwc_factor = 0.104
    ar_balance = {m: money(rev[m] * nwc_factor * 12) for m in MONTHS}
    months_list = MONTHS
    prev_ar = {m: 0.0 for m in MONTHS}
    for i, m in enumerate(months_list):
        if i == 0:
            # Jan: compare to Dec 2024
            dec24_rev = monthly_rev_2024["Dec"]
            prev_ar[m] = money(dec24_rev * nwc_factor * 12)
        else:
            prev_m = months_list[i - 1]
            prev_ar[m] = ar_balance[prev_m]
    nwc_change = {m: money(-(ar_balance[m] - prev_ar[m])) for m in MONTHS}

    capex_mo = {m: money(-rev[m] * A25["capex"]) for m in MONTHS}
    debt_repay_mo = {m: -A25["amort_mo"] for m in MONTHS}

    # Revolver draws: Oct +2, Nov +1, Dec +2
    revolver = {m: 0.0 for m in MONTHS}
    revolver["Oct"] = 2.0
    revolver["Nov"] = 1.0
    revolver["Dec"] = 2.0

    int_mo = {m: -A25["interest_mo"] for m in MONTHS}
    tax_mo = {m: -money(max((ebitda_mo[m] - da_mo[m] + int_mo[m]) * A25["tax"], 0))
              for m in MONTHS}

    # CFO = EBITDA - D&A + D&A + NWC + interest + tax = Net income + D&A + NWC changes
    # Simplified: CFO = EBITDA + NWC_change + interest + tax
    cfo_mo = {m: money(ebitda_mo[m] + nwc_change[m] + int_mo[m] + tax_mo[m]) for m in MONTHS}
    cfi_mo = capex_mo
    cff_mo = {m: money(debt_repay_mo[m] + revolver[m]) for m in MONTHS}
    net_cf = {m: money(cfo_mo[m] + cfi_mo[m] + cff_mo[m]) for m in MONTHS}

    # Opening cash Dec 2024 = 4.5
    opening = 4.5
    closing = {}
    for i, m in enumerate(MONTHS):
        if i == 0:
            closing[m] = money(opening + net_cf[m])
        else:
            prev = months_list[i - 1]
            closing[m] = money(closing[prev] + net_cf[m])

    def tot(d):
        return money(sum(d.values()))

    rows = [
        # label, monthly_dict, bold, is_section, indent
        ("OPERATING ACTIVITIES", None, True, True, False),
        ("EBITDA", ebitda_mo, True, False, False),
        ("Change in Working Capital (NWC)", nwc_change, False, False, True),
        ("Interest Expense", int_mo, False, False, True),
        ("Income Taxes Paid", tax_mo, False, False, True),
        ("Cash from Operations", cfo_mo, True, False, False),
        ("", None, False, False, False),
        ("INVESTING ACTIVITIES", None, True, True, False),
        ("Capital Expenditures", cfi_mo, False, False, True),
        ("Cash from Investing", cfi_mo, True, False, False),
        ("", None, False, False, False),
        ("FINANCING ACTIVITIES", None, True, True, False),
        ("Mandatory Debt Amortization", debt_repay_mo, False, False, True),
        ("Revolver Draw / (Repayment)", revolver, False, False, True),
        ("Cash from Financing", cff_mo, True, False, False),
        ("", None, False, False, False),
        ("Net Change in Cash", net_cf, True, False, False),
        ("Opening Cash Balance", None, False, False, True),
        ("Closing Cash Balance", closing, True, False, False),
    ]

    opening_row = {m: (opening if i == 0 else closing[months_list[i - 1]])
                   for i, m in enumerate(months_list)}

    # Fill opening for that special row
    for i_r, (label, monthly, bold, is_section, indent) in enumerate(rows):
        if label == "Opening Cash Balance":
            rows[i_r] = (label, opening_row, bold, is_section, indent)
            break

    for i, (label, monthly, bold, is_section, indent) in enumerate(rows):
        rr = 3 + i
        if label == "":
            ws.row_dimensions[rr].height = 6
            continue

        ws.row_dimensions[rr].height = 16

        row_fill = fill(NAVY) if is_section else (fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE))
        fc = WHITE if is_section else "000000"

        display_label = ("    " if indent else "") + label
        c = ws.cell(row=rr, column=1, value=display_label)
        c.font = font(bold=bold, color=fc, size=10)
        c.fill = row_fill
        c.alignment = left()
        c.border = thin_border()

        for mi, m in enumerate(MONTHS):
            col = 2 + mi
            if monthly is not None:
                v = monthly[m]
                c = ws.cell(row=rr, column=col, value=v)
                c.number_format = "#,##0.0"
            else:
                c = ws.cell(row=rr, column=col, value="")
            c.font = font(bold=bold, color=fc, size=9)
            c.fill = row_fill
            c.alignment = right()
            c.border = thin_border()

        # FY total
        col = 15
        if monthly is not None and label not in ("Opening Cash Balance", "Closing Cash Balance"):
            total_val = tot(monthly)
            c = ws.cell(row=rr, column=col, value=total_val)
            c.number_format = "#,##0.0"
        elif label == "Closing Cash Balance" and monthly is not None:
            # Show Dec closing
            c = ws.cell(row=rr, column=col, value=closing["Dec"])
            c.number_format = "#,##0.0"
        elif label == "Opening Cash Balance" and monthly is not None:
            c = ws.cell(row=rr, column=col, value=opening)
            c.number_format = "#,##0.0"
        else:
            c = ws.cell(row=rr, column=col, value="")
        c.font = font(bold=bold, color=fc, size=10)
        c.fill = row_fill
        c.alignment = right()
        c.border = thin_border()

    # FY 2024 summary note
    rr_note = 3 + len(rows) + 2
    ws.merge_cells(f"A{rr_note}:O{rr_note}")
    c = ws.cell(row=rr_note, column=1,
                value="FY 2024 Reference: Operating $21.5M | Investing -$2.4M | Financing -$0.8M | Net $18.3M")
    c.font = font(italic=True, size=9, color=DARK_GREY)
    c.alignment = left()

    return ws


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — KPI DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
def build_kpi(wb):
    ws = wb.create_sheet("KPI Dashboard")
    ws.sheet_properties.tabColor = AMBER

    ws.column_dimensions["A"].width = 32
    for col in "BCDEFGH":
        ws.column_dimensions[col].width = 15
    ws.column_dimensions["H"].width = 10

    # Title
    ws.merge_cells("A1:H1")
    c = ws.cell(row=1, column=1,
                value="KPI Dashboard — Q4 2025 / Full Year 2025 | Patriot Staffing Solutions | RAG: AMBER")
    c.font = font(bold=True, size=14, color=NAVY)
    c.alignment = left()
    ws.row_dimensions[1].height = 22

    # Section 1 — KPI Table
    ws.merge_cells("A2:H2")
    c = ws.cell(row=2, column=1, value="Operational KPIs")
    c.font = font(bold=True, size=11, color=AMBER)
    c.alignment = left()

    header_row(ws, 3, [
        "KPI", "Q4 2025 Actual", "Q4 2025 Budget", "Q4 2024 Actual",
        "FY 2025 Actual", "FY 2025 Budget", "FY 2024 Actual", "Status"
    ])

    kpi_rows = [
        # KPI, q4a, q4b, q424, fya, fyb, fy24, status (✓/✗/—), amber_row
        ("Revenue ($M)", "75.4", "77.8", "71.9", "308.0", "318.0", "295.0", "✗", True),
        ("Revenue Growth YoY", "4.9%", "8.2%", "5.3%", "4.4%", "7.8%", "—", "✗", True),
        ("Gross Margin %", "19.1%", "20.0%", "19.4%", "19.2%", "20.0%", "19.5%", "✗", True),
        ("EBITDA ($M)", "5.8", "6.2", "5.5", "23.7", "25.4", "22.7", "✗", True),
        ("EBITDA Margin %", "7.7%", "8.0%", "7.7%", "7.7%", "8.0%", "7.7%", "✗", True),
        ("Internal Headcount", "185", "183", "178", "185", "183", "178", "✓", False),
        ("Temp Workers on Assignment", "3,195", "3,280", "3,070", "3,195", "3,280", "3,070", "✗", True),
        ("Fill Rate %", "78.2%", "81.0%", "79.5%", "78.5%", "81.0%", "79.5%", "✗", True),
        ("Open Requisitions (unfilled)", "312", "240", "285", "312", "240", "285", "✗", True),
        ("DSO (days)", "38", "40", "37", "38", "40", "37", "✓", False),
        ("Active Client Count", "92", "94", "90", "92", "94", "90", "—", False),
        ("Workers Comp Loss Ratio %", "68.2%", "62.0%", "64.5%", "68.2%", "62.0%", "64.5%", "✗", True),
    ]

    for i, (kpi, q4a, q4b, q424, fya, fyb, fy24, status, amber_row) in enumerate(kpi_rows):
        rr = 4 + i
        row_fill = fill(AMBER_LIGHT) if amber_row and status == "✗" else (fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE))
        vals = [kpi, q4a, q4b, q424, fya, fyb, fy24, status]
        for j, v in enumerate(vals):
            c = ws.cell(row=rr, column=1 + j, value=v)
            c.fill = row_fill
            c.border = thin_border()
            if j == 0:
                c.font = font(bold=True, size=10)
                c.alignment = left()
            elif j == 7:  # Status
                if v == "✓":
                    c.font = font(bold=True, color=GREEN, size=11)
                elif v == "✗":
                    c.font = font(bold=True, color=RED, size=11)
                else:
                    c.font = font(bold=True, color=DARK_GREY, size=11)
                c.alignment = center()
            else:
                c.font = font(size=10)
                c.alignment = center()

    # ── Section 2 — Bill/Pay Spread Analysis ─────────────────────────────────
    r_spread = 4 + len(kpi_rows) + 2

    ws.merge_cells(f"A{r_spread}:H{r_spread}")
    c = ws.cell(row=r_spread, column=1,
                value="Bill Rate vs. Pay Rate Spread Analysis — The Margin Compression Story")
    c.font = font(bold=True, size=12, color=NAVY)
    c.fill = fill(NAVY)
    c.font = Font(bold=True, color=WHITE, size=12, name="Calibri")
    c.alignment = left()

    r_spread += 1
    header_row(ws, r_spread, [
        "Quarter", "Avg Bill Rate ($/hr)", "Avg Pay Rate ($/hr)",
        "Spread ($/hr)", "Spread %", "vs. Q1 2024 Baseline", "", ""
    ])

    spread_rows = [
        ("Q1 2024 (Baseline)", 21.00, 16.00, 5.00, "23.8%", "—", False),
        ("Q2 2024",            21.10, 16.45, 4.65, "22.0%", "-$0.35", True),
        ("Q3 2024",            21.25, 16.85, 4.40, "20.7%", "-$0.60", True),
        ("Q4 2024",            21.50, 17.00, 4.50, "20.9%", "-$0.50", True),
        ("Q1 2025",            21.75, 17.10, 4.65, "21.4%", "-$0.35", True),
        ("Q2 2025",            21.90, 17.20, 4.70, "21.5%", "-$0.30", True),
        ("Q3 2025",            22.05, 17.30, 4.75, "21.5%", "-$0.25", True),
        ("Q4 2025",            22.20, 17.40, 4.80, "21.6%", "-$0.20", True),
        ("Q4 2025 Budget",     22.20, 16.55, 5.65, "25.5%", "+$0.65", False),
    ]

    for i, (qtr, bill, pay, spread, spread_pct, vs_base, is_amber) in enumerate(spread_rows):
        rr = r_spread + 1 + i
        row_fill = fill(AMBER_LIGHT) if qtr == "Q4 2025 Budget" else (
            fill(GREY_LIGHT) if i % 2 == 0 else fill(WHITE))
        vals = [qtr, f"${bill:.2f}", f"${pay:.2f}", f"${spread:.2f}", spread_pct, vs_base, "", ""]
        for j, v in enumerate(vals):
            c = ws.cell(row=rr, column=1 + j, value=v)
            c.fill = row_fill
            c.border = thin_border()
            c.font = font(size=10, bold=(qtr in ("Q1 2024 (Baseline)", "Q4 2025 Budget")))
            c.alignment = left() if j == 0 else center()
            if j == 5 and isinstance(v, str) and v.startswith("-"):
                c.font = font(size=10, color=RED)

    # Note below spread table
    r_note = r_spread + 1 + len(spread_rows) + 1
    ws.merge_cells(f"A{r_note}:H{r_note}")
    ws.row_dimensions[r_note].height = 36
    c = ws.cell(row=r_note, column=1,
                value='Note: Spread of $4.80/hr vs. $5.65/hr budget (-$0.85/hr). At ~14.0M billable hours annually, '
                      'spread compression represents ~$11.9M gross profit shortfall vs. original underwriting. '
                      'Management bill rate renegotiations initiated Q4 2025 showing early traction — '
                      'Q4 2025 spread improved $0.10 vs. Q2 2025 trough.')
    c.font = font(italic=True, size=9, color=DARK_GREY)
    c.alignment = Alignment(horizontal="left", wrap_text=True, vertical="top")

    # ── Section 3 — EBITDA Bridge ─────────────────────────────────────────────
    r_bridge = r_note + 2

    ws.merge_cells(f"A{r_bridge}:H{r_bridge}")
    c = ws.cell(row=r_bridge, column=1,
                value="EBITDA Bridge — FY 2025 Actual vs. Budget ($M)")
    c.font = Font(bold=True, color=WHITE, size=12, name="Calibri")
    c.fill = fill(NAVY)
    c.alignment = left()

    r_bridge += 1
    header_row(ws, r_bridge, ["Driver", "Amount ($M)", "Description", "", "", "", "", ""])
    ws.merge_cells(f"C{r_bridge}:H{r_bridge}")

    bridge_rows = [
        ("FY 2025 Budget EBITDA", 25.4,
         "Base", GREY_LIGHT, False),
        ("Volume (revenue -$10M × 8.0% flow-through)", -0.8,
         "Revenue 3.1% below budget; demand softness in H2", RED_LIGHT, True),
        ("Gross Margin Compression (WC&Benefits rate)", -1.3,
         "Workers comp & benefits 80bps above budget on $308M revenue", RED_LIGHT, True),
        ("Workers Comp Loss Ratio", -0.5,
         "Loss ratio 620bps above budget", RED_LIGHT, True),
        ("SG&A Efficiency (below budget)", 0.9,
         "SG&A leverage partially offsets — below-budget revenue reduces variable branch costs", GREEN_LIGHT, False),
        ("FY 2025 Actual EBITDA", 23.7,
         "-$1.7M / -6.7% vs. budget", GREY_LIGHT, False),
    ]

    for i, (driver, amt, desc, row_color, is_neg) in enumerate(bridge_rows):
        rr = r_bridge + 1 + i
        ws.merge_cells(f"C{rr}:H{rr}")
        vals = [driver, amt, desc]
        for j, v in enumerate(vals):
            col = 1 + j
            c = ws.cell(row=rr, column=col if col <= 2 else 3, value=v)
            c.fill = fill(row_color)
            c.border = thin_border()
            is_total = driver in ("FY 2025 Budget EBITDA", "FY 2025 Actual EBITDA")
            if j == 0:
                c.font = font(bold=is_total, size=10)
                c.alignment = left()
            elif j == 1:
                c.font = font(bold=is_total, color=(RED if is_neg else "000000"), size=10)
                c.number_format = "#,##0.0"
                c.alignment = center()
            else:
                c.font = font(italic=True, size=9, color=DARK_GREY)
                c.alignment = left()

    r_bridge_note = r_bridge + 1 + len(bridge_rows) + 1
    ws.merge_cells(f"A{r_bridge_note}:H{r_bridge_note}")
    c = ws.cell(row=r_bridge_note, column=1,
                value="Bridge ties: $25.4 - $0.8 - $1.3 - $0.5 + $0.9 = $23.7M")
    c.font = font(italic=True, size=9, color=DARK_GREY)
    c.alignment = left()

    return ws


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    wb = Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    print("Building Summary tab...")
    build_summary(wb)

    print("Building P&L tab...")
    build_pl(wb)

    print("Building Balance Sheet tab...")
    build_bs(wb)

    print("Building Cash Flow tab...")
    build_cf(wb)

    print("Building KPI Dashboard tab...")
    build_kpi(wb)

    wb.save(OUT_FILE)
    print(f"\nFile saved: {OUT_FILE}")
    print(f"Size: {os.path.getsize(OUT_FILE) / 1024:.1f} KB")
    print(f"Tabs: {[ws.title for ws in wb.worksheets]}")


if __name__ == "__main__":
    main()
