# Northwood Capital — API Keys

> **READ-ONLY.** Do not modify this file. Read before any external API call.

## Supabase (Kith Climate Cohort Environments)

| Key | Value |
|-----|-------|
| Project ID | `qgwapnebycohurpegxfm` |
| URL | `https://qgwapnebycohurpegxfm.supabase.co` |
| Anon Key | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFnd2FwbmVieWNvaHVycGVneGZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM5NjMwODksImV4cCI6MjA4OTUzOTA4OX0.Tft4Lc2nE0hdHNEppx4BBy1khdiUpzrESgUqOw8j_88` |
| Schema | `northwood_capital` |

### Environment Variables

Set these before running any Python tools:

```bash
export SUPABASE_URL="https://qgwapnebycohurpegxfm.supabase.co"
export SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFnd2FwbmVieWNvaHVycGVneGZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM5NjMwODksImV4cCI6MjA4OTUzOTA4OX0.Tft4Lc2nE0hdHNEppx4BBy1khdiUpzrESgUqOw8j_88"
```
