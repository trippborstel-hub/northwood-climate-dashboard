#!/usr/bin/env python3
"""
Northwood Capital — Carbon Footprint Estimator

Reads portco-submitted consumption CSVs from _data/carbon/ and produces
a portfolio-level Scope 1 & 2 emissions estimate with intensity metrics.

Data collection template: _data/carbon/carbon-collection-template-YYYY.csv
Per-portco input files:    _data/carbon/{portco-slug}-{year}.csv

Usage:
    python tools/carbon_footprint.py --year 2025              # All portcos
    python tools/carbon_footprint.py --portco sterling-precision-manufacturing --year 2025
    python tools/carbon_footprint.py --year 2025 --json       # Machine-readable output
"""

import csv
import json
import re
import sys
import argparse
from pathlib import Path
from collections import defaultdict
from datetime import date

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rc_utils


# ============================================================
# EMISSION FACTORS
# Source: EPA Emission Factors for Greenhouse Gas Inventories (2023)
# Units: metric tons CO2e per unit of input
# ============================================================

# Scope 1 — Stationary Combustion
STATIONARY_FACTORS = {
    "natural_gas_therms": 0.005306,   # 53.06 kg CO2e/MMBtu × 0.1 MMBtu/therm
    "diesel_gallons":     0.010180,   # 22.46 lbs CO2/gal × 0.0004536 mt/lb
    "gasoline_gallons":   0.008780,   # 19.37 lbs CO2/gal × 0.0004536 mt/lb
    "propane_gallons":    0.005750,   # 12.68 lbs CO2/gal × 0.0004536 mt/lb
}

# Scope 1 — Refrigerant Leakage
# GWP values from IPCC AR4; converted: mt CO2e/lb = GWP × 0.0004536
REFRIGERANT_FACTORS = {
    "refrigerant_r22_lbs":   0.821,  # GWP 1,810
    "refrigerant_r410a_lbs": 0.947,  # GWP 2,088
}

# Scope 1 — Mobile Combustion (fleet)
MOBILE_FACTORS = {
    "fleet_diesel_gallons":   0.010180,
    "fleet_gasoline_gallons": 0.008780,
}

# Scope 2 — Electricity
# Source: EPA eGRID 2022 subregion averages, mapped to states
# Units: metric tons CO2e per kWh
STATE_ELEC_FACTOR = {
    # SERC-Illinois (coal-heavy)
    "IL": 0.000455,
    # MROE (Indiana, Ohio — coal)
    "IN": 0.000482, "OH": 0.000421,
    # MROW (Missouri, Iowa)
    "MO": 0.000497, "IA": 0.000320, "MN": 0.000300,
    # Mixed Midwest
    "MI": 0.000340, "WI": 0.000340, "KY": 0.000430,
    # RFCE — Mid-Atlantic (nuclear-heavy)
    "PA": 0.000260, "NJ": 0.000118, "MD": 0.000200,
    "VA": 0.000175, "DE": 0.000175,
    # NPCC — Northeast
    "NY": 0.000192, "MA": 0.000192, "CT": 0.000192,
    # SRSE — Southeast
    "GA": 0.000383, "FL": 0.000383, "NC": 0.000383, "SC": 0.000383,
    # SRSO / SRMW — South Central
    "TN": 0.000416, "AL": 0.000416, "MS": 0.000416,
    "AR": 0.000416, "LA": 0.000416,
    # ERCT — Texas
    "TX": 0.000405,
    # WECC — Southwest
    "AZ": 0.000370, "CO": 0.000370,
}

NATIONAL_AVG_ELEC = 0.000386  # US national average fallback


# ============================================================
# PORTCO METADATA
# ============================================================

PORTCO_META = {
    "meridian-business-solutions":      "Meridian Business Solutions",
    "novacare-health-partners":         "NovaCare Health Partners",
    "sterling-precision-manufacturing": "Sterling Precision Manufacturing",
    "trident-it-solutions":             "Trident IT Solutions",
    "clearview-environmental":          "Clearview Environmental Services",
    "patriot-staffing-solutions":       "Patriot Staffing Solutions",
    "keystone-behavioral-health":       "Keystone Behavioral Health",
    "pinnacle-testing":                 "Pinnacle Testing & Inspection",
}


# ============================================================
# DATA LOADING
# ============================================================

def _carbon_dir():
    return rc_utils._base_dir() / "_data" / "carbon"


def load_portco_csv(portco_slug, year):
    """Load a portco's consumption CSV for the given year.

    Returns list of row dicts, or None if file not found.
    Skips comment lines starting with '#'.
    """
    path = _carbon_dir() / f"{portco_slug}-{year}.csv"
    if not path.exists():
        return None
    rows = []
    with open(path, newline="") as f:
        reader = csv.DictReader(
            line for line in f if not line.strip().startswith("#")
        )
        for row in reader:
            rows.append(row)
    return rows


def load_all_portcos(year):
    """Load available CSVs for all portcos. Returns dict keyed by slug."""
    data = {}
    for slug in PORTCO_META:
        rows = load_portco_csv(slug, year)
        if rows:
            data[slug] = rows
    return data


def load_facility_headcount():
    """Parse facility register for headcount by facility_id and portco totals."""
    path = rc_utils._base_dir() / "_data" / "portfolio-facility-register.md"
    content = path.read_text()
    facility_hc = {}
    pattern = re.compile(r"\|\s*([A-Z]+-\d+)\s*\|[^|]+\|[^|]+\|[^|]+\|\s*(\d+)\s*\|")
    for match in pattern.finditer(content):
        fid = match.group(1)
        hc = int(match.group(2))
        facility_hc[fid] = hc
    return facility_hc


# ============================================================
# CALCULATIONS
# ============================================================

def safe_float(val, default=0.0):
    """Parse a string to float. Returns default for blank/invalid values."""
    if not val or str(val).strip() in ("", "N/A", "-", "n/a"):
        return default
    try:
        return float(str(val).replace(",", "").strip())
    except ValueError:
        return default


def compute_facility_emissions(row):
    """Compute Scope 1 and Scope 2 emissions for one facility row.

    Returns dict with emission subtotals and input quantities.
    All emission values in metric tons CO2e.
    """
    state = row.get("state", "").strip().upper()
    elec_factor = STATE_ELEC_FACTOR.get(state, NATIONAL_AVG_ELEC)

    # Scope 2 — Electricity
    electricity_kwh = safe_float(row.get("electricity_kwh"))
    scope2 = electricity_kwh * elec_factor

    # Scope 1 — Stationary Combustion
    scope1_stat = sum(
        safe_float(row.get(col)) * factor
        for col, factor in STATIONARY_FACTORS.items()
    )

    # Scope 1 — Refrigerant Leakage
    scope1_refrig = sum(
        safe_float(row.get(col)) * factor
        for col, factor in REFRIGERANT_FACTORS.items()
    )

    # Scope 1 — Mobile Combustion (fleet)
    scope1_mobile = sum(
        safe_float(row.get(col)) * factor
        for col, factor in MOBILE_FACTORS.items()
    )

    scope1_total = scope1_stat + scope1_refrig + scope1_mobile

    return {
        "scope1_stationary": scope1_stat,
        "scope1_refrigerant": scope1_refrig,
        "scope1_mobile":      scope1_mobile,
        "scope2_electricity": scope2,
        "scope1_total":       scope1_total,
        "total_mt_co2e":      scope1_total + scope2,
        "electricity_kwh":    electricity_kwh,
        "elec_factor":        elec_factor,
        "elec_factor_source": "eGRID" if state in STATE_ELEC_FACTOR else "national_avg",
    }


def compute_portco_emissions(rows, facility_headcount):
    """Aggregate facility emissions to portco level.

    Returns (portco_totals_dict, list_of_facility_result_dicts).
    """
    totals = defaultdict(float)
    facility_results = []

    for row in rows:
        result = compute_facility_emissions(row)
        fid = row.get("facility_id", "")
        hc = facility_headcount.get(fid, 0)
        combined = {**row, **result, "headcount": hc}
        facility_results.append(combined)
        for key in [
            "scope1_stationary", "scope1_refrigerant", "scope1_mobile",
            "scope2_electricity", "scope1_total", "total_mt_co2e",
            "electricity_kwh",
        ]:
            totals[key] += result[key]
        totals["headcount"] += hc

    return dict(totals), facility_results


# ============================================================
# HTML REPORT GENERATION
# ============================================================

def fmt_mt(val):
    """Format metric tons CO2e."""
    if val is None:
        return "N/A"
    if val >= 1000:
        return f"{val:,.0f}"
    if val > 0:
        return f"{val:.1f}"
    return "—"


def fmt_intensity(val):
    """Format intensity (mt CO2e per unit)."""
    if val is None or val == 0:
        return "N/A"
    return f"{val:.2f}"


def generate_html(portfolio_results, year, missing_portcos):
    """Generate the full HTML carbon footprint report."""

    # Portfolio totals
    port_scope1 = sum(r["scope1_total"] for r in portfolio_results.values())
    port_scope2 = sum(r["scope2_electricity"] for r in portfolio_results.values())
    port_total  = port_scope1 + port_scope2
    port_scope1_pct = f"{port_scope1 / port_total * 100:.0f}%" if port_total else "N/A"
    port_scope2_pct = f"{port_scope2 / port_total * 100:.0f}%" if port_total else "N/A"
    n_portcos   = len(portfolio_results)
    total_portcos = len(PORTCO_META)

    # Missing portcos notice
    missing_html = ""
    if missing_portcos:
        missing_names = ", ".join(PORTCO_META.get(s, s) for s in missing_portcos)
        missing_html = f"""
        <div style="background:#fff3cd;border-left:4px solid #856404;padding:12px 16px;margin:20px 0;font-size:13px;color:#856404;">
            <strong>Data Not Received:</strong> {missing_names} — no consumption CSV found for FY {year}.
            Portfolio totals reflect submitted portcos only. Proxy estimates should be substituted before final report.
        </div>"""

    # Portco summary rows
    portco_rows_html = []
    for slug, result in sorted(portfolio_results.items(), key=lambda x: -x[1]["total_mt_co2e"]):
        name = PORTCO_META.get(slug, slug)
        s1    = result["scope1_total"]
        s2    = result["scope2_electricity"]
        total = result["total_mt_co2e"]
        pct   = total / port_total * 100 if port_total > 0 else 0
        hc    = int(result.get("headcount", 0))
        intensity = total / hc if hc > 0 else None
        portco_rows_html.append(f"""
            <tr>
                <td><strong>{name}</strong></td>
                <td class="num">{fmt_mt(s1)}</td>
                <td class="num">{fmt_mt(s2)}</td>
                <td class="num"><strong>{fmt_mt(total)}</strong></td>
                <td class="num">{pct:.1f}%</td>
                <td class="num">{fmt_intensity(intensity)}</td>
            </tr>""")

    portco_rows_html.append(f"""
        <tr style="background:#1B2A3D;color:#fff;font-weight:600;">
            <td>Portfolio Total</td>
            <td class="num">{fmt_mt(port_scope1)}</td>
            <td class="num">{fmt_mt(port_scope2)}</td>
            <td class="num">{fmt_mt(port_total)}</td>
            <td class="num">100.0%</td>
            <td class="num">—</td>
        </tr>""")

    # Facility detail rows
    facility_rows_html = []
    for slug, result in sorted(portfolio_results.items(), key=lambda x: -x[1]["total_mt_co2e"]):
        name = PORTCO_META.get(slug, slug)
        for frow in result.get("facility_rows", []):
            f_total = frow.get("total_mt_co2e", 0)
            if f_total <= 0:
                continue
            fid    = frow.get("facility_id", "")
            city   = frow.get("city", "")
            state  = frow.get("state", "")
            ftype  = frow.get("facility_type", "")
            f_s1   = frow.get("scope1_total", 0)
            f_s2   = frow.get("scope2_electricity", 0)
            dsrc   = frow.get("data_source", "")
            estimate_flag = " *" if dsrc == "estimate" else ""
            facility_rows_html.append(f"""
            <tr>
                <td>{fid}</td>
                <td>{name}</td>
                <td>{ftype}</td>
                <td>{city}, {state}</td>
                <td class="num">{fmt_mt(f_s1)}</td>
                <td class="num">{fmt_mt(f_s2)}</td>
                <td class="num"><strong>{fmt_mt(f_total)}</strong>{estimate_flag}</td>
            </tr>""")

    if not facility_rows_html:
        facility_rows_html.append(
            '<tr><td colspan="7" style="text-align:center;color:#888;">No facility-level data available.</td></tr>'
        )

    # Emission factor table rows
    factor_rows = [
        ("Natural gas",        "per therm",   "0.005306", "EPA 2023 — 53.06 kg CO₂e/MMBtu"),
        ("Diesel (stationary)","per gallon",  "0.010180", "EPA 2023 — 22.46 lbs CO₂/gal"),
        ("Gasoline (stationary)","per gallon","0.008780", "EPA 2023 — 19.37 lbs CO₂/gal"),
        ("Propane",            "per gallon",  "0.005750", "EPA 2023 — 12.68 lbs CO₂/gal"),
        ("Fleet diesel",       "per gallon",  "0.010180", "EPA 2023"),
        ("Fleet gasoline",     "per gallon",  "0.008780", "EPA 2023"),
        ("Refrigerant R-22",   "per lb",      "0.821",    "GWP 1,810 (IPCC AR4) × 0.4536 kg/lb"),
        ("Refrigerant R-410A", "per lb",      "0.947",    "GWP 2,088 (IPCC AR4) × 0.4536 kg/lb"),
        ("Electricity",        "per kWh",     "State-level", "EPA eGRID 2022 subregion averages; US avg 0.000386 fallback"),
    ]
    factor_rows_html = "".join(
        f"<tr><td>{r[0]}</td><td>{r[1]}</td><td class='num'>{r[2]}</td><td>{r[3]}</td></tr>"
        for r in factor_rows
    )

    today_str = date.today().strftime("%B %d, %Y")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Carbon Footprint Estimate FY {year} — Northwood Capital</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    body {{
        max-width: 1100px;
        margin: 0 auto;
        padding: 40px 60px;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        font-size: 14px;
        line-height: 1.6;
        color: #1a1a1a;
        background: #ffffff;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 13px;
    }}
    th {{
        background-color: #1B2A3D;
        color: #ffffff;
        font-weight: 600;
        text-align: left;
        padding: 10px 14px;
        border: 1px solid #1B2A3D;
    }}
    td {{
        padding: 8px 14px;
        border: 1px solid #dee2e6;
        vertical-align: top;
    }}
    tr:nth-child(even) {{ background-color: #f8f9fa; }}
    td.num, th.num {{
        text-align: right;
        font-variant-numeric: tabular-nums;
    }}
    h1 {{ font-size: 28px; font-weight: 700; color: #1B2A3D; margin: 8px 0 4px 0; }}
    h2 {{
        font-size: 22px; font-weight: 600; color: #1B2A3D;
        margin: 36px 0 12px 0;
        border-bottom: 2px solid #1B2A3D;
        padding-bottom: 6px;
    }}
    h3 {{ font-size: 16px; font-weight: 600; color: #2C4A6E; margin: 24px 0 8px 0; }}
    p {{ margin: 8px 0; }}
    ul {{ margin: 8px 0; padding-left: 24px; }}
    li {{ margin: 4px 0; }}
    .metric-cards {{ display: flex; gap: 20px; margin: 25px 0; }}
    .metric-card {{
        flex: 1;
        background: #f8f9fa;
        border-left: 4px solid #0D6EAA;
        padding: 16px 20px;
    }}
    .metric-label {{ font-size: 12px; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }}
    .metric-value {{ font-size: 32px; font-weight: 700; color: #1B2A3D; margin: 4px 0 2px 0; }}
    .metric-sub {{ font-size: 13px; color: #555; }}
    @media print {{
        body {{ padding: 20px; max-width: 100%; }}
        table {{ page-break-inside: avoid; }}
        h2 {{ page-break-after: avoid; }}
    }}
</style>
</head>
<body>

<div style="border-bottom: 3px solid #1B2A3D; padding-bottom: 20px; margin-bottom: 30px;">
    <div style="font-size: 12px; color: #555; text-transform: uppercase; letter-spacing: 1px;">
        Northwood Capital — Confidential
    </div>
    <h1>Carbon Footprint Estimate — FY {year}</h1>
    <div style="font-size: 14px; color: #555;">
        ESG Report — Scope 1 &amp; 2 GHG Emissions | {n_portcos} of {total_portcos} Portfolio Companies
        | Generated {today_str}
    </div>
</div>

{missing_html}

<h2>Portfolio Summary</h2>

<div class="metric-cards">
    <div class="metric-card">
        <div class="metric-label">Total Emissions</div>
        <div class="metric-value">{fmt_mt(port_total)}</div>
        <div class="metric-sub">mt CO₂e — Scope 1 + 2</div>
    </div>
    <div class="metric-card">
        <div class="metric-label">Scope 1 (Direct)</div>
        <div class="metric-value">{fmt_mt(port_scope1)}</div>
        <div class="metric-sub">mt CO₂e — {port_scope1_pct} of total</div>
    </div>
    <div class="metric-card">
        <div class="metric-label">Scope 2 (Electricity)</div>
        <div class="metric-value">{fmt_mt(port_scope2)}</div>
        <div class="metric-sub">mt CO₂e — {port_scope2_pct} of total</div>
    </div>
    <div class="metric-card">
        <div class="metric-label">Reporting Coverage</div>
        <div class="metric-value">{n_portcos}/{total_portcos}</div>
        <div class="metric-sub">Portfolio companies with submitted data</div>
    </div>
</div>

<p style="font-size:12px;color:#888;">
    Management estimate — not third-party verified. GHG Protocol Scope 1 &amp; 2 methodology applied.
    FY {year} is the baseline year; year-over-year comparison available from FY {year + 1} onward.
</p>

<h2>Emissions by Portfolio Company</h2>

<table>
    <thead>
        <tr>
            <th>Company</th>
            <th class="num">Scope 1 (mt CO₂e)</th>
            <th class="num">Scope 2 (mt CO₂e)</th>
            <th class="num">Total (mt CO₂e)</th>
            <th class="num">% of Portfolio</th>
            <th class="num">Intensity (mt/employee)</th>
        </tr>
    </thead>
    <tbody>
        {"".join(portco_rows_html)}
    </tbody>
</table>

<h2>Facility-Level Detail</h2>

<p style="font-size:13px;color:#555;">
    Facilities with zero reported consumption omitted. All values in metric tons CO₂e.
    Rows marked * used estimated consumption (see data_source = estimate in source CSV).
</p>

<table>
    <thead>
        <tr>
            <th>Facility ID</th>
            <th>Company</th>
            <th>Facility Type</th>
            <th>Location</th>
            <th class="num">Scope 1 (mt CO₂e)</th>
            <th class="num">Scope 2 (mt CO₂e)</th>
            <th class="num">Total (mt CO₂e)</th>
        </tr>
    </thead>
    <tbody>
        {"".join(facility_rows_html)}
    </tbody>
</table>

<h2>Methodology &amp; Assumptions</h2>

<h3>Emission Factors Applied</h3>

<table>
    <thead>
        <tr>
            <th>Source</th>
            <th>Unit</th>
            <th class="num">Factor (mt CO₂e)</th>
            <th>Reference</th>
        </tr>
    </thead>
    <tbody>
        {factor_rows_html}
    </tbody>
</table>

<h3>Data Collection</h3>
<p>
    Consumption data collected via standardized CSV template submitted by each portfolio company's finance
    team. Data covers calendar year {year}. Portcos reported: utility invoices (electricity, natural gas),
    fuel purchase records (diesel, gasoline, propane), fleet fuel logs, and refrigerant purchase/recharge
    records where applicable.
</p>

<h3>Leased Facilities</h3>
<p>
    Where a portco does not control utilities (tenant in a multi-tenant building), the portco was asked
    to provide dollar spend on utilities. Spend-based estimates use EPA Commercial Buildings Energy
    Consumption Survey (CBECS) intensity benchmarks by building type and climate zone, converted using
    the applicable eGRID electricity factor and EPA natural gas factor. Such rows are flagged
    <code>data_source = estimate</code> in the source CSV and marked * in the facility table above.
</p>

<h3>Scope and Limitations</h3>
<ul>
    <li>This report covers Scope 1 (direct combustion, refrigerants, fleet) and Scope 2 (purchased electricity).
        Scope 3 emissions are excluded; recommended for assessment once this Scope 1/2 baseline is established.</li>
    <li>Electricity emission factors are location-based (eGRID subregion) not market-based.
        Market-based accounting (using renewable energy certificates) is a future enhancement.</li>
    <li>FY {year} is the baseline year. No year-over-year comparison is available until FY {year + 1} data is collected.</li>
    <li>This is a management estimate, not a third-party verified disclosure. Not suitable for
        use in regulatory filings without independent verification.</li>
</ul>

<div style="border-top: 1px solid #dee2e6; margin-top: 40px; padding-top: 15px;
            font-size: 11px; color: #888; text-align: center;">
    CONFIDENTIAL — Northwood Capital | Carbon Footprint Estimate FY {year} | {today_str}
</div>

</body>
</html>"""

    return html


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Northwood Capital — Carbon Footprint Estimator",
        usage="python tools/carbon_footprint.py [--year YYYY] [--portco SLUG] [--json]",
    )
    parser.add_argument(
        "--year", type=int, default=2025,
        help="Reporting year (default: 2025)",
    )
    parser.add_argument(
        "--portco", type=str, default=None,
        help="Single portco slug (e.g. sterling-precision-manufacturing). Default: all portcos.",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output machine-readable JSON instead of HTML report.",
    )

    args = parser.parse_args()

    # Determine which portcos to process
    slugs = [args.portco] if args.portco else list(PORTCO_META.keys())

    # Load data
    raw_data = {}
    missing  = []
    for slug in slugs:
        rows = load_portco_csv(slug, args.year)
        if rows:
            raw_data[slug] = rows
        else:
            missing.append(slug)

    if not raw_data:
        print(
            f"No carbon data found in _data/carbon/ for year {args.year}.\n"
            f"Expected files: _data/carbon/{{portco-slug}}-{args.year}.csv\n"
            f"Template available at: _data/carbon/carbon-collection-template-{args.year}.csv",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load facility headcount for intensity metrics
    try:
        facility_headcount = load_facility_headcount()
    except FileNotFoundError:
        facility_headcount = {}

    # Compute emissions
    portfolio_results = {}
    for slug, rows in raw_data.items():
        portco_totals, facility_rows = compute_portco_emissions(rows, facility_headcount)
        portfolio_results[slug] = {**portco_totals, "facility_rows": facility_rows}

    if missing:
        print(
            f"Warning: No data found for {len(missing)} portco(s): {', '.join(missing)}",
            file=sys.stderr,
        )

    # Output
    if args.json:
        output = {
            "year": args.year,
            "generated": date.today().isoformat(),
            "portcos": {
                slug: {k: v for k, v in result.items() if k != "facility_rows"}
                for slug, result in portfolio_results.items()
            },
            "portfolio": {
                "scope1_total":       sum(r["scope1_total"] for r in portfolio_results.values()),
                "scope2_electricity": sum(r["scope2_electricity"] for r in portfolio_results.values()),
                "total_mt_co2e":      sum(r["total_mt_co2e"] for r in portfolio_results.values()),
                "portcos_included":   len(portfolio_results),
                "portcos_missing":    missing,
            },
        }
        print(json.dumps(output, indent=2))

    else:
        html = generate_html(portfolio_results, args.year, missing)

        # Save to esg/outputs/
        esg_output_dir = rc_utils._base_dir() / "esg" / "outputs"
        esg_output_dir.mkdir(parents=True, exist_ok=True)

        today_ym  = date.today().strftime("%Y-%m")
        filename  = f"carbon-footprint-estimate-{args.year}-{today_ym}-v1.html"
        filepath  = esg_output_dir / filename

        with open(filepath, "w") as f:
            f.write(html)

        port_total = sum(r["total_mt_co2e"] for r in portfolio_results.values())
        print(f"Report saved: {filepath}")
        print(f"Portfolio total: {port_total:,.0f} mt CO₂e")
        print(f"Coverage: {len(portfolio_results)} of {len(PORTCO_META)} portcos")
        if missing:
            print(f"Missing portcos: {', '.join(missing)}")


if __name__ == "__main__":
    main()
